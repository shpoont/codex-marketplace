# I01: a real Docker/Codex case

Completed and reviewed 2026-11-07. The owner authorized this increment with
GPT-6.1 Sol, High reasoning and the existing ChatGPT subscription. At this
checkpoint, I02 and subsequent increments had not started; see the later
[I02 results](i02-two-case-suite.md). This source prototype is not installed
in the marketplace plugin.

## Result

The [case](../examples/docker-codex-i01/README.md) asks Codex to update a JSON
timeout and matching README statement from 15 to 30 seconds, preserving other
values, text and the two-file project layout. Both final-profile real runs did
exactly that. Independent readback compared the entire JSON object and README,
not just the reward or the agent's completion statement.

| Final run | Full trial duration | Task result | Evidence and cleanup |
| --- | --- | --- | --- |
| Frozen agent 01 | 45.803 seconds | Passed | Complete transfer, separate verification and cleanup passed |
| Frozen agent 02 | 44.070 seconds | Passed | Complete transfer, separate verification and cleanup passed |

These runs used identical task inputs and runner bytes, distinct fresh native
sessions and containers, the same observed agent image ID, and the same pinned
verifier configuration. Native session records confirm `gpt-6.1-sol`, `high`
reasoning and Codex CLI 0.167.0 in both runs.

## Runtime and isolation

- Installed host Harbor 0.25.0 was used without modification. Docker server
  29.9.2 ran Linux/ARM64 containers; guest Codex was pinned and observed at 0.167.0.
- Normal native CLI status confirmed ChatGPT sign-in. Harbor consumed the
  existing auth file internally; no credential content was manually inspected,
  exported into arguments or baked into images. No API-key fallback was selected.
- Agent checkpoints before and after execution showed UID 1000, no extra
  privileges, no host mounts or Docker socket, no grader in the agent container,
  an inaccessible host-only canary and cleaned guest credential paths afterward.
- A separate verifier read the explicit `/app/project` artifact. It received no
  agent credentials. The grader only parses JSON and text; submitted code is
  never executed. No model judge, RewardKit or Worker was needed.
- The agent had public networking for inference and disabled native web tools.
  The verifier used Harbor's `no-network` configuration. This increment does not
  establish comprehensive network denial or adversarial isolation for all tasks.

The retained local image IDs are:

| Role | Image ID |
| --- | --- |
| Agent | `sha256:ec187faae5a89a4600ef57a106cc3da0e301adda3b827f281ffb55480e77bf81` |
| Verifier | `sha256:a24972929c032d5299210261d9fe85330c77afcd9f0afe2d6de311b37ac3b48a` |

Agent image readback was observed in both final trials. Docker start history
also directly identified the first verifier image; historical events for the
second verifier were unavailable when collected. The second trial retains the
identical native task/image configuration, separate-verifier result and graded
artifacts. It is not presented as an independently captured second image event.

## Calibration and the setup correction

Each final-profile non-model control was reviewed before the next:

| Control | Native reward | Reviewed outcome |
| --- | --- | --- |
| Known-good reference output | 1 | Passed with complete collection |
| Plausible defect: config updated, README stale | 0 | Valid rejection; documentation criterion failed |
| Deliberately missing harness-owned artifact | 1 | Infrastructure error: failed collection invalidates the numeric reward |

The last control is an intentional broken harness declaration, not a candidate
task failure or an actual provider outage. It exercises Harbor's real collection
manifest and separate-verifier path without a model.

Two earlier real trials also passed, taking about 53 seconds each. Review caught
that native build-per-trial images had different identities and were removed
afterward. The correction uses standard prebuilt `docker_image` fields: the
[preparer](../examples/docker-codex-i01/prepare.py) builds once and writes exact
local image IDs into a disposable native task copy. Calibration was repeated
on that profile, then the final pair above ran. Original results remain intact.
No host installation or installed-Harbor patch was needed.

Total work comprised four real Codex trials and seven non-model Oracle trials,
including initial build/qualification controls. None used another model or a
model judge. Usage records are retained; Harbor's `cost_usd` fields are model
pricing metadata, not evidence of subscription billing.

## Source checks, retained evidence and stopping point

Native task schema checks, Python syntax checks, the repository package verifier,
relative-link/privacy checks and whitespace checks pass. The runner records the
task contents, its own digest, selected model/settings, native result, artifacts,
isolation checkpoints and owned-resource cleanup. The original host fixture
remained at 15 seconds.

Raw evidence is retained outside Git under
`$TEST_EVIDENCE/harbor-i01-2026-11-07`, including `i01-review.json`, native run
directories, collection manifests and per-run cleanup records. Pattern scans of
retained outputs found no token-shaped credential disclosure; this is a scoped
check, not a proof against every possible disclosure.

Owned evaluation containers and networks were removed. Prepared images and
normal Docker build caches are retained for reuse. No project migration,
registry upload, host update, plugin installation or marketplace release occurred.

This qualifies one concrete single-task execution example. It does not establish
general reliability, other interaction modes, a universal runner, or acceptance
of an existing project. The next increment is I02: author a second realistic case
and rerun a suite without changing the execution machinery.
