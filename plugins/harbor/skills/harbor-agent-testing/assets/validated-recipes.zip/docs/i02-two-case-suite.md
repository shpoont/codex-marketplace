# I02: two cases, two reviewed rounds

Completed and reviewed 2026-11-07 using the owner's authorized GPT-6.1 Sol / High
and existing ChatGPT subscription. This increment adds a second realistic case
and repeats the selected suite without changing the I01 runner. At this
checkpoint I03 remained pending; see the later [I03 results](i03-ordered-workflow.md).
The source prototype is uncommitted and is not installed or released.

## Cases and authoring recipe

| Case | Acceptance criterion | Actual-effect checks |
| --- | --- | --- |
| [Timeout](../examples/docker-codex-i01/README.md) | Change the timeout from 15 to 30 seconds and update its README statement | Entire JSON object, exact documentation and two-file layout |
| [Staging compression](../examples/docker-codex-i02-staging/README.md) | Enable compression only for staging and update the runbook | Entire JSON object; unchanged defaults, production, custom overrides and owner notes; exact documentation and three-file layout |

The new case's README maps each requirement to participant-visible materials and
hidden verification, and gives the authoring and run recipe. It uses native
Harbor instructions, fixtures, `task.toml`, artifacts and results. Its grader
parses transferred JSON/text without executing submitted code. JSON formatting
may vary; unrelated data and files must be preserved.

The selected suite is timeout followed by staging. Each case runs in its own
native Harbor job through the existing command entrypoint. Review its answer,
actual artifacts, collection and cleanup before running the next case; then
repeat the same selection in new output directories. No new suite engine or
case language was introduced.

## Live results and individual review

| Round | Case | Full trial duration | Reviewed result |
| --- | --- | --- | --- |
| 1 | Timeout | 45.430 seconds | Passed; exactly the required effects |
| 1 | Staging compression | 46.187 seconds | Passed; staging-only change and preserved customizations |
| 2 | Timeout | 47.620 seconds | Passed; exactly the required effects |
| 2 | Staging compression | 58.359 seconds | Passed; staging-only change and preserved customizations |

All four attempts completed and were valid scored passes. None were skipped,
incomplete or classified as infrastructure errors. Each result received a
separate artifact and trace review before the next attempt started. Retained
timestamps confirm that order. Independent readback derived the expected effects
from the source fixtures and compared complete saved files, rather than relying
on the reward or the agent's completion claim.

Both rounds used identical task/input records within each case and the same
pinned image IDs. All four native sessions and agent containers were distinct.
Native session metadata confirmed `gpt-6.1-sol`, `high` and guest Codex 0.167.0.
Installed host Harbor remained 0.25.0; Docker ran Linux/ARM64 containers.
Normal CLI status selected the existing ChatGPT sign-in; no API-key route was
substituted.

The runner remained byte-for-byte identical to I01 throughout I02:
`03d5028b7969326ad0eb157fa6791166f282eb82c778e3cc6b38c8c855e2af1e`
(SHA-256 of `tooling/run_docker_case.py`). The original I01 preparer was also
unchanged. No runner repair, retry or rubric change occurred between live runs.

Each agent initially tried the unavailable `python` command and recovered using
`python3`. Those tool errors did not prevent correct completion and were not
harness failures. The images were left unchanged during the suite.

## Calibration and preparation correction

The new case accepted its known-good reference output, including JSON
reformatting. Review then caught that its copied preparation script reused I01's
friendly Docker image tags. Before any I02 live-agent attempt, only the new
case's image-tag prefix was changed to `harbor-i02-staging-`; both case profiles
were prepared and frozen for the suite. Docker recipes, transfer interface,
original preparer and runner were unchanged.

The known-good control was repeated on the corrected profile and reviewed. A
separate plausible-bad control then changed the global compression default while
making the runbook look correct. It was validly rejected with reward 0: the
configuration and staging-only checks failed, while documentation, owner notes,
file layout and credential checks passed. Collection and cleanup succeeded.
This demonstrates a behavioral rejection rather than a broken test setup.

Total I02 execution comprised four real Codex trials and three non-model Oracle
controls, including the initial good control before the tag correction. The
[I01 missing-artifact control](i01-docker-case.md#calibration-and-the-setup-correction)
remains applicable evidence for the unchanged runner's infrastructure-error
classification; it was not rerun or presented as new I02 coverage. These finite
cases do not qualify every possible incomplete or inconclusive outcome.

## Isolation, evidence and limits

Every live trial passed complete artifact collection, separate deterministic
verification and owned-resource cleanup. Before/after agent observations showed
UID 1000, no host mounts, extra privileges, Docker socket or grader access, an
inaccessible host-only canary and cleaned guest credential paths. Verifiers
reported no agent credentials. Host fixtures remained at their original values.
No credential content was manually inspected or copied into source or arguments.

The agent image IDs were observed in both rounds; the verifier image IDs are
fixed in the matching native task configurations. This report does not claim
separate retained Docker event captures for every verifier launch. Agent public
networking permits inference with native web tools disabled; the verifier uses
`no-network`. Comprehensive adversarial or network isolation remains later work.

Raw evidence is retained outside Git under `$TEST_EVIDENCE/harbor-i02-2026-11-07`:
`suite-profile.json`, `i02-review.json`, each native run's inputs, result,
artifacts, isolation, cleanup and individual `review.json`. A scoped pattern
scan of 236 retained files found no token-shaped credential disclosure; it is
not a proof against every possible disclosure. Prepared image IDs remain
available. Owned evaluation containers and networks are gone.

The four live trials took 197.596 seconds in total, excluding preparation and
human/operator review gaps. Native usage totals were 254,850 input tokens,
including 230,912 cached tokens, and 4,188 output tokens. Harbor's price metadata
is not subscription billing evidence. No judge, simulated user, Worker, nested
model, upload, host upgrade or marketplace installation was used.

Native schema/syntax checks, source/package checks, relative links, privacy and
whitespace checks pass. This qualifies repeated execution of two small synthetic
repository-maintenance cases through one unchanged route. It does not establish
all case forms, application-code correctness, real-project migration or general
reliability. The next increment is I03's ordered workflow with fresh sessions.
