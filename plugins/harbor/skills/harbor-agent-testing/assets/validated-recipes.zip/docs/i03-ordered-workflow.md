# I03: ordered work, fresh sessions and early stopping

Completed and individually reviewed 2026-11-07 with the owner's authorized
GPT-6.1 Sol / High and existing ChatGPT subscription. At this checkpoint I04
remained pending; see the later [I04 results](i04-continued-conversation.md).
This is an uncommitted source prototype, without installation or release.

## Workflow and results

The [native two-step example](../examples/docker-codex-i03-workflow/README.md)
prepares a timeout change and file handoff, then creates a staging release record
from that handoff and a newly supplied operator request. The same disposable
container holds both steps; `resume_trajectory=false` starts fresh conversations.
This is a synthetic maintenance workflow, without deployment or external writes.

| Live case | Full duration | Steps attempted / completed / skipped | Reviewed disposition |
| --- | --- | --- | --- |
| Approved change | 81.734 seconds | 2 / 2 / 0 | Passed; both milestones and complete workflow |
| Held approval | 44.175 seconds | 1 / 1 / 1 | Stopped correctly; first milestone passed, workflow incomplete |

Both cases used actual `gpt-6.1-sol` / `high`, observed guest Codex 0.167.0 and
the existing native ChatGPT sign-in. Installed host Harbor remained 0.25.0;
Docker used Linux/ARM64. No API-key/provider substitution, host upgrade, model
judge or nested model was used. The approved case was reviewed before preparing
and executing the held case; its reference control was reviewed before its
live attempt. All native results were reviewed before the next trial started.

Completed-step counts mean completed execution with a grade, not accepted
quality. The held workflow is not counted as a complete workflow pass. There
were two live workflow trials and three fresh model sessions, without retries.

## What the evidence establishes

- **Fresh conversations:** the approved steps have different native session
  IDs, each with one session and the agreed CLI/model/effort metadata. The second
  session contains no first-step prompt. First-step transcripts contain neither
  the later instruction nor the later request's ticket. The held trial has one
  additional distinct session and no second-step agent execution.
- **Persisted work:** both approved steps used the same observed agent
  container. Independent review compared the complete configuration and README,
  verified the handoff digest, and compared all previous files byte for byte
  against the second-step artifacts. The final release record matches those
  persisted inputs and the operator request.
- **Setup provenance:** pre-agent checkpoints recorded project file hashes.
  Before step 2, every prior file matched step 1's post-agent checkpoint; only
  the expected request file had been added. Its bytes matched the supplied
  workdir fixture. Setup only copies that metadata; it does not create the
  prior handoff or final release record.
- **Early stopping:** a failed quality control skipped step 2. Separately, held
  approval preserved `approved=false` and earned `reward=1, ready=0` for correct
  first-step work. The continuation gate skipped step 2 and its setup; no later
  request or release file appeared in the collected project.
- **Honest completion:** native `final` aggregation selects the last executed
  step, not necessarily the intended final milestone. The native quality reward
  1 was retained alongside `stopped`, `workflow_complete=false` and one skipped
  step. Intermediate quality cannot produce a whole-workflow pass.

These observations qualify this concrete fresh-session workflow. They do not
establish resumed conversation, loaded history, adaptive simulation, general
memory isolation or reliability across arbitrary tasks.

## Runner changes and separate validation

The I01/I02 adapter assumed one root artifact/verifier directory and two
isolation checkpoints. Multi-step results instead store step directories and
step-level exceptions; their trial-level verifier-mode field is unset. I03
extends the adapter to inspect each executed step, retain native rewards,
aggregate usage, report planned/attempted/completed/skipped steps and require
complete valid execution for a pass. For workflow fixtures it records focused
project-file hashes at each agent boundary. Fresh sessions are explicitly
selected; credential routing and Docker lifecycle remain on the native path.

Seven focused reporting tests cover a complete workflow, partial reward 1,
step-level error, missing collection, setup failure before agent execution,
earlier failure hidden by a final pass, and single-case compatibility. Run them
with the selected Harbor interpreter:

```sh
"$HARBOR_PYTHON" tests/test_docker_summary.py
```

Native controls were run and reviewed separately:

| Control | Reviewed result |
| --- | --- |
| Existing I01 reference solution | Passed the single-case path with exact intended effects |
| Deliberately missing harness artifact | Native reward 1 correctly invalidated as infrastructure error |
| Approved two-step reference solutions | Both steps and workflow passed |
| Stale README in first reference step | Valid quality rejection; second step skipped |
| Held approval with correct first reference step | Quality reward 1; workflow stopped with second step skipped |

The setup-failure bookkeeping check was added during local development; it
prevents claiming collection when no agent ran. It does not change the observed
single-case controls, each of which executed an agent phase. All three workflow
controls and both live workflows used the same final runner bytes:
`2863fded9ca15731abb01ed692ac1a1134888f8a55f170e5e31d51f672082dc9`
(SHA-256). No runner or rubric repairs occurred between the live cases.
Total non-model work was five Oracle trials, comprising six step executions.

## Safeguards, checks and retained evidence

Before/after checkpoints showed UID 1000, no host mounts, extra privileges,
Docker socket or grader access, inaccessible host-only canaries, and cleaned
guest credential paths. Declared artifacts were completely collected and read
by separate deterministic verifiers; no submitted code was executed for grading.
Each step has a pinned verifier image and the agent image ID was observed.
Verifier mode is resolved from explicit native configuration and supported by
the separate verifier outputs, not a nonexistent per-step native mode field or
independently captured image event for every verifier launch.

The agent retains public networking for inference with native web tools disabled;
verifiers use `no-network`. Exhaustive adversarial and network isolation remain
outside this increment. Host fixtures and installed source digests remained
unchanged. Owned containers/networks were removed; prepared images are retained.
The held agent's initial AGENTS.md search returned no matches; its subsequent
edit and validation commands succeeded. This was not an infrastructure failure.

The two live trials took 125.909 seconds in total, excluding preparation and
review gaps. Native usage was 146,740 input tokens (128,256 cached) and 2,626
output tokens. Native price metadata is not subscription billing evidence.
Raw inputs, native results, step artifacts, sessions, checkpoints, cleanup,
individual reviews and `i03-review.json` remain outside Git under
`$TEST_EVIDENCE/harbor-i03-2026-11-07`. A scoped scan of 283 retained files found
no token-shaped disclosure; it is not a proof against every possible disclosure.

Native task/schema and Python syntax checks, the reporting tests, package
verification, source links/privacy and whitespace checks pass. This completes
I03 only. Real-project adoption, remaining case forms and marketplace release
remain separate later work.
