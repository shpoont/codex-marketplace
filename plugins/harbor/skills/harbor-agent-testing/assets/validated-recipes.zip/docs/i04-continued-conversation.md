# I04: continued conversations and corrections

Completed and individually reviewed 2026-11-07 with GPT-6.1 Sol / High and the
owner's existing ChatGPT subscription. At this checkpoint I05 remained pending;
see the later [I05 results](i05-native-history-loading.md). These source
changes are uncommitted, uninstalled and unreleased.

## Cases and reviewed results

The [conversation template](../examples/docker-codex-i04-conversation/README.md)
receives synthetic release details, then later creates a JSON record without
repeating those values in the final request. The correction variant inserts a
message changing only the window. Both use `--resume-trajectory` in disposable
Docker, with separate deterministic verification and no model judge.

| Live attempt | Full duration | Attempted / completed / skipped steps | Reviewed disposition |
| --- | --- | --- | --- |
| Initial basic conversation | 52.174 seconds | 2 / 1 / 0 | Infrastructure error; positive reward invalidated |
| Basic conversation after ownership repair | 46.087 seconds | 2 / 2 / 0 | Passed conversation and actual-effect checks |
| Three-message correction | 58.095 seconds | 3 / 3 / 0 | Passed; corrected window and retained prior details |

Every result was reviewed before the next trial. The base case was qualified
before implementing the correction variant; each new control was then reviewed
before proceeding. There were three real workflow attempts and seven Codex step
invocations, including the failed attempt. The targeted retest followed diagnosis;
automatic retries stayed disabled. Completed counts mean execution with a grade.
Native metadata confirms `gpt-6.1-sol`, `high`, guest Codex 0.167.0 and ChatGPT
sign-in. Host Harbor stayed at 0.25.0 on the qualified Linux/ARM64 Docker setup.

## Conversation evidence and limits

The qualified basic case retained one native session ID across both messages;
the correction case retained another across all three. CLI thread IDs matched
session metadata. Each later session snapshot preserved the previous snapshot
as a prefix and added a turn with the agreed model/effort.

Before the final turn, workspace snapshots contained exactly two unchanged
reference files, neither containing the release details. Receive/correct turns
made no tool calls or file writes. Final commands did not retrieve values from
session files, logs or process state. The JSON contained the earlier opaque label
and owner; the correction case used `16:00 UTC`, superseding `14:30 UTC`.
Future instructions and the correction value were absent from earlier snapshots.

Filesystem absence means the task workspace. Native runtime history necessarily
stores the conversation on disk; arbitrary access to that history was not
blocked by this test. The evidence combines native continuation, unchanged
workspace state and no observed tool-based history retrieval.

The basic acknowledgement was `ACKNOWLEDGED.` despite an exact-word request.
That minor format deviation is retained as an instruction-adherence finding,
not described as perfect prompt compliance. It revealed no details and used no
tools. The correction acknowledgements matched exactly. Data correctness and
session continuity are evaluated separately from punctuation.

## Separate repair iterations

1. **Resume selection:** the adapter exposes native `resume_trajectory`, records
   its effective selection and retains fresh conversations as the default.
2. **Guest log ownership:** the first attempt hit
   `tee: /logs/agent/codex.txt: Permission denied` after the native log roundtrip
   left files owned by host/root identities. The output earned reward 1, but
   the step exception and stale follow-up logs invalidated the attempt. A
   model-free Docker copy/write control reproduced the mismatch. The launcher
   now restores only native guest-log ownership to the existing nonroot agent
   before later resumed steps, preserving content/modes and guarding against
   mounted logs and unsafe entries. The control proved denial before repair,
   successful writing afterward and symlink rejection; its container was removed.
   The same base inputs, rubric and image pins then passed a fresh trial. The
   correction case verified repair across two consecutive resume boundaries.
   Installed Harbor, project files and evaluated-agent privileges were unchanged.
3. **Cumulative usage:** retained Codex contexts reported cumulative counters.
   Summing 12,603 and 38,765 inputs incorrectly yielded 51,368; the final session
   counter was 38,765. The runner now uses the latest resumed snapshot, retains
   the raw step sum and marks errored usage incomplete. Fresh contexts still sum.
   Two regression tests were added; all nine reporting tests pass. Saved basic
   results were recalculated into separate `derived-summary.json` files without
   new inference or overwriting originals. Correction usage matched native
   counters. No prompts or grading criteria changed for this reporting repair.

Four Oracle trials (ten step executions) separately accepted the correct basic
record, rejected a wrong label, accepted the corrected record and rejected the
stale window. They qualify data grading/transfer, not native conversation resume
or acknowledgements. The additional Docker ownership control used no model.
No model calls were added merely to improve punctuation.

## Usage, safeguards and retained evidence

The two qualified workflows took 104.182 seconds, excluding preparation/review
gaps. Complete session totals were 90,216 input tokens (79,872 cached) and 826
output tokens. The failed attempt has a known first-turn count of 12,603 input
tokens, but follow-up usage cannot be recovered from stale logs. There is no
exact grand usage total. Native price metadata is not subscription billing.

Qualified steps passed complete collection, separate verification, UID 1000,
no host mounts/extra privileges/Docker socket/grader access, host canaries and
guest credential cleanup. Graders parsed data without executing submitted code.
Agent image IDs were observed; verifier images were pinned in native config,
without independently retained image events for every verifier launch. Public
agent networking permits inference with web tools disabled; verifiers use
`no-network`. Exhaustive adversarial/network isolation remains outside I04.

Raw jobs, snapshots, inputs, artifacts, checkpoints, ownership controls, cleanup,
individual reviews, derived summaries and `i04-review.json` remain outside Git
under `$TEST_EVIDENCE/harbor-i04-2026-11-07`. A scoped scan of 358 retained files
found no token-shaped disclosure; it is not proof against every disclosure.
Source fixture bytes and installed source digests stayed unchanged. Owned
containers/networks are gone; prepared images remain. No key/provider fallback,
host upgrade, judge, nested model, upload or marketplace installation occurred.

Final runner SHA-256:
`215531840c2026cff536d5d43351ef02c04c0d4e4f03614334a1a384c478cc97`.
Earlier digests remain in original inputs. Native schema, Python syntax, nine
reporting tests, package verification, links/privacy and whitespace checks pass.
This qualifies the two concrete C03 cases, not loaded histories, adaptive
simulation, general conversational reliability or real-project adoption.
Stop at I04; later modes and release remain separate work.
