# I05: native Codex history loading

Completed and individually reviewed 2026-11-07 with GPT-6.1 Sol / High and the
existing ChatGPT subscription. At this checkpoint I06 remained pending; see the
later [I06 results](i06-atif-loading.md). These changes are source
prototypes: uncommitted, uninstalled and unreleased.

## Task and seed

The [native-loading example](../examples/docker-codex-i05-load-native/README.md)
uses the unchanged final native rollout from I04's reviewed correction case.
Its three earlier turns contain a release label, owner, corrected window and
the actual creation of `RELEASE.json`. The original filename and bytes were
preserved; its source digest and original file artifact were recorded.

A fresh task image supplies two new reference files and none of those details.
The target must recover the conversation into `CONTEXT.json`, record its initial
workspace in `WORKSPACE_CHECK.json`, and leave the earlier `RELEASE.json` absent.
No prior project files are supplied. This is a synthetic task without deployment,
external writes, model judges or submitted-code execution during grading.

## Separate results and reviews

| Check | Observed result | New model calls |
| --- | --- | --- |
| Wrong native filename | Installed filename validation rejected it before evaluation startup | 0 |
| Correct reference output | Passed deterministic grading and complete collection | 0; Oracle |
| Plausible recreated old file | Validly rejected despite correct context values | 0; Oracle |
| Initial valid native load | Passed in 34.244 seconds | 1 |
| Malformed JSONL with a valid filename | Started a fresh session; loading failure, excluded from agent-quality scoring | 1 |
| Malformed content after repair | Specific input error before Docker/inference | 0 |
| Valid load through repaired path | Passed in 33.406 seconds | 1 |
| Wrong filename through repaired path | Specific input error before Docker/inference | 0 |

Each result was reviewed before the next scenario. There were three real Codex
trials, two Oracle controls and three prestartup rejection checks. The original
native rejection, silent-fallback result, guarded rejections and targeted valid
retest all remain recorded. No automatic retries were enabled.

Both valid attempts used the same supplied native session in distinct new
containers, also distinct from I04's container. The retained original three-turn
history was an exact byte prefix of each new four-turn snapshot. Source filename,
source hash, metadata session ID and executed thread ID matched. The final
guarded attempt also passed the runner's automatic loading receipt.

Native metadata confirmed `gpt-6.1-sol`, `high` and guest Codex 0.167.0. Host
Harbor remained 0.25.0 on Linux/ARM64 Docker with existing ChatGPT sign-in.
There was no key/provider fallback, host upgrade or installed-Harbor patch.

## Conversation loads; files do not

Pre-agent workspace hashes showed only the new image's two reference files.
The first actual tool command, after history loading and before writes, inspected
that workspace and reported `RELEASE.json` absent. Saved workspace-check output
agreed with the observed command output. Final artifacts contained the two
unchanged references and only the two requested JSON files.

The context JSON recovered the earlier label and owner and the corrected
`16:00 UTC` window. Those values were absent from the new prompt and workspace;
the agent did not retrieve them by reading session files, logs or process state.
This establishes native conversation loading without restoration of the earlier
project file for this concrete case. Native runtime history itself remains on
disk; arbitrary access to it was not tested as an adversarial boundary.

## Malformed input discovery and repair

The pinned Harbor filename validator accepted the correctly shaped filename
without validating its JSONL contents. With damaged contents, the guest Codex
combination silently started a different session. The agent correctly reported
that prior details were unavailable and declined to invent them. The old report
labelled the resulting zero as a task failure; review classified it as a loading
infrastructure error, not evidence of poor agent behavior.

The source runner now validates complete JSON object records, initial native
metadata and filename/session-ID agreement before startup. It reuses the selected
installed Codex filename pattern. Invalid inputs produce a structured input
error, no scored reward and zero model/container invocations. It does not rewrite
or repair a history or substitute a fresh session.

A post-run check also requires the supplied native prefix to extend and the
executed thread to match the expected session. A successful command or numeric
reward cannot establish loading on its own. Applying this check to the original
silent-fallback output detected the mismatch; its corrected interpretation was
saved separately as `derived-summary.json`, preserving the original records.

Four focused tests cover valid input, damaged/missing metadata or mismatched
identity, filename/missing-file rejection, and detection of unchanged history
or a fresh thread. Together with the nine existing reporting tests, all 13 pass.
The guard accepted the real seed and recorded continuation before the live
retest; both malformed CLI paths and the valid load were then checked separately.
These checks qualify the selected complete native format, not every semantic
corruption, legacy export or cross-version conversion. ATIF remains I06 work.

## Usage, safeguards and retained evidence

Imported native counters include I04's historical usage. The two valid I05
continuations added 55,926 input tokens (54,400 cached) and 1,227 output tokens,
derived by subtracting the unchanged seed's counters from each final snapshot.
The malformed-content fallback consumed another 39,828 input tokens (38,272
cached) and 767 output tokens. All three new calls therefore total 95,754 inputs
(92,672 cached) and 1,994 outputs. Historical seed work is not counted as new
inference. The two qualified trials took 67.650 seconds excluding preparation
and review gaps. Native price metadata is not subscription billing evidence.

Valid runs passed complete collection, separate deterministic verification,
UID 1000, no host mounts/extra privileges/Docker socket/grader access, host
canaries and guest credential cleanup. Agent image IDs were observed; verifier
images were pinned in native configuration, without separate image-event captures
for every verifier. Agent public networking supports inference with native web
tools disabled; verifiers use `no-network`. Exhaustive isolation is later work.

Raw evidence is outside Git under `$TEST_EVIDENCE/harbor-i05-2026-11-07`, including
the untouched seed, malformed fixtures, native jobs, outputs, snapshots, loading
receipts, reviews, derived report and `i05-review.json`. A scoped scan of 184
retained files found no token-shaped disclosure; it is not proof against every
disclosure. Source/seed bytes and installed source digests stayed unchanged.
Owned evaluation containers and networks are gone; prepared images remain.

Final runner SHA-256:
`f6b2b0f1cf85840ade535ba7a48a87ce312493f0de5cdae12eb283067eeba930`.
Native schema/syntax, 13 focused tests, package verification, relative links,
privacy and whitespace checks pass. This completes I05's concrete C04 route;
other loading formats, general reliability, real-project adoption and plugin
release remain separate work.
