# I06: ATIF loading, precedence and later-step state

Completed and individually reviewed 2026-11-07 with GPT-6.1 Sol / High and the
existing ChatGPT subscription. At this checkpoint I07 remained pending; see the
later [I07 results](i07-supplied-skills.md). The source prototypes are
uncommitted, uninstalled and unreleased.

## Live cases

| Case | Full trial duration | Reviewed result |
| --- | --- | --- |
| Task-level ATIF | 32.358 seconds | Passed; user text and linked historical tool receipt recovered |
| Run-level override | 29.148 seconds | Passed; run values/session used, conflicting task values absent |
| Loaded first step, fresh second step | 54.417 seconds | Passed; new second-step session, unknown values reported as null, files persisted |
| Loaded first step, resumed second step | 53.796 seconds | Passed; same session and retained imported/new conversational values, files persisted |

Every result was reviewed before the next scenario. The
[task/run template](../examples/docker-codex-i06-atif/README.md) was qualified
first; the [later-step workflow](../examples/docker-codex-i06-atif-workflow/README.md)
was then added and checked fresh before resumed. All four live trials passed
without retries, skipped steps or infrastructure errors: six Codex step
invocations in four disposable Docker trials.

Native metadata and guest checks confirmed `gpt-6.1-sol`, `high` and Codex
0.167.0. Installed host Harbor remained 0.25.0 on Linux/ARM64 Docker with normal
native ChatGPT sign-in. No provider/key fallback, host update, installed-Harbor
patch, judge, nested model, upload or marketplace installation occurred.

## Effective loading source and invalid inputs

The task case supplies `trajectory.json` beside its instruction and leaves the
native run-level load setting unset. Its converted native prefix, source hash,
session ID and output match the task seed. The override case retains that task
history but supplies a different run-level ATIF file. The executed native session
and result match only the run seed; task-only markers are absent from its history.
The agent image and target instruction do not expose expected grading data.

The adapter now discovers the first instruction's task source, applies native
run-over-task precedence, validates only the selected source and records its
level/hash. Execution still uses Harbor's original task/run mechanism; the
adapter does not replace it with a preconverted native input. Loading receipts
compare actual output against the selected installed converter's expected prefix
and executed thread identity, extending I05's protection against silent fresh
fallback. The shared native receipt was also checked against retained I05 good
and fallback records without new inference.

Invalid task ATIF and an invalid run override were each rejected before Docker
or inference. The latter did not fall back to a valid task source. A unit check
also verifies that an unused invalid task source does not block a run override.
The original source bytes are never rewritten to repair invalid history.

## Conversion coverage and limits

A model-free probe used the actual installed ATIF-v1.8 schema and Codex converter.
Its retained input/output and review establish these specific transformations:

| Input | Observed converted representation |
| --- | --- |
| User/agent text | Preserved |
| Linked structured tool call and matching output | Preserved as native call/output records |
| System message text | Retained with developer role |
| Image and audio parts | Replaced by text placeholders; this converter labels both `[image omitted]` |
| Synthetic reasoning content, root notes, unlinked observation, media paths | Omitted in the tested representation |

The live task cases additionally recovered the linked tool-output marker. They
did not replay its historical call. Historical tool records do not establish
current tool availability or restore files. No live multimodal comprehension
claim follows from the conversion probe.

ATIF source IDs and timestamps can be absent or non-native. Receipt tests handle
runtime-generated native values without modifying the source, aligning only the
converter's generated identity/time for comparison. Those cases have offline
coverage; the four live cases use explicit source UUIDs/timestamps. This is not
a qualification of every ATIF version, legacy export or possible conversion loss.

## Fresh versus resumed later steps

Both workflow variants use identical participant instructions and ATIF seed.
The first loaded step receives a new conversation-only follow-up code and writes
only a fixed milestone. The second prompt does not restate the imported label,
tool receipt or new code. Its instructions explicitly permit null for values
unavailable in the active conversation.

With fresh default behavior, the second executed thread differs from the loaded
thread. Its active snapshot contains none of the three values, and its JSON
contains three nulls with `history_available=false`. This is the expected
successful outcome for the fresh case, not a loading failure.

With resume enabled, both threads use the imported ID. The second snapshot
extends the first and its output contains all three values with
`history_available=true`. In both cases, before/after file hashes show the same
unchanged references and persisted milestone across the boundary; workspace files
did not supply the values. Actual commands did not recover history from logs,
sessions or process state. First-step snapshots excluded the later instruction.

Fresh/resumed agent image IDs differed, so an initial exact-ID comparison was
not used as evidence of equality. Further readback confirmed identical filesystem
layers, runtime configuration and build sources. Each case's own immutable image
ID remained pinned and was checked by the runner. Grading expectations differ
deliberately between available and unavailable history. The I04 ownership repair
was exercised at the resumed boundary without changing agent privileges.

## Validation, usage and evidence

Five separately reviewed Oracle trials (seven step executions) calibrated correct
task data, rejection of a wrong receipt, override data, legitimate fresh nulls
and resumed values. They qualify grading/transfer; Oracle skips task histories
and does not prove conversation behavior. Two prestartup rejection checks and
the model-free conversion probe made no model calls.

All 17 focused tests pass: nine reporting, four native-loading and four ATIF
tests. They cover source selection, schema rejection, conversion boundaries and
receipt handling. Native schemas, Python syntax, source/package checks,
links/privacy and whitespace checks pass. No new standalone case language,
orchestration framework or approval gate was added.

The four live trials took 169.719 seconds total, excluding preparation/review
gaps. Native totals were 165,307 input tokens (128,256 cached) and 2,404 output
tokens. The synthetic ATIF seeds contain no historical usage counters. Fresh
steps sum independent contexts; resumed usage uses the latest cumulative native
counter. Both were checked against active-session counters. Price metadata is
not subscription billing evidence.

Complete collection, separate deterministic verification, UID 1000, no host
mounts/extra privileges/Docker socket/grader access, host canaries and credential
cleanup passed. Graders read data without executing submitted code. Agent image
IDs were observed; verifier images were pinned in native configuration, without
independent image events for every verifier. Public agent networking permits
inference with native web tools disabled; verifiers use `no-network`. Exhaustive
adversarial/network isolation remains later work.

Evidence is retained outside Git under `$TEST_EVIDENCE/harbor-i06-2026-11-07`,
including native jobs, source descriptors, converted-prefix receipts, active
snapshots, outputs, individual reviews, conversion probe, image comparison and
`i06-review.json`. A scoped scan of 394 retained files found no token-shaped
disclosure; it is not proof against every disclosure. Recorded installed-source
digests stayed unchanged. Owned evaluation containers/networks are gone;
prepared images remain available.

Final runner SHA-256:
`0648792b12a6284dbb438a5dad2e9defc81b725186cc3c28bb2eb9d28a11417e`.
This completes the concrete C05 examples. General memory reliability, additional
capabilities, real-project adoption and marketplace release remain separate work.
