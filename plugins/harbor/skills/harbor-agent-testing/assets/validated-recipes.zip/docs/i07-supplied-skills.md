# I07: supplied skills and context comparisons

Completed and individually reviewed 2026-11-07 with GPT-6.1 Sol / High and the
existing ChatGPT subscription. At this checkpoint I08 remained pending; see its
later [tools and services results](i08-tools-and-services.md). Source prototypes remain
uncommitted, unpushed, uninstalled and unreleased.

## Reviewed results

| Case | Full trial duration | Reviewed outcome |
| --- | --- | --- |
| Task-bundled skills | 35.233 seconds | Passed; native discovery, skill/reference reads and expected task-policy output |
| Job-only injection | 42.960 seconds | Passed; default sandbox source, native registration and expected job-policy output |
| Same-name precedence | 45.231 seconds | Passed; final job source wins over earlier job and bundled task sources |

Every control and live result was reviewed before starting the next scenario.
All three real Codex trials completed without trial retries, skipped steps or
infrastructure errors. The [native template and three recipes](../examples/docker-codex-i07-skills/README.md)
were added sequentially: task-bundled first, then job-only, then precedence.
The same participant prompt and project inputs ask for a structured release note
using the available synthetic `release-notes` skill and its policy reference.

Native rollout metadata and guest checkpoints confirm `gpt-6.1-sol`, `high` and
Codex 0.167.0. Host Harbor 0.25.0 stayed unchanged; Docker 29.9.2 ran Linux/ARM64.
The normal existing native ChatGPT sign-in was used, with no API-key/provider
fallback, installed-Harbor patch, judge, nested model, host upgrade or upload.

## Delivery, discovery and use

The task image bundles skills under `/opt/task-skills`, selected with native
`environment.skills_dir`. The job-only preparation removes the bundled skills
and that setting. Repeatable local `--skill` inputs populate Harbor's default
`/runtime/skills` directory. Native Codex then registers the source contents at
`/home/node/.agents/skills`.

Before inference, the sandbox source contained the selected files and native
registration was empty. After execution, source/native file manifests matched
exactly. Independent review compared them to frozen source contents. The active
rollouts listed the expected skill; successful commands read its native SKILL.md
and JSON reference. RELEASE.json used the selected policy, and existing project
files stayed byte-for-byte unchanged. These are separate observations of
content delivery, discoverability, use and the prescribed output.

The author used the Harbor plugin for evaluation guidance. Only the synthetic
fixture skills were supplied to the participant; authoring guidance, hidden
expectations, verifier code and Oracle solutions were not injected.

## Replacement and provenance

The precedence variant keeps the bundled skill, then supplies two local roots
whose children share the directory name `release-notes`. The earlier input has
a distinct policy and an earlier-only file. The last input has a final policy.
Installed Harbor's resolution selects the last same-name job source, clears the
corresponding bundled directory and uploads the winner before agent setup.

Both sandbox and native manifests contain only the final policy. The task-only
and earlier-only files are absent; the unrelated bundled `fixture-neighbor`
remains unchanged. Neither superseded policy marker appears in the executed
native conversation. Output matches the final policy. Native job-lock provenance
records the winning source and digest; the runner additionally retains both
ordered supplied manifests, so the discarded input remains attributable.

Task/precedence participant prompts, project inputs and agent build sources
match. Their local image IDs differ, with identical filesystem layers and
runtime configuration; each immutable image pin was checked independently.
Job-only intentionally omits bundled context. Policy category/receipt and hidden
grading expectations differ deliberately. This qualifies local delivery and
precedence, not general skill benefit, automatic natural-language routing,
reliability across repeated trials or every skill/context combination. Git
sources, additional instructions and other native configurations remain outside
this concrete V01 qualification.

## Runner changes and controls

The launcher remains a thin native Harbor Job adapter. Its new repeatable local
`--skill` flag records ordered source files, native content digests, the effective
winners and sandbox source location. Harbor still resolves and uploads inputs.
Missing/non-directory or linked local inputs are rejected before job creation.
Supplied-content omissions, changed native files, leftover same-name files or
missing delivery snapshots invalidate the result as an infrastructure error.
The task-only path was also checked against the final receipt implementation
using its retained observations, without another model call.

Five non-model Oracle controls ran through real collection and the separate
verifier: task-good, task-wrong-receipt, job-good, final-policy-good and
superseded-task-policy. The three correct outputs passed; both incorrect outputs
were validly rejected. Oracle omits job injection and does not establish Codex
discovery/use. The verifier parses transferred JSON/text without executing
submitted code; no RewardKit or Worker was required.

In the job-only and precedence live trials, the participant first tried an
unavailable `python` command, then succeeded with the installed `python3`.
Those command failures remain in the trajectories; they required no fixture,
runner, rubric or image correction and no trial retry.

## Final validation and evidence limits

All 21 focused tests pass: nine reporting, four native loading, four ATIF and
four skill-delivery tests. The new cases cover source content/order, missing or
linked inputs, native last-wins resolution and invalid missing/mixed/modified
receipts. Native schemas/layouts, Python syntax, package checks, relative links,
privacy and whitespace checks pass. No packaged skill content changed in I07.

Live trial durations total 123.424 seconds, excluding preparation/review gaps.
Native totals are 187,123 input tokens (169,216 cached) and 2,454 output tokens.
Each trial used a distinct fresh session. Native price metadata is not evidence
of subscription billing.

Complete artifact collection, separate data-only verification, UID 1000, no host
mounts/extra privileges/Docker socket/grader access, host canaries and guest
credential cleanup passed. Agent image IDs were observed; verifier image pins
were retained in native config, without independent image events for each
verifier. Agent networking remains public for inference, with native web tools
and multi-agent disabled; the verifier uses no-network. This increment does not
qualify adversarial or comprehensive network isolation.

Private evidence under `$TEST_EVIDENCE/harbor-i07-2026-11-07` retains all native
jobs, prepared profiles, source manifests, lock provenance, exported data,
individual reviews, comparison inputs and `i07-review.json`. A scoped scan of
304 evidence files found no token-shaped disclosure; it is not exhaustive proof.
Installed-source digests remain unchanged. Owned trial containers/networks are
gone; frozen preparation images remain available.

Final runner SHA-256:
`5b820e4fc9c06363f2142b0661400dfb09b7863c151788a760a13e06264e7082`.
This completes I07's concrete V01 examples. I08, real-project migration and
marketplace release remain separate work.
