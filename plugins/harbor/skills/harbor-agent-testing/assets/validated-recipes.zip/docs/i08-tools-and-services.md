# I08: native MCP tools and Compose services

Completed and individually reviewed 2026-11-07 with GPT-6.1 Sol / High and the
existing ChatGPT subscription. At this checkpoint I09 remained pending; see its
later [network/web results and hosted-app correction](i09-network-and-web-controls.md). These source prototypes are
uncommitted, unpushed, uninstalled and unreleased.

## Reviewed live results

| Case | Full trial duration | Reviewed result |
| --- | --- | --- |
| Task-declared local stdio MCP | 37.347 seconds | Passed; native stock read/reservation and accurate receipt/state |
| Native-config local MCP filter | 37.450 seconds | Passed; allowed tools work and the filter survives native setup |
| Compose Streamable HTTP MCP | 44.302 seconds | Passed; healthy sidecar, native effects and explicit service-state export |

Each result was reviewed before the next scenario. The
[local MCP template](../examples/docker-codex-i08-mcp/README.md) was qualified
first, then its native-config option, then the
[Compose service template](../examples/docker-codex-i08-compose/README.md).
All three live trials passed without trial retries or infrastructure errors.
Native metadata confirms `gpt-6.1-sol`, `high` and guest Codex 0.167.0 in three
distinct fresh sessions. Host Harbor remains 0.25.0, with Docker 29.9.2 on
Linux/ARM64 and normal native ChatGPT sign-in. No key/provider fallback, host
upgrade, installed-Harbor patch, nested model, judge or upload occurred.

## Native registration and actual effects

The local task declares an inventory stdio server in native
`environment.mcp_servers`. The agent reads current stock, reserves three units
for one order using the observed revision, and writes a receipt. Recorded native
MCP calls show both operations, their arguments and successful server results.
Exported data shows stock falling from 12 to 9, exactly one three-unit reservation
and one revision/audit event. Project inputs remain byte-for-byte unchanged.

The local SDK is the official Python MCP SDK pinned to its supported 1.30.0
maintenance line, not the newer v2 API. It runs only inside Docker. The guest
venv uses Python 3.11.2; its resolved 31-package inventory is retained privately.
The same authored inventory behavior runs in the Compose sidecar on Python 3.12.
Local images are frozen after preparation; no host MCP dependency was installed.

Native tool-call records, shell commands and file-change paths were inspected:
participants used the MCP tools and only wrote the requested project receipt.
They did not invoke the calibration client or edit service state/code. The local
fixture includes its model-free protocol client, explicitly disallowed by the
prompt; the Compose reference client is uploaded only for Oracle controls.
Neither setup supplies hidden verifier code or rewards to the participant.
This qualifies the prescribed tool-use path, not resistance to a malicious
agent that edits locally accessible service data or calls a service directly.

## Native-config finding and guarded recipe

An offline check of installed Harbor exposed a concrete precedence trap:
a task-declared MCP server replaces the entire same-name native-config table.
An `enabled_tools` option supplied in that table is discarded. Installed Harbor
was not patched. The fixture launcher now rejects duplicate names across these
two sources and accepts a narrow MCP-only native config, preserving the selected
model, reasoning, authentication, disabled native web and disabled multi-agent.
The filtered variant declares its server only in native config.

A model-free check in a network-disabled Docker container initialized the actual
guest Codex app-server and requested only its MCP catalog. The raw server
advertises three tools; the filtered native catalog contains only
`get_inventory` and `reserve_stock`, excluding the reset canary. No credentials,
thread turn or inference were needed. That result was reviewed before the
filtered live trial, which then performed the real reservation through those
allowed tools. The active MCP process retained only public registration fields
in a receipt, confirming the filter, required-server setting and startup timeout.

The first review incorrectly expected native config to remain at the end hook.
Source/readback established that Harbor deletes the whole temporary Codex home
before that hook, as intended. The review expectation was corrected; successful
native calls establish registration for the baseline and Compose cases. The
filtered fixture captures its public config while that home is active. No
credentials or auth file contents were inspected, copied into these receipts or
left behind, and no model rerun was needed for this review correction.

See the [official Codex MCP settings](https://learn.chatgpt.com/docs/extend/mcp),
[app-server API](https://learn.chatgpt.com/docs/app-server) and
[SDK v1 documentation](https://py.sdk.modelcontextprotocol.io/v1/). The native
catalog allow-list is not a general shell or network access boundary.

## Compose lifecycle and service-state transfer

The Compose task has exactly two services: reserved agent service `main` and
`inventory`. A real HTTP health check gates `main` startup. Both share an
internal fixture network; only `main` also joins the public default network for
inference. Runtime readback confirms that topology, nonroot UID 1000, pinned
image IDs, healthy sidecar, no mounts, extra privileges or published host ports,
and successful isolation canaries at both checkpoints.

The task explicitly declares `/app/service-data` with `service = "inventory"`.
Harbor's native service artifact collection transfers the sidecar snapshot to
the separate no-network verifier. The manifest identifies that service/path;
verification reads the actual inventory state and the agent's receipt. A receipt
without the reservation is rejected. The verifier never executes submitted code.
No Worker, RewardKit, model judge or shared service volume is needed here.

The runner previously assumed one container per trial. It now selects `main` by
its Compose label and checks all declared services independently. Collection
validation also matches both service and source path, preventing a same-path
artifact from `main` from satisfying a sidecar declaration. Its non-Compose
summaries were replayed against retained local results and kept their original
dispositions, without additional inference.

See [Harbor multi-container](https://docs.harborframework.com/tasks/multi-container)
and [environment/MCP configuration](https://docs.harborframework.com/tasks/environment).
Other databases, browser tools, OAuth/credentialed services, custom hooks and
extensions remain outside this concrete qualification. Native config coverage is
limited to the tested MCP option; broader V15 support remains conditional.

## Controls, verification and stopping point

Five non-model Oracle control jobs were reviewed individually. Four executed
real SDK clients: local and Compose correct reservations passed; correct-looking
receipts with unchanged state were validly rejected in each topology. The fifth
used a deliberately failing Compose healthcheck: startup stopped before agent
work, produced an infrastructure error with zero attempted steps and cleaned up.
It is a health-gate control, not evidence of an actual external service outage.
The local grading contract was reused for the filtered case because its prompt,
project inputs and verifier are unchanged.

All 25 focused tests pass: ten reporting/collection, four native loading, four
ATIF, four skill delivery and three MCP configuration tests. Native schemas,
layouts, syntax, source/package checks, links/privacy and whitespace pass. No
packaged skill content changed in I08. The local and Compose participants each
recovered from an unavailable `python` command; these remain recorded and did
not require fixture changes or trial retries.

The live trials total 119.099 seconds, excluding preparation/review gaps.
Native totals are 275,935 input tokens (227,584 cached) and 1,385 output tokens.
Native price metadata is not evidence of subscription billing.

Private evidence under `$TEST_EVIDENCE/harbor-i08-2026-11-07` retains prepared
profiles, image/source pins, native jobs and tool traces, exported state,
individual reviews, SDK inventory, merge/catalog probes and `i08-review.json`.
The scoped token-pattern scan covered 308 evidence files with no findings; it
does not establish protection against every possible disclosure.
Installed-source hashes remain unchanged. Owned containers/networks are gone;
preparation images remain available. Agent networking permits inference with
native web/multi-agent disabled; full egress and adversarial isolation remain
later work. I09, project adoption and marketplace release were not started.

Final runner SHA-256:
`da96b340c9207dbd2abc5ced1bf0ad9e13fd2a7626601023b1c9ed4f41563c1f`.
