# I10: artifact transfer and protected submitted code

Completed 2026-11-08 with the owner's existing approval for native **GPT-6.1 Sol /
High** and ChatGPT subscription authentication. Shared data-only verification was
qualified and reviewed before separate verification; Worker execution followed
both. Every live/control result was inspected before selecting the next case.
No numerical budget gate, provider fallback or automatic trial retry was added.

## Reviewed live cases

| Case | Full trial duration | Result |
| --- | --- | --- |
| Shared data-only verifier | 19.375 seconds | Passed correct receipt, selected collection and isolation checks |
| Separate data-only verifier | 25.578 seconds | Passed correct receipt at original source paths, collection and isolation |
| Separate Worker code grader | 48.907 seconds | Generated code passed both protected inputs; README and trusted files preserved |

All three were fresh native sessions with guest **Codex 0.167.0**, observed
**gpt-6.1-sol / high**, complete collection and successful cleanup. Full retained
rollouts were inspected; no hosted MCP/connector calls occurred. The shared
participant recovered from unavailable `python` using `printf`. The Worker
participant performed public self-checks and added an unrequested `amount`
alias; protected grading qualifies only the specified integer `amount_cents`
contract. No rubric or fixture was changed to obtain a model pass.

## Transfer controls and separate corrections

The payment receipt is declared from `/app/export` with host destination
`receipt-export`; `/app/project` is separately exported. Shared verification
reads the original target filesystem. Separate verification receives only
native declared exports at **source paths**, independently of host destinations.
The deterministic verifier reads JSON and never imports submitted code.

1. Shared good passed; wrong total and omitted receipt were valid quality
   failures through successful directory collection. Missing harness-owned
   collection invalidated native reward 1. An escaping symlink through the
   exclusion path produced failed collection and an infrastructure result.
2. A FIFO was silently skipped while Harbor's manifest remained `ok`; the old
   summary incorrectly passed. Added a source-to-host hash/type receipt using
   GNU tar's actual exclusion selection. Six initial focused tests passed;
   the same FIFO control then became an infrastructure error despite reward 1.
   A separate exclusion control still passed, with `scratch` absent from host
   collection. The first live shared run followed those reviews.
3. Separate good and wrong outputs passed/rejected correctly; missing harness
   collection invalidated reward 1. Without exclusions, an absolute symlink
   reached host collection but Harbor dropped it during verifier upload. Native
   manifest/reward and the first receipt implementation still reported success.
   Added escaping-link validation, checked with focused tests, then reran the
   same control: infrastructure error with the original reward retained.
   Exclusions and the separate live case subsequently passed.

The original false-positive summaries remain untouched. Pre-receipt runs cannot
be retroactively given receipts. The FIFO defect is established by its known
control and fresh corrected run. Reinterpreting retained evidence with the final
summary preserves other dispositions and catches the earlier separate-link
case from its already-recorded receipt; this is readback, not another trial.

One preliminary shared launch had a fixture schema error: explicit shared mode
was combined with `verifier.environment`. Removed that incompatible table before
Docker/model execution. The preparer now emits shared mode directly and the
separate control generator adds its own environment. No installed code changed.

## Released Worker qualification

The [published RewardKit 0.2.4 wheel](https://pypi.org/project/harbor-rewardkit/0.2.4/)
was hash-checked and installed only into a disposable Python 3.12 verifier image.
Its `Worker` implementation matches the
[official release source](https://github.com/harbor-framework/harbor/blob/fdba28fc411e47e8765420a1a063b4918fce3def/packages/rewardkit/src/rewardkit/sandbox.py).
The guest checker verifies version and module bytes before any submitted code.

- Wheel SHA-256: `ff715e9f921e448d5b9e607433a87c1ebb7914191c8334330eecfb99f1b15c59`.
- Worker source SHA-256: `b5d5b5e5eb4abb9fbd8c3238d219f3e25864e674cd2ffe7084e5dfd2fc417144`.
- Qualified verifier image: `sha256:f9d6816f9619276d697af4cf1bdb0253a50533c385f2cb5e00a257b3d1f89221`.

Worker private paths explicitly include `/tests`, `/logs/verifier`, `/grading`
and `/trusted-state`, including references outside Worker's defaults.
No real credentials were supplied to grading. The root verifier holds grading
data while submitted code runs under Worker's fresh UID and receives only
explicit stdin/files.

| Separately reviewed control | Actual result |
| --- | --- |
| Correct submitted program | Both real Worker invocations returned correct outputs; reward 1 |
| Plausible wrong program | Empty input passed, pending amount polluted mixed total; valid reward 0 |
| Interference probe | All nine grading/reference/reward/process-state accesses denied; protection-control reward 1 |
| Invalid private-path setup | Actual symlink refusal raised WorkerSetupError before submission; no reward, infrastructure error |
| Cleanup failure injection | Official cleanup-result failure raised WorkerSetupError; no reward, infrastructure error; container discarded |

The probe verified nonroot UID, zero effective capabilities, empty supplementary
groups, no-new-privs, no inherited parent marker, unchanged trusted bytes and no
surviving live child. It attempted reads of tests, references, another protected
directory and the trusted process's environ/memory/fds, plus grader/reward/score
writes. This is selected attack coverage, not exhaustive isolation proof.

Docker event inspection captured actual agent, verifier and official network
controller specifications during the probe. Agent UID was 1000. The verifier ran
as root with default capabilities only. Neither had privileged mode, added
capabilities, host mounts or published ports. The sole added-capability service
was the unchanged official controller image from I09, with NET_ADMIN/NET_RAW and
no host mounts or published ports. The verifier's relevant private paths were
copied files/directories, not host binds; Docker socket and agent credentials
were absent. I09's DNS/ICMP limitations still apply.

Setup/cleanup exceptions remove any reward and exit with an infrastructure
failure. The runner also rejects an explicit failed `worker_boundary_ok`, even
if a numeric zero is accidentally present; its dedicated reporting test passed
before the cleanup control and final live run.

## Validation, retained evidence and limits

Total: **22 executed Harbor trials: 19 non-model Oracle controls and three native
Codex trials**, plus the one pre-Docker schema-error launch. The two false
transfer passes are retained as discovered defects, not accepted safeguards.
The unsuccessful first Docker-inspection assertion had included Harbor's
network controller; a corrected event capture distinguished the three services
without any trial rerun. Initial and final Worker images were built before
Worker execution as the checker postcondition was finalized.

All **49 discovered source unit tests** and package verification pass, including
11 reporting and 10 receipt checks. Native task layout/schema, Python syntax,
new source links/privacy and whitespace are checked separately. Final summary
readback preserves all three live dispositions. Live totals: **93.859 seconds**,
**127,068 input tokens (118,016 cached), 1,460 output tokens**. Native price
metadata is not ChatGPT subscription billing evidence.

Host Harbor remains **0.25.0**, inspected source hashes remain unchanged, and
RewardKit remains absent from that host environment. Docker is **29.9.2
Linux/ARM64**. Target no-host/no-socket/no-grader canaries, guest credential
cleanup and owned-container/network cleanup passed. Build images remain for
reuse. A scoped token-pattern scan of 568 evidence files found no disclosure;
it is not exhaustive proof against credential leakage.
Evidence under `$TEST_EVIDENCE/harbor-i10-2026-11-07` retains original jobs,
prepared tasks, wheel/source pins, Docker specifications, receipts, raw native
histories, separate reviews and `i10-review.json`.

The receipt covers explicitly declared small snapshots with regular files and
directories. Internal relative links have unit coverage only; special files and
hardlink archive entries are rejected. Large exports, live mutation races,
concurrent graders, arbitrary attack programs and alternate platforms remain
unqualified. No general shared-container security guarantee is claimed. These
limits do not prevent reuse of the qualified regular-file examples.

Source additions are the [transfer recipe](../examples/docker-codex-i10-transfer/README.md),
[Worker recipe](../examples/docker-codex-i10-worker/README.md), receipt companion
and focused tests. The packaged skill and installed plugin **0.3.2** are unchanged
by I10; I14 owns guidance/adoption/release. Nothing was committed, pushed,
installed into the host, uploaded or released. **Stop at I10; I11 remains pending.**

Final runner SHA-256: `bb3943cc385151b62bdfcb058760e2342cecf79c11f8f913c4058bad218d9e9b`.
Receipt companion SHA-256: `8cf2ddf1bc94001628feaf62d0623e61653ab3e98aa19b255969b5a0b1e3eefa`.

Official transfer references: [separate verifier](https://docs.harborframework.com/tasks/separate-verifier),
[artifact collection](https://docs.harborframework.com/jobs/artifact-collection)
and [task artifacts](https://docs.harborframework.com/tasks/artifacts). Installed
source and the recorded runtime evidence remain authoritative for this profile.
