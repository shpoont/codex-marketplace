# I11: subscription Codex judge and regrading

Completed 2026-11-08 with the owner's existing authorization for **GPT-6.1 Sol /
High**, native Codex and ChatGPT subscription authentication. Judge qualification
and each result review preceded regrading. Host Harbor stayed **0.25.0**; guest
Codex was **0.167.0**, RewardKit **0.2.4**. No host package was installed or changed.

## Judge protocol and calibration

The target writes a customer-facing invoice-export incident message. Hidden
trusted grading uses the same approved facts: delayed exports, uncertain recovery,
no observed duplicate charges without a guarantee, no customer retry/action, and
another update at 16:00 UTC even if recovery remains incomplete. A single batched
judge scores accuracy and action as binary mandatory conditions and clarity on
an independent Likert scale. Overall reward requires both mandatory conditions;
clarity cannot compensate for false claims. Guard mode is descriptive `flag`.

| Separately reviewed case | Full trial | Actual outcome |
| --- | --- | --- |
| Known good | 22.972 seconds | Accuracy/action 1; clarity 1; accepted |
| Plausible bad | 25.143 seconds | Accuracy 0, action 1, clarity 0.5; valid rejection |
| Legitimate alternative | 23.635 seconds | Different wording accepted; all dimensions 1 |
| Scoring-instruction injection | 25.272 seconds | Guard flagged; accuracy 0 and valid rejection |
| Fresh target plus judge | 41.235 seconds | Generated message accepted; brief independently confirmed unchanged |

Every scored native judge history confirms **gpt-6.1-sol / high**, read-only
policy and no tool calls. The target used a separate fresh native session with
the same model/effort; its full history contained no hosted connector calls.
Transferred evidence was unchanged by judgment. These examples calibrate this
rubric, not general judge accuracy or injection immunity.

### Authentication and error controls

The installed default test-script path merges verifier environment values into
sandbox execution. Putting raw `CODEX_AUTH_JSON` there would violate the chosen
persistence/argv boundary. The source adapter uses Harbor's supported custom
verifier hook and sends the configured session file handle through `docker exec`
stdin. It neither parses/displays the host credential nor writes a host copy.
RewardKit consumes it in guest memory, forces subscription selection and owns
its temporary native auth home. Cleanup is checked before copying grading logs.

A model-free, network-disabled Docker probe supplied synthetic invalid API-key
canaries alongside the real transient session. The actual Codex backend discarded
the canaries/bridge variables before child execution; native login status
confirmed ChatGPT and its temporary home disappeared afterward. No inference
occurred. No real API key or account switch was introduced.

The guest CLI wrapper adds settings missing from RewardKit 0.2.4's AgentJudge
configuration: read-only mode, disabled web/apps/shell/unified execution and
delegation. Native inference, model/effort and authentication remain in the
released Codex backend. Actual verifier Docker specifications showed the pinned
image, no host mounts, added capabilities, privileged mode or published ports.
The judged data never executes. Worker remains necessary for submitted-code
execution, as qualified separately in I10.

- **Malformed output:** synthetic backend responses passed through the released
  parser/error-retry path without model calls or a credential stream. Final parse
  failure yielded no reward and an infrastructure result.
- **Real timeout:** a one-second Codex judge startup timed out. RewardKit produced
  errored 0.0 values and a warning. The adapter retained those details, removed
  the numeric reward and reported infrastructure failure. The native log had no
  completed turn context or usage; model usage is unknown, not assumed zero.
- **Internal retries:** this release permits three attempts for backend/parse
  errors. Every successful live judgment used the first recorded attempt. Timeout
  was terminal. Job retries remained disabled; no success-seeking reruns occurred.

## Separate implementation corrections

1. A missing message initially caused FileNotFoundError inside the judge recipe,
   producing an infrastructure error despite successful collection. Added
   deterministic submission checks before judgment: omitted message or changed
   brief now receives a valid task zero with the judge marked **not run**. No
   judge-dimension values are invented. The omission was rerun and reviewed;
   changed-brief rejection was then run/reviewed separately. Seven focused
   contract tests cover mandatory gates, partial values, error zeros, warnings,
   duplicate/nonfinite results and submission preconditions.
2. Reporting now records judge authentication and usage separately from target
   authentication/usage. Oracle calibration still invokes a real judge unless
   explicitly skipped/fault-injected. Original records retain their original
   metadata; the first model-free parser protocol's generic authentication label
   was clarified in later source. Its actual bridge used DEVNULL, not credentials.
3. A native missing-export regrade correctly raised RegradeError before sandbox
   setup, but the first report called it infrastructure failure and considered
   two absent artifact directories equal. Fixed input-error classification and
   required actual artifact directories. A fresh no-execution retest confirmed
   input_error, absent artifact evidence and unchanged source bytes.
4. Added a destination guard preventing derived outputs inside the source job or
   task. Both forbidden locations and a separate allowed location passed focused
   checks before closeout.

The new deterministic gates were checked against all retained complete
calibration/target exports and accepted them. They do not alter the earlier
judge criteria/results. Subsequent fresh regrades ran the updated checker. Old
misclassifications and intermediate preparations remain retained.

## Native regrading

The revised trusted rubric, `i11-v2`, changes clarity from three to five anchors;
accuracy/action and all agent-facing inputs/settings remain unchanged. The
regrade preparer builds only the verifier and preserves the original agent image
pin/configuration. Regrading delegates to installed Harbor's native `source_jobs`
mechanism with one concurrent trial and no job retries.

| Retained output | Full regrade | Old → new reward | Evidence review |
| --- | --- | --- | --- |
| Fresh generated message | 17.793 seconds | 1 → 1 | Same artifact bytes; source immutable; zero new target attempts |
| Plausible bad message | 17.923 seconds | 0 → 0 | False guarantees still rejected; clarity remains 0.5 |
| Legitimate alternative | 17.696 seconds | 1 → 1 | Different wording still accepted; source immutable |

Each replay received a separate review before the next. Fresh judge histories
confirm Sol / High, read-only policy, no tools and new native sessions. All source
job files and project export bytes match their before snapshots. Native derived
results reference the original trial; no agent events or execution timing were
created. Harbor copies original `agent_info`/`agent_result` into derived records;
those historical token counters are explicitly excluded from new target usage.

Missing-export controls used a disposable source clone, preserving the original.
The corrected rejection occurred before environment setup or verification, with
no agent/judge call. A shared-mode updated task was rejected at derivation
preflight, again without Docker/model execution. No fallback rerun or conversion
to shared verification occurred. Workflow/step regrading is not qualified here.

The first two regrades used the manually prepared v2 verifier; the alternative
used the reusable verifier-only preparer. Both pin their own immutable image
IDs and have matching relevant checker/rubric/backend bytes. This is not a claim
that the Docker image IDs are identical.

## Validation and accounting

All **58 source unit tests** and unchanged Harbor plugin **0.3.2** package checks
pass. Native task schemas/layouts, Python syntax, new source links/privacy and
whitespace are checked at closeout. Recorded installed-source hashes remain
unchanged; RewardKit remains absent from the host Harbor environment.

Execution comprises ten original Harbor trials (nine Oracle target controls,
one actual Codex target), five native regrade trials (three scored and two
missing-export attempts), one preflight-only shared rejection and one standalone
model-free Docker auth probe, plus model-free version/image checks.
One missing-export attempt predates the reporting
repair. All are retained. Full trial time totals **273.147 seconds**, excluding
preparation, review gaps and the auth probe.

There were **eight completed valid judge calls**, plus one timed-out startup with
unknown usage. Known judge totals: **89,856 input tokens, 9,088 cached, 1,685
output**. The single new evaluated target used **46,173 input tokens, 41,856
cached, 295 output**. Regrading added **zero evaluated-agent attempts**. These
are separate role counters, not subscription billing evidence; RewardKit's price
figures are estimates. Judge samples remain one per case, with no reliability
or population-quality estimate claimed.

Private evidence under `$TEST_EVIDENCE/harbor-i11-2026-11-08` contains original
jobs/errors, immutable image/source/rubric pins, Docker specifications, judge
scores/warnings, full histories, auth probe, source snapshots, separate reviews
and `i11-review.json`. Scope limits include small regular-file snapshots,
single-step text judgment, selected injection/error examples and selected
regrading. Conversation/trajectory judges, numeric/rubric formats beyond this
binary/Likert example, scoring trees, concurrent/isolated agent judges and
multistep regrading remain unqualified. No full egress or injection-immunity
claim follows from these tests.

Final readback found no owned containers or networks. A scoped pattern scan of
571 retained evidence files found no token-shaped disclosure or retained
`auth.json`; this is not exhaustive leakage proof. No API-key/base-URL routing
variables were set at closeout. Prepared images and original evidence remain.

Source recipe: [Docker judge and regrading](../examples/docker-codex-i11-judge/README.md).
The packaged skill and installed plugin are unchanged by I11. Source remains
uncommitted/unpushed, uninstalled and unreleased. **Stop at I11; I12 remains pending.**

Official mechanics: [judge criteria](https://docs.harborframework.com/rewardkit/judge-criteria),
[custom verifiers](https://docs.harborframework.com/jobs/custom-verifiers) and
[regrading](https://docs.harborframework.com/jobs/regrade). Installed Harbor,
released RewardKit bytes and recorded runtime evidence govern this profile.
