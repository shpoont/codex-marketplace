# I12: Exec map, reducer and imported reference task

Completed 2026-11-08 using **GPT-6.1 Sol / High**, native Codex and the owner's
existing ChatGPT subscription. Map-only was validated and reviewed before the
reducer; reducer results were reviewed before the imported benchmark. Host
Harbor stayed **0.25.0** and guest Codex **0.167.0**. RewardKit remains absent
from the host Harbor environment. No installed package or plugin changed.

| Separately reviewed native case | Full trial | Result |
| --- | --- | --- |
| Exec map-only | 29.716 seconds | Correct paid-order summary; input unchanged; no reducer started |
| Exec reducer | 33.803 seconds | Correct totals and exact source SHA-256; reviewed map not rerun or changed |
| Imported Terminal-Bench log summary | 58.171 seconds | Both original pytest tests pass; all 15 rows match original reference semantically |

All three ran in distinct fresh sessions with observed `gpt-6.1-sol / high` and
UID 1000. Native histories contain no hosted connector calls or delegation.
Actual Docker specifications/canaries, complete hash/type collection receipts,
separate verifier credential checks and owned-resource cleanup passed.

## Map-only and separate corrections

The map compiles one instruction and a focused CSV snapshot through native
`Executor.execute()` with no reduce configuration. Paid orders include a refund;
pending money is excluded. A known-good Oracle and a plausible 7,300-versus-5,000
cent error calibrate semantic grading through real transfer.

1. The first good Oracle could not write because native loose upload retained
   host UID/GID. Its original failed score remains intact and is classified in
   the review as a setup defect, not participant-quality evidence. Added a
   narrowly scoped ownership repair after verifying the container has no host
   mounts. It refuses links/special entries and independently verifies unchanged
   bytes/modes. The corrected Oracle passed before the bad control and live map.
2. Native Exec serialization redacted a literal auth-file path before job
   creation, causing preflight failure without a Docker/model trial. Two focused
   tests establish masking and the native placeholder mechanism. The launcher
   supplies the same configured path only in its process environment and saves
   `${CODEX_AUTH_JSON_PATH}`. The fresh native map then passed. Installed Harbor,
   credential contents, account/provider and reasoning settings were unchanged.

## Reducer and lineage

The reducer receives the reviewed map's native exported artifact tree. The
launcher refuses semantically failed maps and changed receipt/URI lineage before
startup; both controls were tested separately without model calls. A tampering
control used a disposable source clone, preserving the original.

To honor the review checkpoint, the launcher invokes installed native
`_compile_reduce_task()` and `_run_job()` on the retained result rather than
rerunning `Executor.execute()`. It rehydrates the actual per-trial records because
aggregate job JSON excludes them. Full staged bytes/types must equal the source
tree. The trusted checker requires correct totals and the exact analysis-file
hash. Final source artifacts still match the original receipt.

3. The first reducer bootstrap found missing staged inputs before any agent
   execution: a stale template Dockerfile suppressed loose-artifact upload with
   a prebuilt image. Removed that unused Dockerfile without changing image pins.
   Also repaired reporting that had masked the native exception when observation
   files were absent. Two focused installed-rule checks pass. The good Oracle
   then passed; correct totals with forged lineage were validly rejected before
   the native reducer. Original bootstrap records are retained.

The live trace reads the supplied `analysis.json`, derives totals and hashes
its exact bytes. It does not reconstruct the result from an original CSV. Map
input/output is unchanged and no map session is rerun. This qualifies one map
and an explicit reviewed reducer checkpoint. Fanout, the automatic combined
pipeline and future internal API compatibility remain unqualified.

## Imported task with its original solution

Imported `legacy/log-summary-date-ranges` from official
`harbor-framework/terminal-bench` commit
`cfc7b6c66f2c731e4b70d92ee71ee5d6d3b55b64`. Nine original files were checked by
Git blob and SHA-256. Instructions, deterministic generator, reference solution,
pytest assertions and original driver remain unchanged. Preparation only adapts
execution, image pins and transfer; the wrapper retains the original driver as
`upstream-test.sh` and adds credential checks without rewriting reward.

The task's fixed date is **2025-08-12**. It summarizes 164 generated log files
into ERROR/WARNING/INFO counts across five date ranges. DEBUG is excluded, and
a WARNING containing the word ERROR must remain a warning.

4. The reference's inspected `apt-get` requires root, whereas our participant
   profile requires nonroot. Added an explicit **trusted Oracle only** Docker
   role; selecting Codex with that exception is rejected before startup. The
   observer now checks the configured effective container user as well as its
   executed UID. The unchanged root reference passed both original tests; a
   well-formed CSV with one wrong count was validly rejected; then nonroot live
   Codex passed. The actual grader filename is included in absence canaries.
5. Removed reporting's invented `/app/project` requirement: required exports
   now follow the native task/step declaration. Two focused checks establish
   that `/app` is valid and a missing declared export remains invalid. Exporting
   the parent directory lets a missing answer receive the original task's zero
   rather than manufacturing a missing-file collection failure.

Root was measured only for trusted reference calibration and separate grading;
live Codex stayed UID 1000. The data-only grader reads CSV and never executes a
submission. All 15 live rows match the canonical reference semantically. Codex
corrected an initial DEBUG parsing assumption within the same attempt; no
harness/rubric change or success-seeking retry was needed. Upstream package
downloads remain public and not fully dependency-locked. One task/reference is
qualified; other benchmarks and multiple-reference selection remain unqualified.

## Validation, accounting and stop

All **62 source unit tests**, unchanged public plugin **0.3.2** verification,
native task schemas/layouts, Python syntax, new source links/privacy and
whitespace checks pass. All 13 recorded installed-source digests are unchanged.
The inherited baseline's old runner-before field is explicitly annotated;
the I12 entry hash is verified against the retained I11 final source snapshot.

There are **11 native trials**: three actual Codex attempts, seven executed
Oracle controls (including the first map setup failure), and one reducer
bootstrap with no agent execution. Four additional pretrial controls cover auth
serialization, failed map, tampered map and forbidden root Codex. There were no
judges, nested models, job retries, API-key/provider fallbacks or uploads.

The three live trials total **121.690 seconds**, with **179,211 input tokens,
166,144 cached and 2,681 output**. All native trials total **227.716 seconds**,
excluding preparation, reviews and preflight. Native price metadata is not
subscription billing evidence. These are functional examples, not a reliability
or population-quality estimate.

Private evidence under `$TEST_EVIDENCE/harbor-i12-2026-11-08` retains immutable
pins, originals, all failures, native results/histories, Docker specifications,
receipts, per-case reviews and `i12-review.json`. Final readback found no owned
containers or networks. A scoped scan of 477 retained files found no token-shaped
disclosure or retained `auth.json`; this is not exhaustive leakage proof.

Recipes: [Exec map/reducer](../examples/docker-codex-i12-exec/README.md) and
[imported task](../examples/docker-codex-i12-import/README.md). Tracking details are maintained separately from this package.
Source remains uncommitted/unpushed, uninstalled and unreleased. The packaged
skill is unchanged by I12; I14 owns guidance/adoption/release. **Stop at I12;
I13 remains pending.**

Official mechanics: [released Exec implementation](https://github.com/harbor-framework/harbor/blob/fdba28fc411e47e8765420a1a063b4918fce3def/src/harbor/exec/executor.py),
[released Exec configuration](https://github.com/harbor-framework/harbor/blob/fdba28fc411e47e8765420a1a063b4918fce3def/src/harbor/models/exec/config.py),
[original benchmark](https://github.com/harbor-framework/terminal-bench/tree/cfc7b6c66f2c731e4b70d92ee71ee5d6d3b55b64/legacy/log-summary-date-ranges)
and [reference solutions](https://docs.harborframework.com/tasks/solution).
Installed-version checks and measured runtime evidence govern this profile.
