# I13: unsupported modes and adaptive-simulation feasibility

Rechecked and individually reviewed 2026-11-08. The selected profile remains
**Docker + native Codex + GPT-6.1 Sol / High + existing ChatGPT subscription**.
No inference was necessary: these findings concern explicit startup/configuration
boundaries. Zero target, simulated-user or judge calls were made. Installed
Harbor remains **0.25.0**; nothing was installed, upgraded or patched.

## Separately validated findings

| Finding | Fresh installed-runtime evidence | Reviewed disposition |
| --- | --- | --- |
| C06: adaptive simulated user | Both auth-path/force-auth connection guards reject subscription; actual ACP install method rejects before environment operations; only ACP bridge exists. Both role configs parse and Sol / High is expressible. | Blocked in Harbor's target-auth integration. User-role native support does not fix the target. |
| R04: run-level history plus simulator | Actual TrialConfig rejects native and ATIF paths with user_agent; either configuration separately parses. | Still blocked. This does not qualify task-bundled history with simulation. |
| R05: multi-step plus simulator | Actual MultiStepTrial constructor rejects before parent trial initialization; ordinary ordered-step config parses. | Still blocked independently of subscription. Fixing C06 would not fix this combination. |
| R01: Windows Codex tasks | Capability is false; actual trial validator rejects Windows and accepts the same Linux configuration. | Still blocked. Another Docker provider cannot supply missing agent support. |
| R02: host CLI handoff | Capability is false; inherited method rejects; actual CLI rejects a synthetic Codex trial before handoff mutation or process exec. | Still unsupported. Host handoff would also leave Docker. I05/I06 loading into a new Docker trial remains a distinct qualified operation. |
| R03: selected-step startup | Task/trial/job schemas have no start_step; actual CLI rejects --start-step during parsing. | Still future work upstream. Session resume and completed-job reuse do not select an arbitrary step. |
| V08: direct API/provider route | Generic resolver selects no API key from synthetic native auth-file settings; actual LiteLLM preflight rejects that public-provider connection. A synthetic key-presence control parses without authentication. | Outside the agreed profile. This is one API-route example; other agents do not universally require API keys. I11 native Codex judging remains available. |

Each finding received its own retained review before the next. Final probe source
reproduced all **24 checks across seven groups**, reviewing each group before
proceeding. These are expected compatibility rejections, not participant failures
or quality zeros. No successful adaptive conversation, Windows run or handoff is
claimed.

## Current official evidence

The latest release is still
[v0.25.0](https://github.com/harbor-framework/harbor/releases/tag/v0.25.0), published
2026-10-25. Official main was pinned to
[`2bc1a23bd961de0bec8742940f35ac9070c67815`](https://github.com/harbor-framework/harbor/commit/2bc1a23bd961de0bec8742940f35ac9070c67815),
dated 2026-11-07. It retains the reviewed restrictions and was inspected as data,
never installed or executed. Twenty-one official source/reference files were
verified against their Git blobs. Installed Codex integration bytes match the
official 0.25.0 file exactly.

The [simulation guide](https://docs.harborframework.com/jobs/simulate-a-user)
lists Codex as an ACP target without qualifying that statement by authentication
route. The [actual integration](https://github.com/harbor-framework/harbor/blob/2bc1a23bd961de0bec8742940f35ac9070c67815/src/harbor/agents/installed/codex.py)
rejects ChatGPT auth-file selection in connection resolution and acp_install().
Its ACP command requests api-key authentication; its ACP environment delivers a
selected API key rather than a native sign-in. The ordinary native-exec
credential path is not an ACP credential-delivery path. Removing the guard alone
would leave these dependencies unresolved.

The [handoff guide](https://docs.harborframework.com/jobs/handoff) still limits
handoff to Claude Code and restores history rather than sandbox files. The
[multi-step guide](https://github.com/harbor-framework/harbor/blob/2bc1a23bd961de0bec8742940f35ac9070c67815/docs-mintlify/tasks/multi-step.mdx)
still labels selected-step startup as coming soon. Targeted Harbor issue/PR
searches found no verified subscription-ACP fix; this is not an exhaustive claim
about every discussion or unmerged branch.

## Adaptive simulation: a narrower opportunity

Harbor pins **@agentclientprotocol/codex-acp 1.12.0**. Published npm metadata
points to source commit
[`a7afd2ae077d625710194d9701b83595494449de`](https://github.com/agentclientprotocol/codex-acp/tree/a7afd2ae077d625710194d9701b83595494449de).
That adapter already [documents ChatGPT authentication](https://github.com/agentclientprotocol/codex-acp/blob/a7afd2ae077d625710194d9701b83595494449de/README.md).
Its [client checks an existing Codex account](https://github.com/agentclientprotocol/codex-acp/blob/a7afd2ae077d625710194d9701b83595494449de/src/CodexAcpClient.ts)
with account/read; the server requests authentication only when needed. This is
source evidence of a plausible route, not a successful compatibility test.

**Recommendation:** prefer a focused upstream Harbor auth integration that
reuses the existing ACP bridge. If adaptive simulation is needed before upstream
ships it, qualify a separately named, opt-in project-local Codex adapter
extension. Keep installed Harbor unchanged. The demonstrated gap does not
justify a new conversation engine or parallel case format.

The candidate needs to address these dependencies:

- Select subscription deliberately in bridge preflight and command/env handling.
  Remove API-key/default-auth fallback for that selected route. Failed existing
  sign-in must not silently start browser/device login or select another account.
- Deliver the existing configured sign-in transiently to the target's private
  ACP home with correct ownership and cleanup on success/error/timeout. Reuse
  established credential handling where applicable; keep raw contents out of
  argv, saved job config, images, exports and model prompts.
- Confirm both roles' actual Sol / High and subscription selection. Record
  target/user sessions, usage and errors separately. Set web/apps/delegation
  controls explicitly rather than inheriting bridge defaults.
- Qualify the exact binaries. The adapter bundles Codex **^0.154.0**, while this
  profile pins **0.167.0** through supported CODEX_PATH. Source inspection does
  not establish that protocol pairing's compatibility.
- Preserve attribution: both roles share a container/workspace. A prompt asking
  the user agent not to solve the task is not an enforced filesystem boundary.
  Verify that target work earned the score and assess whether the intended claim
  requires stronger role separation. Hide grading material from both roles.

This is more than a one-line guard removal. Maintenance would cover the custom
adapter's connection/install/command/env/teardown behavior, pinned ACP/CLI
compatibility and Harbor-upgrade checks. It would not automatically enable
history-plus-simulator, multi-step simulation, Windows or host handoff.

### Proposed qualification order, not implemented

1. Model-free Docker checks for pinned binaries, protocol initialization,
   existing-account recognition, API-key precedence canaries and cleanup after
   missing/invalid auth and forced failures. No new login/account selection.
2. One real single-step adaptive case with both roles on Sol / High and the
   existing subscription. The target asks for missing information; the user's
   reply depends on the target's actual words/actions. Trace attribution and
   deterministic output verification establish who completed the work. Review
   before proceeding.
3. A distinct correction case and a timeout/error case, reviewed separately.
   Preserve incomplete work and infrastructure failures. Broader combinations
   remain separate work.

These are proposed tests for a changed integration, not standing gates for
ordinary project cases. No extension, provider change or guard bypass was made
in I13. Agree that implementation separately before use. Scripted messages
remain scripted; they are not relabeled as adaptive support.

## Validation and stop

`tooling/check_unsupported_modes.py` runs one named group at a time against
installed Harbor and writes fresh evidence outside source Git. During probes it
forbids network connections, subprocess/exec operations and auth.json reads.
Synthetic role/environment objects stop at real guard methods; they do not
substitute for successful model or Docker execution.

Two initial selected-step probes encountered command-completion telemetry. The
first lacked counters; its evidence limit is retained explicitly. The second
recorded the blocked subprocess. The first direct-provider probe had a variadic
resolver-stub error and a blocked LiteLLM price-map lookup. Corrected the stub
and used supported process-local HARBOR_TELEMETRY=0 and
LITELLM_LOCAL_MODEL_COST_MAP=True. These affect probe metadata, not credentials
or inference. Failures are retained; final probes attempted no forbidden action.

Existing **62 source unit tests**, unchanged public plugin **0.3.2** verification,
Python syntax, local links/privacy and whitespace checks pass. All 13 recorded
installed-source digests are unchanged. Private evidence under
`$TEST_EVIDENCE/harbor-i13-2026-11-08` retains per-finding results/reviews,
failures, official byte checks, final probes and i13-review.json.

Source remains uncommitted/unpushed, uninstalled and unreleased. The packaged
skill and installed plugin are unchanged by I13. **I13 feasibility is complete;
I14 and adaptive-extension implementation remain pending.**

At this checkpoint the extension was only proposed. The subsequent separately
authorized [implementation and qualification](subscription-acp-qualification.md)
adds opt-in single-step examples; the installed/default restriction remains.
