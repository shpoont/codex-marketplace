# Opt-in subscription ACP: implemented and qualified examples

Completed 2026-11-08 following separate owner authorization after
[I13 feasibility](i13-unsupported-mode-feasibility.md). Installed Harbor stays
**0.25.0**, guest Codex **0.167.0**, ACP adapter **1.12.0**, ACPX **0.11.2** and
both model roles **GPT-6.1 Sol / High**, using the existing ChatGPT subscription.
This is a source-only extension; installed Harbor and plugin **0.3.2** are unchanged.

## Reviewed outcomes

Model-free Docker checks preceded all adaptive inference. Every control and
live result was reviewed before the next scenario.

| Case | Full trial | Reviewed result |
| --- | --- | --- |
| Adaptive clarification | 51.196 seconds | Target asked for missing time/timezone; user answered its actual question; target alone wrote the correct daily schedule |
| Adaptive correction | 81.045 seconds | Target wrote 08:00 Europe/Berlin, then changed it to 17:15 Europe/Lisbon after the user corrected the completed work |
| Early controller timeout | 15.260 seconds, including setup/cleanup | Actual 2-second agent timeout before a target prompt; unscored execution error, partial user session, complete cleanup |

Both successful cases have separate native target/controller sessions, actual
Codex 0.167.0 and Sol / High metadata in each role, and observed UID 1000 for
both processes. Target turns stay in the same session within each conversation:
two completed turns for clarification, three for correction. The controlling
user only sends ACP prompts and polls; target histories show the project writes.
No cross-role history retrieval, external connected-source action or extra
model/delegation call was observed. Separate data-only grading and complete
hash/type artifact collection passed.

The correction target also tried a native form helper, which returned
`unsupported_client`, and a native asynchronous question helper. It then supplied
the question as ordinary ACP text; the simulated user answered it without human
intervention. Those helpers are recorded explicitly, rather than described as
connected-account app actions or silently omitted.

## Integration and safeguards

`tooling/subscription_codex_acp.py` adds the named `SubscriptionCodexACP` target
and a scoped subclass of Harbor's existing ACP bridge. It uses supported bridge
registration in the launcher process and restores the previous registration on
exit, including errors. Default Codex's subscription/ACP rejection remains intact.
No installed function or source file is patched.

The bridge reuses native configuration, session management, export and teardown.
Its setup verifies the three prebuilt binary pins instead of repeating runtime
npm installation. `CODEX_PATH` selects 0.167.0 rather than the adapter's bundled
dependency. Installed version/source identity and actual Docker image/user pins
are checked before credential delivery.

The existing configured sign-in is consumed through native scoped transfer into
a private target home with UID 1000, directory mode 700 and auth-file mode 600.
The extension never parses the host credential or creates another host copy.
Native guest login status must identify ChatGPT. API-key/base-URL/default-auth
variables are removed from the target process; no API/provider/account fallback
or implicit interactive login is permitted. The native controller uses its own
temporary Codex home. Credentials are removed before collection and grading.

Measured model containers have no host mounts, Docker socket, added capabilities,
privileged mode or published ports. Both models run nonroot. Trusted setup uses
root only for owned guest directories/configuration. Public networking permits
subscription inference; this is not a complete egress-denial claim. Web/apps/
delegation settings are explicit. Native histories are screened and reviewed;
the literal-call screen is reporting, not an adversarial capability filter.

Both roles share a workspace and UID. The observed attribution above does not
establish enforced role filesystem separation. Hidden grading is in a separate
verifier and never executes submissions, so Worker is unnecessary for this JSON
grader. Native account-supplied instructions/skill descriptions can still appear
in model context; filesystem isolation does not establish a context-free account.

## Model-free checks

- Exact binaries initialize ACP in network-disabled Docker. Missing authentication
  refuses session creation with no authenticate or prompt request. The initial
  probe omitted the temporary Codex directory; creating that directory corrected
  the fixture, with original failures retained.
- A native Harbor `install_only` job opens a session using the existing ChatGPT
  sign-in, including synthetic API-key precedence canaries, then removes its
  temporary credentials. No model agent phase runs.
- Missing, malformed and API-key-only auth documents are separately refused.
  There is no login/API fallback. Synthetic credential controls are distinct from
  normal launcher preflight, which checks the real configured file before Docker.
- A controlled failure and a real asyncio timeout occur after an actual transient
  auth file is verified as UID 1000/mode 600. Both remove it and clean up Docker
  without inference. Native timeout classification is retained as an error.
- Known-good output is accepted and plausible wrong output rejected for each
  adaptive task through real collection/separate grading. Leaving the initial
  correction settings is rejected as incomplete final work.

## Separate corrections and validation

1. Host Codex login status writes to stderr. The first launcher checked stdout
   alone and stopped before Docker. Corrected the status check; the setup-only
   retest passed without changing credentials or route.
2. Native `agent_result` in simulated-user mode contains the **controller's**
   usage. Added per-role native-history counters and checked them against both
   real histories. Final cumulative counters are not summed across snapshots;
   missing counters stay unknown.
3. The initial reporting screen treated any `mcp__` substring as a connected
   call. It flagged tool-metadata discovery and the native question helper despite
   a correct correction result. Separated literal invocations, native question
   helpers and connected/delegated calls. Three focused checks and both retained
   histories validate the fix. Original flagged reports remain intact; derived
   reviewed reports identify the correction. No runtime permission was widened
   and no inference rerun was needed.
4. The real early timeout retained a native verifier zero. Reporting now keeps it
   as `native_rewards` and exposes no valid reward for an execution error. Tests
   distinguish that case from a valid task zero, without altering native results.
5. Deleting the mandatory README initially crashed the clarification grader after
   complete transfer. Reproduced it with an Oracle control, handled missing-file
   reads as criterion failure, then reviewed the same rejection and a good control
   separately. The agent image and criteria stayed fixed. Fresh verifier pins
   differ from the original live run; old evidence retains its original scope.
6. Final inspection found the launcher ownership matcher could miss the exact
   main project name because it added a second suffix. Fixed the matcher, checked
   actual main/verifier naming and unrelated lookalikes, then read back all actual
   trial identities. No owned containers or networks remain. Original reports
   are preserved; the final readback uses the corrected matcher.

All **78 source unit tests**, unchanged public plugin **0.3.2** verification,
syntax, native task schemas/layouts, local links/privacy and whitespace checks
pass. All 13 recorded installed-source digests remain unchanged. These include
the unchanged default Codex integration; the extension requires its own explicit
import path and launcher scope.

## Accounting, timing and limits

Execution comprises **17 native Harbor trials**: seven model-free setup controls
(including one repeat), seven Oracle controls, two completed adaptive trials and
one incomplete controller-timeout trial. Four standalone network-disabled ACP
probe launches and one standalone binary probe also ran. Initial fixture/status
failures are retained. No judge, nested model, automatic job retry, API fallback,
upload or host installation occurred.

Known completed-role usage:

| Role | Input tokens | Cached input | Output tokens |
| --- | --- | --- | --- |
| Target | 360,584 | 312,192 | 1,994 |
| Simulated user | 258,356 | 244,096 | 899 |

The timed-out controller's usage is **unknown**, not zero; it produced no
completed model/effort context, and no target prompt began. Successful adaptive
trials total **132.242 seconds**; all three agent-phase trials total **147.502
seconds**, including setup/cleanup. Native price estimates are not subscription
billing evidence. One sample per distinct case is not a reliability estimate.

One synthetic missing-auth control recorded **956.697 seconds** of wall time,
mostly Docker environment startup, despite no inference. An immediate controlled
repeat took **5.011 seconds**, with **0.972 seconds** of Docker startup. The
outlier did not recur; its cause remains unresolved. All native wall durations
sum to **1,210.981 seconds**, including that outlier and excluding preparation/
review. Do not treat this sum as a steady-state latency benchmark. No host
diagnostic or configuration detour was made.

Private evidence under `$TEST_EVIDENCE/harbor-acp-subscription-2026-11-08` retains
original failures, all image/source pins, native histories, per-result reviews,
receipts, process/UID observations, derived reports and qualification-review.json.
A scoped scan of 415 retained files found no token-shaped disclosure or retained
auth.json; this is not exhaustive leakage proof. Later final readback checks the
expanded evidence set as recorded in that file.

The result qualifies the two single-step adaptive examples and selected cleanup/
error boundaries. It does not qualify multi-step simulation, history/simulator
combinations, mid-target-turn timeout recovery, concurrency, long-running token
refresh, other platforms/versions or adversarial role separation. Installed
built-in support remains blocked. No broader supported-mode claim follows.

Recipe: [source example and commands](../examples/docker-codex-acp-subscription/README.md).
Source remains uncommitted/unpushed, uninstalled and unreleased. **Stop here;
I14 plugin guidance, adoption and release remain pending.**
