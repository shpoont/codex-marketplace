# Opt-in ChatGPT subscription ACP integration

This source-only recipe adds a separately named target,
`subscription_codex_acp:SubscriptionCodexACP`, and a scoped subclass of Harbor's
existing ACP bridge. It leaves installed Harbor and the packaged plugin unchanged.
The launcher uses Harbor's supported bridge registration API only within its
process and restores the previous registration afterward.

Qualified profile: **Harbor 0.25.0**, **Codex 0.167.0**, **codex-acp 1.12.0**,
**ACPX 0.11.2**, Linux/ARM64 Docker and **GPT-6.1 Sol / High** for both roles,
using the existing ChatGPT sign-in. The adapter checks installed source identity
and guest pins; upgrading requires requalification. It accepts no endpoint/key
fallback or implicit browser/device login.

## Repeat a qualified case

Set `HARBOR_PYTHON` to the installed Harbor environment's Python and
`TEST_EVIDENCE` to a new evidence root outside Git. Keep runtime/CLI directories
on PATH. Run these commands from this repository; every output must be new.

```sh
"$HARBOR_PYTHON" examples/docker-codex-acp-subscription/prepare.py \
  --output "$TEST_EVIDENCE/clarification-profile"
```

Read that preparation's `images.json`. Use its immutable **agent** image ID:

```sh
"$HARBOR_PYTHON" tooling/run_subscription_acp.py \
  --image sha256:REPLACE_WITH_PREPARED_AGENT_ID \
  --task "$TEST_EVIDENCE/clarification-profile/clarification" \
  --output "$TEST_EVIDENCE/adaptive-clarification"
```

The simulated customer withholds time/timezone until the target asks. It replies
to the target's actual question; the target creates a local draft JSON schedule.
Review the native conversation and work attribution alongside `summary.json`,
`role-evidence.json`, isolation/transfer receipts and separate verifier checks.
An output-only reward does not establish adaptive interaction.

After that review, prepare the correction case while reusing the same agent image:

```sh
"$HARBOR_PYTHON" examples/docker-codex-acp-subscription/prepare.py \
  --case correction --agent-image sha256:REPLACE_WITH_PREPARED_AGENT_ID \
  --output "$TEST_EVIDENCE/correction-profile"
"$HARBOR_PYTHON" tooling/run_subscription_acp.py \
  --image sha256:REPLACE_WITH_PREPARED_AGENT_ID \
  --task "$TEST_EVIDENCE/correction-profile/correction" \
  --output "$TEST_EVIDENCE/adaptive-correction"
```

Here the user introduces changed preferences after the target actually creates
the initial file. The final grader rejects leaving the intermediate settings.
Job retries are disabled. Expected task rejections and errors return status 1;
retain their evidence rather than rerunning until success.

## Model-free integration checks

The launcher's setup mode omits `--task` and uses native `install_only`. It opens
an ACP session but sends no model prompts and disables verification. Its
`setup_passed` field is a setup result, not a participant-quality score.

```sh
"$HARBOR_PYTHON" tooling/run_subscription_acp.py \
  --image sha256:REPLACE_WITH_PREPARED_AGENT_ID \
  --output "$TEST_EVIDENCE/setup-good"
```

Maintainer controls add `--control missing`, `malformed`, `api-auth`, `failure`
or `timeout`, one per fresh output directory, reviewing each before proceeding.
The last two verify an actual UID-1000, mode-600 temporary auth file exists,
then inject failure/timeout before inference. These are integration qualification
controls, not requirements to repeat before every ordinary project test.
`probe_rpc.mjs` separately checks ACP initialize/session creation without sending
`session/prompt` or `authenticate`; it can run in network-disabled Docker.

## Authentication, evidence and limits

- The configured sign-in is consumed by native scoped file transfer into a
  private guest ACP home. It is never parsed here or copied to another host file.
  Raw credentials do not enter argv, saved config, images, prompts or exports.
  A native guest login-status check must identify ChatGPT. API routing/default
  auth variables are removed from the target process. Both roles clean their
  private credentials before evidence collection and grading.
- Model processes were observed as UID 1000, with no host mounts, socket, extra
  capabilities, privileged container or published ports. Trusted setup can use
  root for private-directory ownership. Networking permits subscription calls;
  this is not an offline or complete egress-denial profile.
- Web/apps/delegation settings are explicit. Literal connected-tool/delegation
  calls are screened in native histories and reviewed. Native question helpers
  are recorded separately from connected apps; the observed form attempt returned
  `unsupported_client` and the target supplied a text question. This screen is
  reporting, not an adversarial code parser or capability-enforcement mechanism.
- Native `agent_result` contains the controlling **user's** usage in this mode.
  Each role's own final cumulative history supplies its counters; cumulative
  snapshots are never summed. Native prices are not subscription billing.
  Incomplete usage remains unknown. Infrastructure rewards are exposed only as
  `native_rewards`; valid `rewards` is null for an execution error.
- The two roles share a workspace and UID. The tested user only sent prompts and
  polled; target traces show the file writes. This is observed attribution, not
  enforced role filesystem isolation. Hidden grading stays in a separate data-only
  verifier, which never executes submissions. Worker is not needed for this JSON
  grader. Account-supplied instructions may still appear in native context;
  Docker filesystem isolation does not establish a context-free account.

The built-in Codex ACP route still rejects subscription auth. This extension
qualifies selected single-step adaptive cases only; history/simulator and
multi-step/simulator combinations remain blocked. Windows, host handoff, arbitrary
selected-step startup, concurrent/long-running simulations, token-refresh races
and other adapter/CLI versions remain unqualified.

See the [qualification record](../../docs/subscription-acp-qualification.md).
Upstream basis: [Harbor Codex integration](https://github.com/harbor-framework/harbor/blob/fdba28fc411e47e8765420a1a063b4918fce3def/src/harbor/agents/installed/codex.py),
[ACP bridge](https://github.com/harbor-framework/harbor/blob/fdba28fc411e47e8765420a1a063b4918fce3def/src/harbor/bridges/acp.py)
and [adapter 1.12.0](https://github.com/agentclientprotocol/codex-acp/tree/a7afd2ae077d625710194d9701b83595494449de).
