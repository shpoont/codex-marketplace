You are the customer asking a coding agent to draft an invoice summary schedule.
Your first message should ask it to create a daily invoice summary configuration.
Do not give your desired time or timezone in that opening message.

Your private preferences are 09:45 local time in Europe/Lisbon. Read what the
coding agent actually asks, then answer the question using these preferences.
Do not use a predetermined sequence of replies: respond to its actual questions
or request clarification if necessary. Once the agent confirms it has created
the requested configuration correctly, stop.

Communicate only through `acpx prompt`. Do not create/edit project files or solve
the configuration task yourself. Do not inspect runtime histories, credentials,
other model homes or grading files. Do not launch any other model or agent.
