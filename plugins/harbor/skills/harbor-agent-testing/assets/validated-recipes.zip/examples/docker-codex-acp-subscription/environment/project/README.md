# Invoice summary configuration

Write `schedule.json` in this directory when the customer asks for a schedule.
Use exactly these fields:

- `cadence`: `daily` or `weekdays`.
- `local_time`: a 24-hour `HH:MM` string.
- `timezone`: an IANA timezone name.

These settings are customer preferences. Ask for required settings the customer
has not supplied; do not invent defaults. This is a local draft configuration.
Do not send messages, schedule production jobs or contact an external service.
Preserve this README.
