"""Freeze one adaptive case and its separate data-only verifier."""
import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--case', choices=['clarification', 'correction'], default='clarification')
p.add_argument('--agent-image')
a = p.parse_args()
source = Path(__file__).resolve().parent; root = a.output.resolve()
if root.is_relative_to(source.parents[1]): raise ValueError('Prepared tasks must stay outside source Git')
root.mkdir(parents=True, exist_ok=False)
context = root / 'verifier-context'; shutil.copytree(source / 'tests', context)
if a.case == 'correction': shutil.copyfile(source / 'correction/check.py', context / 'check.py')
shutil.copyfile(source / 'environment/project/README.md', context / 'README.md')
images = {}
for role, directory in [('agent', source / 'environment'), ('verifier', context)]:
    if role == 'agent' and a.agent_image:
        if not re.fullmatch('sha256:[0-9a-f]{64}', a.agent_image): raise ValueError('Immutable reused image required')
        images[role] = a.agent_image
        continue
    with (root / (role + '-build.log')).open('w') as log:
        result = subprocess.run(['docker', 'build', '--quiet', str(directory)], stdout=subprocess.PIPE,
                                stderr=log, text=True, check=True, timeout=600)
    image = result.stdout.strip().splitlines()[-1]
    if not re.fullmatch('sha256:[0-9a-f]{64}', image): raise RuntimeError('Immutable image ID required')
    images[role] = image
task = root / a.case; (task / 'environment').mkdir(parents=True)
shutil.copyfile(source / (a.case + '.md'), task / 'instruction.md')
shutil.copytree(context, task / 'tests'); (task / 'solution').mkdir()
expected = {'cadence': 'daily', 'local_time': '09:45', 'timezone': 'Europe/Lisbon'} if a.case == 'clarification' else {
    'cadence': 'weekdays', 'local_time': '17:15', 'timezone': 'Europe/Lisbon'}
(task / 'solution/solve.sh').write_text("#!/bin/sh\nprintf '%s\\n' '" + json.dumps(expected) + "' > /app/project/schedule.json\n")
(task / 'task.toml').write_text('schema_version = "1.4"\n[agent]\nuser = "node"\ntimeout_sec = 600\n'
    '[environment]\ndocker_image = ' + json.dumps(images['agent']) + '\ncpus = 1\nmemory_mb = 2048\nnetwork_mode = "public"\n'
    '[verifier]\ntimeout_sec = 60\nenvironment_mode = "separate"\n[verifier.environment]\ndocker_image = '
    + json.dumps(images['verifier']) + '\ncpus = 1\nmemory_mb = 512\nnetwork_mode = "public"\n'
    '[[artifacts]]\nsource = "/app/project"\ndestination = "project"\n')
(root / 'images.json').write_text(json.dumps(images, indent=2) + '\n')
print(json.dumps(images))
