// Model-free ACP initialize/session probe. Never send session/prompt or authenticate.
import {spawn} from 'node:child_process';
import readline from 'node:readline';
import {mkdirSync} from 'node:fs';

const pending = new Map();
const env = {...process.env, NO_BROWSER: '1', CODEX_PATH: '/usr/local/bin/codex'};
for (const key of ['OPENAI_API_KEY', 'CODEX_API_KEY', 'OPENAI_BASE_URL',
  'OPENAI_API_BASE', 'DEFAULT_AUTH_REQUEST']) delete env[key];
env.CODEX_CONFIG = JSON.stringify({model: 'gpt-6.1-sol', model_reasoning_effort: 'high',
  web_search: 'disabled', features: {apps: false, multi_agent: false}});
mkdirSync(env.CODEX_HOME, {recursive: true, mode: 0o700});
const child = spawn('/usr/local/bin/codex-acp', [], {env, detached: true,
  stdio: ['pipe', 'pipe', 'pipe']});
let stderrBytes = 0;
child.stderr.on('data', b => {stderrBytes += b.length;});
const lines = readline.createInterface({input: child.stdout});
lines.on('line', line => {
  let item;
  try {item = JSON.parse(line);} catch {return;}
  if (item.id != null && pending.has(item.id)) {
    pending.get(item.id)(item); pending.delete(item.id);
  }
});
let counter = 0;
async function request(method, params) {
  const id = ++counter;
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {pending.delete(id); reject(new Error('RPC timeout: ' + method));}, 25000);
    pending.set(id, value => {clearTimeout(timeout); resolve(value);});
    child.stdin.write(JSON.stringify({jsonrpc: '2.0', id, method, params}) + '\n');
  });
}
try {
  const init = await request('initialize', {protocolVersion: 1,
    clientCapabilities: {}, clientInfo: {name: 'harbor-subscription-probe', version: '0.1.0'}});
  if (!init.result) throw new Error('ACP initialization failed: ' + JSON.stringify(init.error));
  const session = await request('session/new', {cwd: '/app/project', mcpServers: []});
  const result = {protocol: init.result.protocolVersion,
    auth_methods: (init.result.authMethods || []).map(x => x.id),
    session_created: Boolean(session.result?.sessionId),
    current_model: session.result?.models?.currentModelId ?? null,
    config_ids: (session.result?.configOptions || []).map(x => x.id),
    auth_required: Boolean(session.error && /auth/i.test(session.error.message || '')),
    error_code: session.error?.code ?? null,
    inference_requests: 0, authenticate_requests: 0, stderr_bytes: stderrBytes};
  process.stdout.write(JSON.stringify(result) + '\n');
} finally {
  lines.close();
  try {process.kill(-child.pid, 'SIGTERM');} catch {}
  child.stdin.destroy();
}
