import json
import os
from pathlib import Path

root = Path('/app/project')
expected = {'cadence': 'daily', 'local_time': '09:45', 'timezone': 'Europe/Lisbon'}
try:
    actual = json.loads((root / 'schedule.json').read_text())
except (OSError, ValueError):
    actual = None
try:
    preserved = (root / 'README.md').read_bytes() == Path('/tests/README.md').read_bytes()
except OSError:
    preserved = False
checks = {'semantic_schedule': actual == expected,
          'readme_preserved': preserved,
          'no_agent_credentials_in_verifier': not any(os.environ.get(k) for k in
              ('OPENAI_API_KEY', 'CODEX_API_KEY', 'CODEX_AUTH_JSON_PATH'))
              and not Path('/installed-agent/codex-subscription-acp-home').exists()}
out = Path('/logs/verifier'); out.mkdir(parents=True, exist_ok=True)
(out / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
(out / 'reward.txt').write_text('1\n' if all(checks.values()) else '0\n')
