# First Docker/Codex case

This source-only I01 example asks Codex to change a service timeout from 15 to
30 seconds in JSON and its README, preserving unrelated data and text. It tests
the execution route, not the effectiveness of a skill or a real product release.
No Harbor skill is injected into the evaluated agent.

The agent uses native Codex with ChatGPT subscription authentication inside a
disposable Linux Docker container. A separate, network-disabled verifier reads
the explicitly transferred `/app/project` data and writes deterministic checks.
It never executes submitted code. No RewardKit, model judge, Worker, simulated
user or reducer is needed for this case.

## Run with the selected installed Harbor

Use the Python interpreter belonging to the selected Harbor 0.25.0 installation.
Verify Docker is running and `codex login status` identifies the existing ChatGPT
session. The runner checks for its native auth file without reading its contents;
Harbor supplies it to Codex during the agent phase and removes the guest copy.
Do not put credential contents in arguments, configuration or the task files.

From the repository root, select a work directory outside the repository and
prepare the images once. `prepare.py` builds the two Dockerfiles and writes
their exact local image IDs into a disposable native `task.toml` copy. Subsequent
trials use those prebuilt images instead of rebuilding per-trial images.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i01/prepare.py \
  --output /path/outside/repository/i01-prepared

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i01-prepared/docker-codex-i01 \
  --output /path/outside/repository/i01-agent-01 \
  --name agent-01 --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

`HARBOR_PYTHON` denotes the selected installation's interpreter; the runner does
not install or upgrade host tools. Each run requires a new output directory so
earlier results are preserved. Docker image dependencies are installed only
inside the image build. Base-image digests and the guest Codex version are pinned;
`images.json` records the built image IDs and source hashes. Retain the two owned
images for reuse. A later rebuild creates a new recorded profile, without
rewriting previous evidence.

Run the known-good reference solution without a model by selecting
`--agent oracle`. A plausible-bad calibration task copies this task into
disposable staging and changes only its reference solution to leave the README
stale. `--missing-artifact-control` deliberately declares an absent harness-owned
artifact; it tests collection-error reporting, not participant performance.

The runner calls Harbor's native Job API. This initial prototype checks this
example's project-artifact contract and is not yet a universal suite runner.
It retains native results, artifact manifests, isolated-agent observations and
cleanup evidence; `summary.json` adds a disposition:

- `passed`: complete valid collection and all deterministic conditions met;
- `failed`: validly collected evidence with a rejected task outcome;
- `infrastructure_error`: missing/invalid evidence, execution or boundary failure.

Review the native result and actual exported files before interpreting a score.
Raw outputs may contain local paths and belong outside Git. The agent has public
network access for inference with native web tools disabled; this example does
not establish an offline or restricted-egress boundary. Broader failure modes,
network restrictions, submitted-code protection and other interaction types
remain later increments.
