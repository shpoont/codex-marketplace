# Demo service

The request timeout is **15 seconds**.

Retries stay at 2. Telemetry is disabled.

Keep this deployment note: staged rollout only.
