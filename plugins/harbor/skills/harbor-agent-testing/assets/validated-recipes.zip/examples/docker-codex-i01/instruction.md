# Update the demo service timeout

The service in `/app/project` needs a longer request timeout.

Change `service.request_timeout_seconds` in `service.json` from 15 to 30.
Update the existing timeout statement in `README.md` to match. Preserve every
other configuration value and the rest of the README text. JSON formatting may
change. Keep the same two project files; no additional deliverables are needed.

Inspect the resulting files and report what changed. Work only on this
disposable project. Do not use external services or delegate the work.
