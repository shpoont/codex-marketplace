"""Build images once and freeze their local IDs into a disposable native task."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def main(output):
    source = Path(__file__).resolve().parent
    output = output.resolve()
    if output.is_relative_to(source):
        raise ValueError("Preparation output must be outside the source task")
    output.mkdir(parents=True, exist_ok=False)
    images = {}
    for role, context in (("agent", "environment"), ("verifier", "tests")):
        with (output / f"{role}-build.log").open("w") as log:
            result = subprocess.run(
                ["docker", "build", "--quiet", "--tag", f"harbor-i01-{role}:0.1.0", str(source / context)],
                stdout=subprocess.PIPE, stderr=log, text=True, timeout=600, check=True,
            )
        image = result.stdout.strip().splitlines()[-1]
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
            raise ValueError("Docker did not return an immutable local image ID")
        images[role] = image
    task = output / source.name
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    config = (task / "task.toml").read_text()
    for section, role in (("environment", "agent"), ("verifier.environment", "verifier")):
        marker = f"[{section}]\n"
        if config.count(marker) != 1:
            raise ValueError("Expected one native environment section")
        config = config.replace(marker, marker + f'docker_image = "{images[role]}"\n', 1)
    (task / "task.toml").write_text(config)
    record = {"images": images, "task_config_sha256": hashlib.sha256(config.encode()).hexdigest(),
              "source_files": {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted(source.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}}
    (output / "images.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"task": str(task), "images": images}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args().output)
