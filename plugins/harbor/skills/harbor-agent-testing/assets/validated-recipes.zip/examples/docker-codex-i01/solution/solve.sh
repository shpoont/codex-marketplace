#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/project/service.json')
data = json.loads(p.read_text())
data['service']['request_timeout_seconds'] = 30
p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
p = Path('/app/project/README.md')
p.write_text(p.read_text().replace('**15 seconds**', '**30 seconds**'))
PY
