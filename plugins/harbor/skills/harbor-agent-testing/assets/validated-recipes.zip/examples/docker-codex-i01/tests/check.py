"""Read transferred data only. Never import or execute submitted project code."""

import json
from pathlib import Path

project = Path("/app/project")
expected = {
    "schema_version": 1,
    "service": {
        "name": "harbor-demo",
        "request_timeout_seconds": 30,
        "retry_count": 2,
        "region": "eu-west",
    },
    "telemetry": {"enabled": False},
    "message": "Café readiness check",
}
expected_readme = (
    "# Demo service\n\nThe request timeout is **30 seconds**.\n\n"
    "Retries stay at 2. Telemetry is disabled.\n\n"
    "Keep this deployment note: staged rollout only.\n"
)
checks = {}
try:
    checks["configuration"] = json.loads((project / "service.json").read_text()) == expected
except (OSError, ValueError):
    checks["configuration"] = False
try:
    checks["documentation"] = (project / "README.md").read_text() == expected_readme
except OSError:
    checks["documentation"] = False
checks["project_files"] = project.is_dir() and {
    p.relative_to(project).as_posix() for p in project.rglob("*") if p.is_file()
} == {"service.json", "README.md"}
checks["no_agent_credentials_in_verifier"] = not any(
    p.exists() for p in (Path("/tmp/codex-secrets"), Path("/installed-agent/codex-home/auth.json"))
)
logs = Path("/logs/verifier")
logs.mkdir(parents=True, exist_ok=True)
(logs / "checks.json").write_text(json.dumps(checks, indent=2) + "\n")
(logs / "reward.json").write_text(json.dumps({"reward": float(all(checks.values()))}) + "\n")
print(json.dumps(checks, sort_keys=True))
