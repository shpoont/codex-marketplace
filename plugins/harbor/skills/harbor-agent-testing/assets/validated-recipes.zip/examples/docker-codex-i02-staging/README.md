# Staging-only configuration case

This second realistic repository-maintenance fixture asks Codex to enable
response compression for staging without changing production, defaults, local
timeout/logging customizations or owner notes. It is a synthetic project, not a
production deployment. No network service is contacted.

| Acceptance criterion | Participant-visible material | Verification |
| --- | --- | --- |
| Enable compression only for staging | `deployments.json` and the explicit staging-only request | New staging override is true; defaults remain false; production is unchanged |
| Preserve custom configuration | Existing timeout, logging, replicas, endpoints and metadata | Full JSON object comparison; formatting may differ |
| Keep the runbook current | Existing `RUNBOOK.md` | Update its staging statement while preserving other prose |
| Preserve unrelated reference material | `OWNER_NOTES.txt` | Exact unchanged text and the original three-file layout |

The separate Python verifier parses JSON and text; it never executes submitted
code or calls a model. The reference solution also demonstrates acceptable JSON
reformatting. The plausible-bad calibration changes the global default instead
of adding the staging override: the runbook looks correct, but production would
inherit the wrong behavior. The verifier must reject that distinction.

## Authoring and extending the suite

Start from the project's acceptance criterion. Identify the requested effect,
state that must remain unchanged, participant-visible context and observable
outputs. Write a native Harbor instruction, fixture and verifier for that
contract. Keep hidden grading logic outside the agent image. Calibrate the
criterion with correct output and a plausible defect before interpreting a
participant score; accept legitimate alternatives such as JSON formatting.

This case retains the existing `/app/project` artifact and separate-verifier
interface, with different filenames, three files and a new domain criterion.
It uses the unchanged `tooling/run_docker_case.py`; no conditional for this case
was added to that runner. Docker recipes are reused from I01. Its preparation
script changes only the owned image-tag prefix so preparing both cases does not
replace their friendly tags.

## Prepare and run

Use the selected Harbor 0.25.0 environment's Python as `HARBOR_PYTHON`. Confirm
the existing native Codex sign-in is ChatGPT. Store prepared tasks and raw outputs
outside the repository. Native task copies pin the locally built image IDs.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i02-staging/prepare.py \
  --output /path/outside/repository/staging-prepared

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/staging-prepared/docker-codex-i02-staging \
  --output /path/outside/repository/staging-round-01 \
  --name staging-round-01 --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

For the two-case suite, prepare [I01](../docker-codex-i01/README.md) as well. Run
timeout then staging with the same runner/settings, reviewing each native result,
actual artifacts, collection and cleanup before the next command. Repeat that
ordered selection in new output directories for round 02. Each case remains a
native Harbor task in its own job; this recipe does not introduce a suite engine
or modify the runner. The suite's final report should keep failures,
infrastructure errors and skipped/unattempted work separate.
