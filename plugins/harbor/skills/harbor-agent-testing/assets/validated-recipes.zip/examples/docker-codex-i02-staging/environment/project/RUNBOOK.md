# Deployment runbook

Staging response compression: disabled.

Production inherits the default compression setting.
Keep the staging timeout override at 45 seconds.
Changes require a staged rollout.
