# Enable compression for staging only

The deployment settings and runbook are in `/app/project`.

Enable response compression for staging by adding
`response_compression: true` to `environments.staging.overrides` in
`deployments.json`. Keep the default compression setting and production
configuration unchanged. Preserve the existing staging timeout and logging
overrides, all other configuration values, and `OWNER_NOTES.txt`.

Change the existing staging compression statement in `RUNBOOK.md` from disabled
to enabled. Preserve the rest of its text and the existing three-file layout.
JSON formatting may change. Inspect the results and explain what changed.

Work only on this disposable project. Do not contact external services or
delegate the work.
