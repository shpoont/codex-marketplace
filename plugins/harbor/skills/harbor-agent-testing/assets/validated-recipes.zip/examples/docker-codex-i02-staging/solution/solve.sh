#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
p = Path('/app/project/deployments.json')
data = json.loads(p.read_text())
data['environments']['staging']['overrides']['response_compression'] = True
p.write_text(json.dumps(data, indent=2) + '\n')
p = Path('/app/project/RUNBOOK.md')
p.write_text(p.read_text().replace('Staging response compression: disabled.', 'Staging response compression: enabled.'))
PY
