"""Parse transferred data only; never execute submitted project code."""

import json
from pathlib import Path

project = Path("/app/project")
expected = {
    "schema_version": 1,
    "defaults": {"replicas": 2, "request_timeout_seconds": 15, "response_compression": False},
    "environments": {
        "staging": {
            "endpoint": "https://staging.example.invalid",
            "overrides": {"request_timeout_seconds": 45, "log_level": "debug", "response_compression": True},
        },
        "production": {
            "endpoint": "https://api.example.invalid",
            "overrides": {"replicas": 6, "request_timeout_seconds": 90},
        },
    },
    "owner_metadata": {"ticket": "OPS-DEMO-42", "note": "Preserve staged rollout customizations"},
}
expected_runbook = (
    "# Deployment runbook\n\nStaging response compression: enabled.\n\n"
    "Production inherits the default compression setting.\n"
    "Keep the staging timeout override at 45 seconds.\n"
    "Changes require a staged rollout.\n"
)
checks = {}
try:
    actual = json.loads((project / "deployments.json").read_text())
    checks["configuration"] = actual == expected
    checks["staging_only"] = (
        actual["defaults"]["response_compression"] is False
        and actual["environments"]["staging"]["overrides"]["response_compression"] is True
        and "response_compression" not in actual["environments"]["production"]["overrides"]
    )
except (OSError, ValueError, KeyError, TypeError):
    checks["configuration"] = False
    checks["staging_only"] = False
for name, content, key in (
    ("RUNBOOK.md", expected_runbook, "documentation"),
    ("OWNER_NOTES.txt", "Keep production at six replicas.\nDo not replace the staging timeout override.\n", "owner_notes"),
):
    try:
        checks[key] = (project / name).read_text() == content
    except OSError:
        checks[key] = False
checks["project_files"] = project.is_dir() and {
    p.relative_to(project).as_posix() for p in project.rglob("*") if p.is_file()
} == {"deployments.json", "RUNBOOK.md", "OWNER_NOTES.txt"}
checks["no_agent_credentials_in_verifier"] = not any(
    p.exists() for p in (Path("/tmp/codex-secrets"), Path("/installed-agent/codex-home/auth.json"))
)
logs = Path("/logs/verifier")
logs.mkdir(parents=True, exist_ok=True)
(logs / "checks.json").write_text(json.dumps(checks, indent=2) + "\n")
(logs / "reward.json").write_text(json.dumps({"reward": float(all(checks.values()))}) + "\n")
print(json.dumps(checks, sort_keys=True))
