# Ordered change and release workflow

This native Harbor task has two steps in one disposable container. Each step
starts a fresh Codex conversation (`resume_trajectory=false`); project files
persist. It exercises the Docker/Codex/ChatGPT subscription profile, without
deploying anything or calling a model judge.

| Step | Agent work | Setup and continuation |
| --- | --- | --- |
| `prepare` | Update timeout and README; create a SHA-256 file handoff; preserve owner approval and notes | The image supplies the initial four files. Continue only if quality and owner approval both pass |
| `release` | Read the persisted handoff and create the staging release record | Setup adds only `rollout-request.json`; it does not recreate prior agent work |

Each separate verifier reads declared artifacts as data. The first checks the
whole configuration, documentation, handoff, approval preservation and file
layout. The second also checks the request and release record. Cross-step review
must compare previous files byte for byte; semantic per-step checks alone do
not prove that those bytes persisted unchanged.

`reward` measures the milestone's quality. `ready` reflects the immutable owner
approval. Both must be 1 to continue after `prepare`. With `--hold`, correct
first-step work earns `reward=1, ready=0`; `release` must remain unattempted.
The native `final` aggregation returns the last executed step, so its reward 1
does not establish completion of the intended two-step workflow. The runner
keeps that native reward and separately reports `stopped`, completion and
attempted/completed/skipped counts. Its nonzero exit for a held workflow means
the entire workflow did not pass; it is not a reason to retry it automatically.
Completed-step counts mean finished execution with a grade, not accepted quality.

## Prepare and run

Use the selected installed Harbor 0.25.0 interpreter as `HARBOR_PYTHON`. Guest
Codex is pinned at 0.167.0. Prepared tasks, build contexts and evidence belong
outside the checkout. Image-tag namespaces distinguish approved/held cases and
roles. The preparer records immutable local image IDs for the agent and each
step's bundled verifier.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i03-workflow/prepare.py \
  --output /path/outside/repository/workflow-approved

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/workflow-approved/docker-codex-i03-workflow \
  --output /path/outside/repository/workflow-approved-run \
  --name workflow-approved --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Review the native step results, session identities, actual files, before/after
hashes, collection and cleanup before preparing/running the held case. Add
`--hold` to preparation with a new output path, then run the resulting task in
another new output path using the same settings.

Calibration uses the known-good per-step solutions, then a plausible stale-README
first-step defect that must stop execution. A held-approval reference run checks
the distinct case where first-step quality passes but the workflow stays partial.
Agent artifacts remain authoritative for actual effects; setup provenance and
distinct session IDs require trace and checkpoint review as well.

The template does not test resumed conversations, trajectory loading, adaptive
simulation, arbitrary application behavior or exhaustive isolation. Its
[qualification record](../../docs/i03-ordered-workflow.md) states actual results
and evidence limits.
