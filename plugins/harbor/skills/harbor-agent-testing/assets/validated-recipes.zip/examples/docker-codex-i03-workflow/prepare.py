"""Prepare one native workflow with immutable agent and per-step verifier images."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def main(output, hold):
    source = Path(__file__).resolve().parent
    output = output.resolve()
    if output.is_relative_to(source):
        raise ValueError("Output must be outside the source task")
    output.mkdir(parents=True, exist_ok=False)
    task = output / source.name
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    if hold:
        for file in ("environment/project/approval.json", "tests/expected-approval.json"):
            (task / file).write_text('{"approved": false}\n')
    contexts = {"agent": task / "environment"}
    for step in ("prepare", "release"):
        context = output / "build" / step
        shutil.copytree(task / "tests", context)
        shutil.copy2(task / "steps" / step / "tests/test.sh", context / "test.sh")
        contexts[f"verifier-{step}"] = context
    images = {}
    for role, context in contexts.items():
        with (output / f"{role}-build.log").open("w") as log:
            built = subprocess.run(["docker", "build", "--quiet", "--tag",
                f"harbor-i03-{'held' if hold else 'approved'}-{role}:0.1.0", str(context)],
                stdout=subprocess.PIPE, stderr=log, text=True, timeout=600, check=True)
        image = built.stdout.strip().splitlines()[-1]
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
            raise ValueError("Expected an immutable local Docker image ID")
        images[role] = image
    config = (task / "task.toml").read_text().replace(
        "[environment]\n", f'[environment]\ndocker_image = "{images["agent"]}"\n', 1)
    verifier_images = iter(images[f"verifier-{step}"] for step in ("prepare", "release"))
    config = re.sub(r"\[steps.verifier.environment\]\n",
        lambda _: f'[steps.verifier.environment]\ndocker_image = "{next(verifier_images)}"\n', config)
    (task / "task.toml").write_text(config)
    (output / "images.json").write_text(json.dumps({"images": images, "hold": hold,
        "source_files": {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(source.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}}, indent=2) + "\n")
    print(json.dumps({"task": str(task), "images": images, "hold": hold}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--hold", action="store_true")
    args = parser.parse_args()
    main(args.output, args.hold)
