#!/bin/sh
set -eu
python3 - <<'PY'
import hashlib,json
from pathlib import Path
p=Path('/app/project')
config=json.loads((p/'service.json').read_text())
config['service']['request_timeout_seconds']=30
(p/'service.json').write_text(json.dumps(config,indent=2)+'\n')
(p/'README.md').write_text((p/'README.md').read_text().replace('**15 seconds**','**30 seconds**'))
(p/'HANDOFF.json').write_text(json.dumps({'request_timeout_seconds':30,'service_sha256':hashlib.sha256((p/'service.json').read_bytes()).hexdigest()})+'\n')
PY
