# Prepare the staging release record from persisted files

This is a fresh conversation. Work only in `/app/project` and use `python3` if
needed. Read the existing handoff and service configuration, and the newly
supplied `rollout-request.json`. Confirm approval in `approval.json` is true.

Create `RELEASE.json` with exactly four fields: `ticket` and `environment` from
the rollout request, plus `request_timeout_seconds` and `service_sha256` from
the persisted handoff. Validate the handoff digest against `service.json`.
Preserve all six existing files byte for byte, including the handoff, approval,
README, owner notes and rollout request. Only `RELEASE.json` may be added.
Inspect the result and explain what the release record contains. Do not contact
external services or delegate work.
