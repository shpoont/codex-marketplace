#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/app/project')
request=json.loads((p/'rollout-request.json').read_text())
handoff=json.loads((p/'HANDOFF.json').read_text())
(p/'RELEASE.json').write_text(json.dumps({**request,**handoff})+'\n')
PY
