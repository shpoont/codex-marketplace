#!/bin/sh
set -eu
test -f /app/project/HANDOFF.json
test ! -e /app/project/RELEASE.json
cp /app/rollout-request.json /app/project/rollout-request.json
