# Continued release-record conversation

This native Harbor example tests prior-message dependence and a correction in
one continued Codex session, with a persistent disposable Docker workspace.
It creates a synthetic release record; it never deploys or contacts a service.

| Case | Messages delivered in order | Required effect |
| --- | --- | --- |
| Basic | Receive details; later request the record without repeating values | Recover the earlier release label, owner and window |
| Correction | Receive details; correct only the window; later request the record without repeating values | Use the corrected window and preserve the earlier label and owner |

The receive/correct turns request acknowledgements without tools or file writes.
Until the final turn, the task workspace must contain only its original two
reference files, neither of which contains the release details. Native session
files necessarily store the conversation; they are runtime history, not task
memory files. The final instruction forbids retrieving earlier values through
tools that read logs, sessions or process state. Review the actual commands.

Separate deterministic verifiers check unchanged reference files, file layout
and the final JSON. They do not execute submitted code or call a model.
Reference output and plausible wrong-label/stale-window controls calibrate those
criteria. Oracle controls use fresh executions and qualify grading/transfer,
not native conversation resume. Session identity, growing history, no premature
disclosure and acknowledgement behavior require independent trace review.
Literal acknowledgement punctuation is recorded separately from data correctness
and session continuity.

## Prepare and run

Use the selected Harbor 0.25.0 interpreter as `HARBOR_PYTHON`, existing native
ChatGPT sign-in, guest Codex 0.167.0 and the agreed model/effort. Store prepared
tasks, build contexts and evidence outside the checkout. Preparation freezes
agent and per-step verifier image IDs with distinct case/role tag namespaces.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i04-conversation/prepare.py \
  --output /path/outside/repository/conversation-basic

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/conversation-basic/docker-codex-i04-conversation \
  --output /path/outside/repository/conversation-basic-run \
  --name conversation-basic --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0 \
  --resume-trajectory
```

Review the actual result before preparing the correction case with
`prepare.py --correction --output <new-path>`. Run that prepared task with the
same settings and `--resume-trajectory` in another new output path. The flag is
essential: without it the runner retains I03's fresh-session default. Do not
reinterpret a fresh conversation as continued history.

## Version-specific lifecycle and reporting

The non-mounted Docker log roundtrip in Harbor 0.25.0 can retain host/root file
ownership. Before later resumed steps, the trusted launcher restores ownership
only in the guest's native log directory to the existing nonroot agent. It
preserves content/modes and guards against mounted logs and unsafe entries.
It does not change installed Harbor, project files or evaluated-agent privileges.
The owned-container copy/write and symlink controls are recorded in qualification.

Codex's retained session counters are cumulative on this route. The runner uses
the latest snapshot for resumed usage, keeps the raw per-step sum separately
and marks usage incomplete when a step errors. Fresh-session runs still sum
their independent step contexts. Preserve original results when deriving a
corrected report; reporting changes do not count as a fresh target attempt.

See the [I04 qualification record](../../docs/i04-continued-conversation.md) for
actual cases, repairs, counts and limits. This example does not qualify loaded
histories, adaptive user simulation or general memory reliability.
