# Synthetic release record

This fixture creates a record only. No deployment takes place.
