"""Freeze a native conversation task and per-step verifier image IDs."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tomllib


def main(output, correction):
    source = Path(__file__).resolve().parent
    output = output.resolve()
    if output.is_relative_to(source):
        raise ValueError("Output must be outside the source task")
    output.mkdir(parents=True, exist_ok=False)
    task = output / source.name
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    config = (task / "task.toml").read_text()
    if correction:
        shutil.copytree(task / "variants/correction", task / "steps/correct")
        marker = '[[steps]]\nname = "record"'
        if config.count(marker) != 1:
            raise ValueError("Expected one final record step")
        config = config.replace(marker, (task / "variants/correction/step.toml").read_text() + "\n" + marker, 1)
        expected_path = task / "tests/expected.json"
        expected = json.loads(expected_path.read_text())
        old_window = expected["window"]
        expected["window"] = "16:00 UTC"
        expected_path.write_text(json.dumps(expected) + "\n")
        solution = task / "steps/record/solution/solve.sh"
        solution.write_text(solution.read_text().replace(old_window, expected["window"]))
    steps = [s["name"] for s in tomllib.loads(config)["steps"]]
    contexts = {"agent": task / "environment"}
    for step in steps:
        context = output / "build" / step
        shutil.copytree(task / "tests", context)
        shutil.copy2(task / "steps" / step / "tests/test.sh", context / "test.sh")
        contexts[f"verifier-{step}"] = context
    images = {}
    for role, context in contexts.items():
        with (output / f"{role}-build.log").open("w") as log:
            result = subprocess.run(["docker", "build", "--quiet", "--tag", f"harbor-i04-{'correction' if correction else 'basic'}-{role}:0.1.0", str(context)],
                stdout=subprocess.PIPE, stderr=log, text=True, timeout=600, check=True)
        image = result.stdout.strip().splitlines()[-1]
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
            raise ValueError("Expected immutable local image ID")
        images[role] = image
    config = config.replace("[environment]\n", f'[environment]\ndocker_image = "{images["agent"]}"\n', 1)
    verifier_images = iter(images[f"verifier-{step}"] for step in steps)
    config = re.sub(r"\[steps.verifier.environment\]\n",
        lambda _: f'[steps.verifier.environment]\ndocker_image = "{next(verifier_images)}"\n', config)
    (task / "task.toml").write_text(config)
    (output / "images.json").write_text(json.dumps({"images": images, "correction": correction,
        "source_files": {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(source.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}}, indent=2) + "\n")
    print(json.dumps({"task": str(task), "images": images}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--correction", action="store_true")
    args = parser.parse_args()
    main(args.output, args.correction)
