# Receive release coordination details

This is a synthetic release-record task. Remember these details for a later
request in this conversation:

- release_label: RLS-Q7M4-N8P2 (a non-secret fixture label)
- owner: release-coordination
- window: 14:30 UTC

For this message, do not use tools or create/change any files. Do not write
these details into a file or repeat them in your response. Reply with exactly
ACKNOWLEDGED. Do not contact services or delegate work.
