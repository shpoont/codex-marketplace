# Record the agreed release details

Create `/app/project/RELEASE.json` using the release details supplied earlier
in this conversation. It must contain exactly `release_label`, `owner` and
`window`, using their latest agreed values. The values are not repeated here.

Use the conversation; do not search session files, logs, process state or other
directories for the earlier message. If scripting is useful, use `python3`.
Work only in `/app/project`. Preserve `README.md` and `OWNER_NOTES.txt` byte for
byte, add only `RELEASE.json`, inspect its contents and briefly describe the
record. Do not contact external services or delegate work.
