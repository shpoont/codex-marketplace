#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
Path('/app/project/RELEASE.json').write_text(json.dumps({
    'release_label':'RLS-Q7M4-N8P2','owner':'release-coordination','window':'14:30 UTC'})+'\n')
PY
