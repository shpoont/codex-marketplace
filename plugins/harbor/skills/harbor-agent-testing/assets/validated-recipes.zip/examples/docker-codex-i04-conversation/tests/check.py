"""Grade transferred JSON/text only; conversation process is reviewed separately."""
import json
from pathlib import Path
import sys

phase = sys.argv[1]
assert phase in ("receive", "correct", "record")
project = Path("/app/project")
expected = json.loads(Path("/tests/expected.json").read_text())


def content(name):
    try:
        return (project / name).read_text()
    except (OSError, ValueError):
        return None


checks = {
    "readme": content("README.md") == "# Synthetic release record\n\nThis fixture creates a record only. No deployment takes place.\n",
    "owner_notes": content("OWNER_NOTES.txt") == "Preserve these reference files. Do not contact external services.\n",
}
names = {"README.md", "OWNER_NOTES.txt"}
if phase == "record":
    try:
        actual = json.loads(content("RELEASE.json") or "null")
    except ValueError:
        actual = None
    checks["record"] = actual == expected
    checks["window"] = isinstance(actual, dict) and actual.get("window") == expected["window"]
    names.add("RELEASE.json")
checks["project_files"] = {str(p.relative_to(project)) for p in project.rglob("*") if p.is_file()} == names
checks["no_agent_credentials_in_verifier"] = not any(
    p.exists() for p in (Path("/tmp/codex-secrets"), Path("/installed-agent/codex-home/auth.json")))
logs = Path("/logs/verifier")
logs.mkdir(parents=True, exist_ok=True)
(logs / "checks.json").write_text(json.dumps(checks, indent=2) + "\n")
(logs / "reward.json").write_text(json.dumps({"reward": float(all(checks.values()))}) + "\n")
print(json.dumps(checks, sort_keys=True))
