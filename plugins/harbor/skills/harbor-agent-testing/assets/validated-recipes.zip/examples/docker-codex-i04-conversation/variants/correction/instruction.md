# Correct the previously agreed release window

Correction to the release details from my earlier message: Change only the window to `16:00 UTC`.
Keep the release label and owner as previously supplied. The earlier window is
superseded. Remember the corrected details for my next request in this conversation.

Do not use tools or create/change files yet. Do not restate any of the details.
Reply with exactly UPDATED. Do not contact services or delegate work.
