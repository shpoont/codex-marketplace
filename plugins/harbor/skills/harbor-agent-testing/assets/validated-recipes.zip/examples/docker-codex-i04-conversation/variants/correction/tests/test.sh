#!/bin/sh
set -eu
python /tests/check.py correct
