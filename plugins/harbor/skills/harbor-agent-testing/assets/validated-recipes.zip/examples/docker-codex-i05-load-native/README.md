# Load native history into a fresh workspace

This task continues the reviewed I04 corrected-release history in a new Docker
container. Its prompt does not repeat the release values. The loaded conversation
contains an earlier `RELEASE.json` creation, while the new workspace supplies
only two reference files. The agent must recover the corrected values, report
the initially absent old file and create only `CONTEXT.json` and
`WORKSPACE_CHECK.json`.

The deterministic verifier checks the data, old-file absence and preserved
reference files. Independent review also checks the source hash, native session
ID, extended history prefix, fresh container, initial workspace and actual tool
commands. Oracle controls qualify grading/transfer, not conversational loading.
The plausible-bad control recreates the old file despite correct context values.

## Prepare and run

Use the selected Harbor 0.25.0 interpreter as `HARBOR_PYTHON`, guest Codex 0.167.0
and existing ChatGPT sign-in. The paired seed is the final native I04 correction
snapshot, with its original `rollout-<timestamp>-<session-id>.jsonl` filename.
Keep its bytes unchanged. Do not copy old project artifacts into the new task.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i05-load-native/prepare.py \
  --output /path/outside/repository/load-prepared

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/load-prepared/docker-codex-i05-load-native \
  --output /path/outside/repository/load-result \
  --name native-load --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0 \
  --load-trajectory "/path/to/original/rollout-<timestamp>-<session-id>.jsonl"
```

Replace the example history path with a real quoted path preserving the native
filename. Prepared tasks/evidence belong outside the checkout. The preparer
freezes immutable local agent/verifier image IDs under the `harbor-i05-` namespace.
The I04 source history is intentionally supplied context, not a fresh model run.
For other histories, adapt the case's acceptance criteria and verifier explicitly.

`--load-trajectory` loads the first conversation; it does not require the
multi-step `--resume-trajectory` setting. This increment qualifies native `.jsonl`
only. `.json` selects ATIF in Harbor and remains a separate I06 qualification.

## Damaged inputs and evidence

The pinned native combination can silently start a fresh session from malformed
contents. The runner now rejects incomplete/invalid JSONL, missing metadata and
filename/session-ID mismatches before Docker or inference. It uses the installed
Codex filename pattern. A post-run receipt also requires the original native
prefix to grow and the executed thread ID to match; a fallback is an infrastructure
error, never an agent-quality failure or a loaded-session pass.

These checks cover the selected complete native-record format, not every legacy
export or possible semantic corruption. The installed native loader still owns
execution compatibility. No history is rewritten or repaired automatically.

Native usage counters include the imported history. The qualification report
subtracts the seed's retained counters to identify new continuation usage;
raw native totals remain unchanged. Do not charge the prior session's usage to
this continuation again.

See the [I05 qualification record](../../docs/i05-native-history-loading.md) for
actual malformed-input results, repair/retest evidence and scope limits.
