# Fresh history-loading workspace

This is a new sandbox. Prior task files are not provided.
