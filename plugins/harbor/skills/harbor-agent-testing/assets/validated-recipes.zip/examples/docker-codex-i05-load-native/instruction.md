# Continue in a fresh workspace

Continue from the loaded release-coordination conversation. This is a new
disposable workspace at `/app/project`; conversation loading does not supply
the previous project's files. Do not recreate the earlier `RELEASE.json`.

First inspect the project before writing any files. Create `WORKSPACE_CHECK.json`
with exactly `previous_release_present` (whether `RELEASE.json` existed before
your work) and `initial_files` (the sorted filenames initially present).

Create `CONTEXT.json` with exactly `release_label`, `owner` and `window` using
the latest agreed values from the loaded conversation. Those values are not
repeated here. Use the conversation; do not retrieve them through tools reading
session files, logs, process state or other directories. Use `python3` if helpful.

Preserve `README.md` and `OWNER_NOTES.txt` byte for byte. Add only the two requested
JSON files. Inspect the outputs and explain whether the previous file existed
and which conversational details were recovered. Do not contact external
services or delegate work.
