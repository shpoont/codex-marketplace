#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/app/project')
initial=sorted(f.name for f in p.iterdir())
old=(p/'RELEASE.json').exists()
(p/'WORKSPACE_CHECK.json').write_text(json.dumps({'previous_release_present':old,'initial_files':initial})+'\n')
(p/'CONTEXT.json').write_text(json.dumps({'release_label':'RLS-Q7M4-N8P2','owner':'release-coordination','window':'16:00 UTC'})+'\n')
PY
