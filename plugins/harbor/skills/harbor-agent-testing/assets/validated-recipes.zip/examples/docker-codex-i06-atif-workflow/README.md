# Loaded first step, fresh or resumed later step

This two-step native Harbor task loads ATIF only before `remember`. The first
step receives a new conversation-only code and saves a fixed milestone without
writing any context values into the workspace. The second step reports which
values are available in its active conversation; unavailable values must be null.

| Variant | Native sequence | Expected final context |
| --- | --- | --- |
| Fresh, default | Load, then fresh | Three nulls and `history_available=false` |
| Resumed | Load, then resume | Imported label/receipt, new follow-up code and `history_available=true` |

The same participant instructions, initial files and ATIF source are used in
both cases. Files persist in both. Expected grading data changes to reflect the
deliberately different conversation mode. Separate verifiers read data only.
Oracle reference controls calibrate each expected outcome without loading history.

## Prepare and run

Use the selected Harbor 0.25.0 interpreter as `HARBOR_PYTHON`, guest Codex 0.167.0
and existing ChatGPT sign-in. Keep prepared profiles and raw evidence outside Git.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i06-atif-workflow/prepare.py \
  --output /path/outside/repository/atif-fresh

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/atif-fresh/docker-codex-i06-atif-workflow \
  --output /path/outside/repository/atif-fresh-run \
  --name atif-fresh --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Review the fresh result before preparing the resumed case with
`prepare.py --resume-case --output <new-path>`. Run that prepared task with
`--resume-trajectory`, the same model settings and another new result path.
Both options matter: preparation selects the expected outcome; the native runner
flag selects actual conversation continuity. No automatic mode substitution occurs.

The source remains at `steps/remember/trajectory.json`; no second-step history
file or setup script reintroduces it. Review first-step load receipts, active
native thread IDs/history, actual outputs and file hashes across both steps.
An inactive retained session file is not proof that it was the active conversation.

The I04 native-log ownership correction still applies to resumed steps without
changing installed Harbor or evaluated-agent privileges. Usage for resumed Codex
uses the latest cumulative counter; fresh steps sum independent counters.
These synthetic ATIF seeds contain no prior model usage counters.

See [I06 results](../../docs/i06-atif-loading.md) for the actual pair, pinned-image
comparison, conversion limits and evidence scope. Neither case claims broad
memory reliability or adaptive conversation simulation.
