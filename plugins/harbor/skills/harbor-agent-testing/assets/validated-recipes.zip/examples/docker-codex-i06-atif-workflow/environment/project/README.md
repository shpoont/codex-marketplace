# Portable history fixture

The earlier conversation is context, not a filesystem backup.
