"""Freeze one fresh/resumed-later-step ATIF task and verifier image IDs."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def main(output, resume_case):
    source = Path(__file__).resolve().parent
    output = output.resolve()
    if output.is_relative_to(source):
        raise ValueError('Output must be outside the source task')
    output.mkdir(parents=True, exist_ok=False)
    task = output / source.name
    shutil.copytree(source, task, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    if resume_case:
        expected = {'context_label':'TASK-COPPER-K7','tool_receipt':'TOOL-TASK-Q3',
                    'followup_code':'FOLLOWUP-R8','history_available':True}
        (task/'tests/expected.json').write_text(json.dumps(expected)+'\n')
        (task/'steps/report/solution/solve.sh').write_text(
            "#!/bin/sh\nset -eu\npython3 - <<'PY'\nfrom pathlib import Path\n"
            "Path('/app/project/CONTEXT.json').write_text("+repr(json.dumps(expected)+'\n')+")\nPY\n")
    contexts = {'agent': task / 'environment'}
    for step in ('remember', 'report'):
        context = output / 'build' / step
        shutil.copytree(task / 'tests', context)
        shutil.copy2(task / 'steps' / step / 'tests/test.sh', context / 'test.sh')
        contexts['verifier-'+step] = context
    images = {}
    for role, context in contexts.items():
        with (output / f'{role}-build.log').open('w') as log:
            result = subprocess.run(['docker','build','--quiet','--tag',f'harbor-i06-{"resumed" if resume_case else "fresh"}-{role}:0.1.0',str(context)],
                stdout=subprocess.PIPE,stderr=log,text=True,timeout=600,check=True)
        image = result.stdout.strip().splitlines()[-1]
        if not re.fullmatch(r'sha256:[0-9a-f]{64}',image):
            raise ValueError('Expected immutable local image ID')
        images[role] = image
    config = (task/'task.toml').read_text().replace('[environment]\n',f'[environment]\ndocker_image = "{images["agent"]}"\n',1)
    pins = iter(images['verifier-'+step] for step in ('remember','report'))
    config = re.sub(r'\[steps.verifier.environment\]\n',lambda _:f'[steps.verifier.environment]\ndocker_image = "{next(pins)}"\n',config)
    (task/'task.toml').write_text(config)
    (output/'images.json').write_text(json.dumps({'images':images,'resume_case':resume_case,'source_files':{
        str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts}},indent=2)+'\n')
    print(json.dumps({'task':str(task),'images':images}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--resume-case',action='store_true')
    args = parser.parse_args()
    main(args.output,args.resume_case)
