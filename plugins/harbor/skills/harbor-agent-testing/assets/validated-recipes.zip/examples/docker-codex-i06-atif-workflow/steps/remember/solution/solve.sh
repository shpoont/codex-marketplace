#!/bin/sh
set -eu
printf 'First step completed.\n' > /app/project/MILESTONE.txt
