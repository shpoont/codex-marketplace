#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
Path('/app/project/CONTEXT.json').write_text(json.dumps({'context_label':None,'tool_receipt':None,'followup_code':None,'history_available':False})+'\n')
PY
