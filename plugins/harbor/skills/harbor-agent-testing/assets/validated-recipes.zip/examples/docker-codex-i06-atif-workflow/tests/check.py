"""Read saved fixture data only; session semantics receive independent review."""
import json
from pathlib import Path
import sys

p = Path('/app/project')
phase = sys.argv[1]
assert phase in ('remember', 'report')


def text(name):
    try:
        return (p / name).read_text()
    except (OSError, ValueError):
        return None


checks = {
    'readme': text('README.md') == '# Portable history fixture\n\nThe earlier conversation is context, not a filesystem backup.\n',
    'owner_notes': text('OWNER_NOTES.txt') == 'Preserve these reference files. Do not replay historical tool calls.\n',
    'milestone': text('MILESTONE.txt') == 'First step completed.\n',
    'no_agent_credentials_in_verifier': not any(f.exists() for f in (Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json'))),
}
names = {'README.md','OWNER_NOTES.txt','MILESTONE.txt'}
if phase == 'report':
    try:
        actual = json.loads(text('CONTEXT.json') or 'null')
    except ValueError:
        actual = None
    checks['context'] = actual == json.loads(Path('/tests/expected.json').read_text())
    names.add('CONTEXT.json')
checks['project_files'] = {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()} == names
logs = Path('/logs/verifier')
logs.mkdir(parents=True, exist_ok=True)
(logs / 'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(logs / 'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks,sort_keys=True))
