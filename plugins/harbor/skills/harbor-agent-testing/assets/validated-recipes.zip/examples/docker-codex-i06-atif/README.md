# Task-level and run-level ATIF loading

This synthetic task uses portable ATIF-v1.8 history containing a user label and
a linked historical tool receipt. The current prompt omits both values; the
agent must recover them into `CONTEXT.json` while preserving two reference files.
Historical tool calls are context only and must not be executed again.

The default source is task-level `trajectory.json`. The override variant retains
that source but prepares a conflicting run-level JSON source with a different
label, receipt and session ID. Its verifier expects the run-level values.
The runner records the effective source hash, level and converted-native receipt;
the native Harbor loader still performs execution and conversion.

## Prepare and run separately

Use the selected Harbor 0.25.0 interpreter as `HARBOR_PYTHON`, existing ChatGPT
sign-in, guest Codex 0.167.0 and the agreed Sol / High settings. Store prepared
tasks and raw evidence outside the checkout. Images are pinned to local IDs.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i06-atif/prepare.py \
  --output /path/outside/repository/atif-task

"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/atif-task/docker-codex-i06-atif \
  --output /path/outside/repository/atif-task-run \
  --name atif-task --agent codex \
  --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Review the actual result before preparing another case. For the run-level case,
use `prepare.py --run-override --output <new-path>`, then run the prepared task
with `--load-trajectory /path/to/new-path/run-history.json` and a new result path.
Preparation changes the hidden expected values and reference output; it does
not set the native run-level load option automatically. The source task-level
history remains unchanged, so precedence is observable.

Oracle controls skip task-level histories, matching Harbor's behavior. They
calibrate data grading and transfer, not native loading or conversation use.
Invalid selected ATIF is rejected before evaluation startup; an invalid override
does not silently fall back to the task source. Only the effective source is
validated, so an unused lower-priority source cannot block an override.

## Conversion boundaries

The selected installed converter preserves the tested text and linked structured
tool calls/results. Its inspected behavior maps system messages to developer
messages, replaces image/audio content with text placeholders and omits some
reasoning, metadata and unlinked observations. The probe uses synthetic markers;
it does not claim live multimodal understanding or restoration of tools/files.

ATIF may omit a native UUID or timestamps. Receipt checks accommodate generated
values without rewriting the input. That comparison has offline coverage; the
four live I06 cases use explicit source UUIDs/timestamps. No model calls are
needed to inspect these conversion limits.

See the [fresh/resumed workflow](../docker-codex-i06-atif-workflow/README.md) and
[I06 qualification record](../../docs/i06-atif-loading.md). These examples do not
qualify all ATIF versions, legacy exports or semantic corruption.
