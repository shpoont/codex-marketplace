#!/bin/sh
set -eu
python3 - <<'PY'
import json
from pathlib import Path
Path('/app/project/CONTEXT.json').write_text(json.dumps({'context_label':'TASK-COPPER-K7','tool_receipt':'TOOL-TASK-Q3'})+'\n')
PY
