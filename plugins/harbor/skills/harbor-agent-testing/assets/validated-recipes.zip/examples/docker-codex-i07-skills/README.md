# Task-bundled skills: source prototype

The evaluated agent prepares RELEASE.json from CHANGE.json using a synthetic
release-notes skill and its JSON policy reference. The source Dockerfile bundles
both that skill and an unrelated neighboring skill under /opt/task-skills.
`environment.skills_dir` asks Harbor to register them in native Codex discovery.
The native source and registered file hashes are retained before/after execution;
the trajectory separately establishes discovery and reference use.

These synthetic skills are the treatment. The Harbor plugin guides the author;
it is not injected into the participant. No effectiveness comparison is claimed.
A separate no-network verifier parses declared project data and never executes
submitted code. Host Harbor remains 0.25.0; Docker Codex 0.167.0 uses the selected
Sol / High settings and existing native ChatGPT subscription authentication.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i07-skills/prepare.py \
  --output /path/outside/repository/i07-task-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i07-task-profile/docker-codex-i07-skills \
  --output /path/outside/repository/i07-task-live --name i07-task-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Use the selected installed Harbor interpreter. Preparation records exact source
hashes and local image IDs. Every run requires a new output directory. Oracle
controls qualify grading and transfer, not Codex discovery. Review exported data,
native rollout and actual skill reads separately from the numeric reward.

## Job-only injection

Prepare with `--job-only` to omit bundled skills and `environment.skills_dir`.
The prompt and project input stay the same. The job skill provides a distinct
policy category/receipt, and the hidden deterministic expectation changes with
that deliberate treatment. Pass its prepared local root to the same launcher:

```sh
"$HARBOR_PYTHON" examples/docker-codex-i07-skills/prepare.py --job-only \
  --output /path/outside/repository/i07-job-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i07-job-profile/docker-codex-i07-skills \
  --skill /path/outside/repository/i07-job-profile/docker-codex-i07-skills/job-skills \
  --output /path/outside/repository/i07-job-live --name i07-job-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

This uses Harbor's default `/runtime/skills` source and native registration at
`/home/node/.agents/skills`. The launcher accepts local roots or individual
skill directories, records ordered contents and native digests, and leaves
resolution/upload to Harbor. Missing inputs or symlinks stop before startup;
missing, modified or mixed registered content invalidates the result. Git skill
sources are not qualified by this local recipe. Oracle controls omit `--skill`.

## Same-name replacement

Prepare with `--precedence` to keep the task-bundled skill and use the final
job policy as the expected treatment. Inject the earlier root first, final root
last. Both contain a directory named `release-notes`; native Harbor resolves
this collision by directory name, with the last job source winning.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i07-skills/prepare.py --precedence \
  --output /path/outside/repository/i07-precedence-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i07-precedence-profile/docker-codex-i07-skills \
  --skill /path/outside/repository/i07-precedence-profile/docker-codex-i07-skills/precedence-skills/earlier \
  --skill /path/outside/repository/i07-precedence-profile/docker-codex-i07-skills/precedence-skills/final \
  --output /path/outside/repository/i07-precedence-live --name i07-precedence-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

The selected skill replaces the bundled directory at `/opt/task-skills` before
native registration. Check that `task-only.txt` and `earlier-only.txt` are absent,
the final policy is the only supplied policy and `fixture-neighbor` remains.
Compare native lock provenance and both delivered file manifests with the frozen
sources. A wrong-source Oracle output must be rejected by the final verifier.

Across these cases the participant prompt and project inputs are fixed; policy
category and receipt vary deliberately. Task/precedence image filesystems and
runtime configuration match in qualification, but local image IDs differ. Each
run uses its own frozen image pin. Different hidden grading expectations prevent
mistaking source precedence for a general skill-effectiveness comparison.
