---
name: fixture-neighbor
description: Unrelated synthetic skill for a different fixture; do not use for release notes.
---

This neighboring directory is a delivery-preservation canary: NEIGHBOR-KEPT-T4.
It has no instructions for the release note task.
