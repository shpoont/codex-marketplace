---
name: release-notes
description: Prepare a structured release note from CHANGE.json using the supplied reference policy.
---

Read `references/policy.json` relative to this skill before writing the release
note. Write RELEASE.json with exactly `version`, `component`, `category`,
`summary` and `policy_receipt`. Copy version and component from CHANGE.json.
Use category and policy_receipt from the policy. Set summary to the change text
followed by ` (#<issue>)`. Do not change source files or this skill.
