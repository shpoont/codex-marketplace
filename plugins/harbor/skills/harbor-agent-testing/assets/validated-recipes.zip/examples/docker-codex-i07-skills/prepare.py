"""Build images once and freeze their local IDs into a disposable native task."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


def main(output, job_only=False, precedence=False):
    source = Path(__file__).resolve().parent
    output = output.resolve()
    if output.is_relative_to(source):
        raise ValueError("Preparation output must be outside the source task")
    output.mkdir(parents=True, exist_ok=False)
    task = output / source.name
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    mode = "precedence" if precedence else "job" if job_only else "task"
    if job_only:
        shutil.rmtree(task / "environment/skills")
        dockerfile = task / "environment/Dockerfile"
        dockerfile.write_text(dockerfile.read_text().replace("COPY --chown=node:node skills/ /opt/task-skills/\n", ""))
        config_path = task / "task.toml"
        config_path.write_text(config_path.read_text().replace('skills_dir = "/opt/task-skills"\n', ""))
    if job_only or precedence:
        policy = (task / "precedence-skills/final/release-notes/references/policy.json" if precedence
                  else task / "job-skills/release-notes/references/policy.json")
        expected_path = task / "tests/expected.json"
        expected = json.loads(expected_path.read_text())
        expected.update(json.loads(policy.read_text()))
        expected_path.write_text(json.dumps(expected, indent=2) + "\n")
        solution = task / "solution/solve.sh"
        solution.write_text(solution.read_text().replace("maintenance", expected["category"]).replace("TASK-COPPER-K7", expected["policy_receipt"]))
    images = {}
    for role, context in (("agent", "environment"), ("verifier", "tests")):
        with (output / f"{role}-build.log").open("w") as log:
            result = subprocess.run(
                ["docker", "build", "--quiet", "--tag", f"harbor-i07-{mode}-{role}:0.1.0", str(task / context)],
                stdout=subprocess.PIPE, stderr=log, text=True, timeout=600, check=True,
            )
        image = result.stdout.strip().splitlines()[-1]
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
            raise ValueError("Docker did not return an immutable local image ID")
        images[role] = image
    config = (task / "task.toml").read_text()
    for section, role in (("environment", "agent"), ("verifier.environment", "verifier")):
        marker = f"[{section}]\n"
        if config.count(marker) != 1:
            raise ValueError("Expected one native environment section")
        config = config.replace(marker, marker + f'docker_image = "{images[role]}"\n', 1)
    (task / "task.toml").write_text(config)
    record = {"images": images, "mode": mode,
              "task_config_sha256": hashlib.sha256(config.encode()).hexdigest(),
              "source_files": {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted(source.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}}
    (output / "images.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"task": str(task), "images": images}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--job-only", action="store_true")
    modes.add_argument("--precedence", action="store_true")
    args = parser.parse_args()
    main(args.output, args.job_only, args.precedence)
