#!/bin/sh
set -eu
cat > /app/project/RELEASE.json <<'JSON'
{"version": "2.4.1", "component": "cache-sync", "category": "maintenance", "summary": "Retry transient connection failures (#42)", "policy_receipt": "TASK-COPPER-K7"}
JSON
