"""Data-only grading. Native skill delivery and use are reviewed separately."""
import json
from pathlib import Path
p=Path('/app/project')
def text(name):
    try:return (p/name).read_text()
    except (OSError,ValueError):return None
try:actual=json.loads(text('RELEASE.json') or 'null')
except ValueError:actual=None
checks={
    'release':actual==json.loads(Path('/tests/expected.json').read_text()),
    'input_unchanged':text('CHANGE.json')==Path('/tests/CHANGE.json').read_text(),
    'notes_unchanged':text('OWNER_NOTES.txt')=='Preserve input files exactly. Only RELEASE.json is a deliverable.\n',
    'project_files':{str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}=={'CHANGE.json','OWNER_NOTES.txt','RELEASE.json'},
    'no_agent_credentials_in_verifier':not any(f.exists() for f in (Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json'))),
}
logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks,sort_keys=True))
