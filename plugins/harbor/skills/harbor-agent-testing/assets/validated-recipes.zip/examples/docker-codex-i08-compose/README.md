# Compose inventory service

The same reservation task now uses a Streamable HTTP MCP server in an inventory
sidecar. Harbor reserves `main` for the agent. A real HTTP health check gates
startup; both containers share an internal fixture network, and only main joins
the public default network for inference. No ports are published and no volume
or host paths are mounted. All three images are frozen to local IDs.

The task declares `/app/service-data` from service `inventory` explicitly.
Harbor exports that live service state and transfers it to the separate verifier;
copying just the agent's receipt is insufficient. The verifier parses data and
never runs submitted code. Oracle's HTTP calibration client is uploaded only
with the reference solution; it is not part of the evaluated agent image.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i08-compose/prepare.py \
  --output /path/outside/repository/i08-compose-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i08-compose-profile/docker-codex-i08-compose \
  --output /path/outside/repository/i08-compose-live --name i08-compose-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Use selected installed Harbor 0.25.0 and existing native ChatGPT sign-in. Each
run needs a new output directory. Check all service image IDs, nonroot users,
health, mounts, published ports and network membership at both checkpoints.
Review native tool calls and sidecar-qualified artifact manifests. This proves
the concrete service-state path, not comprehensive egress or adversarial safety.
