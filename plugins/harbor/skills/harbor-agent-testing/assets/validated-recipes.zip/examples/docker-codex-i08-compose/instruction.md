Reserve 3 units of CABLE-USB for order demo-42 using the inventory MCP tools.
Read the current inventory first and use its revision when making the reservation.
Do not reset inventory, call the server through a shell client, run its Python
functions directly, or edit service data. Use the actual native MCP tools.

Write `/app/project/RECEIPT.json` with exactly `sku`, `order_id`, `quantity`,
`available`, `reserved` and `revision`, reflecting the successful reservation.
Preserve existing project files exactly. Create no other project files. Do not
inspect grading, credentials, runtime logs or host state.
