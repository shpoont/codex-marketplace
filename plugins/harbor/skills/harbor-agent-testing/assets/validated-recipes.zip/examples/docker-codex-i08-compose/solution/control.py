"""Model-free protocol control; never used by the evaluated agent."""
import asyncio,json,sys
from pathlib import Path
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

async def main():
    async with streamablehttp_client('http://inventory:8000/mcp') as streams:
        async with ClientSession(streams[0],streams[1]) as session:
            await session.initialize()
            tools=await session.list_tools()
            assert {t.name for t in tools.tools}=={'get_inventory','reserve_stock','reset_inventory'}
            result=await session.call_tool('get_inventory',{})
            assert not result.isError
            stock=json.loads(result.content[0].text)
            if '--bad' not in sys.argv:
                result=await session.call_tool('reserve_stock',{'sku':'CABLE-USB','quantity':3,'order_id':'demo-42','expected_revision':stock['revision']})
                assert not result.isError
                receipt=json.loads(result.content[0].text)
            else:
                receipt={'sku':'CABLE-USB','quantity':3,'order_id':'demo-42','available':9,'reserved':3,'revision':1}
            Path('/app/project/RECEIPT.json').write_text(json.dumps(receipt)+'\n')
asyncio.run(main())
