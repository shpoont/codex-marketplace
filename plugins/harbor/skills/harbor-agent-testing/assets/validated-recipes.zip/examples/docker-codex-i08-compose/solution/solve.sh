#!/bin/sh
set -eu
/opt/mcp-venv/bin/python /solution/control.py
