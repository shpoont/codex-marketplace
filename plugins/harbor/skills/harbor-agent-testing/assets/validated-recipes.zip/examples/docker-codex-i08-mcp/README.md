# Local native MCP tool case

Reserve synthetic stock through native MCP tools, then export an accurate JSON
receipt and actual service state. The stdio server uses the official Python SDK
pinned to its 1.30.0 maintenance release inside Docker; it is not installed on
the host. State is confined to /app/service-data in the disposable agent container.
Harbor registers the task-declared server in Codex's effective native config.

The prompt requires native tool calls, not a shell client or manual state edit.
The separate no-network verifier reads two declared artifacts and executes no
submitted code. A model-free Oracle client exercises initialization, discovery
and tool calls; a plausible receipt without reservation must be rejected.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i08-mcp/prepare.py \
  --output /path/outside/repository/i08-mcp-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i08-mcp-profile/docker-codex-i08-mcp \
  --output /path/outside/repository/i08-mcp-live --name i08-mcp-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Use installed Harbor 0.25.0's interpreter and the existing ChatGPT sign-in.
Preparation records source hashes and immutable local agent/verifier image IDs.
Use new output directories. Oracle controls select --agent oracle. Review native
MCP call arguments/results, exported state, complete collection and cleanup.
The locally accessible service data is not an adversarial tamper-proof boundary.
Public agent networking permits inference; native web and multi-agent are disabled.

## Native MCP configuration

The separate `--filtered` preparation removes the task MCP declaration. Supply
its `native-filter.toml` with launcher `--mcp-config` to test Codex's native
`enabled_tools` setting, retaining only the two reservation tools. The runner
accepts MCP-only fixture settings; inference/authentication fields are rejected.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i08-mcp/prepare.py --filtered \
  --output /path/outside/repository/i08-filter-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i08-filter-profile/docker-codex-i08-mcp \
  --mcp-config /path/outside/repository/i08-filter-profile/docker-codex-i08-mcp/native-filter.toml \
  --output /path/outside/repository/i08-filter-live --name i08-filter-live \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0
```

Harbor 0.25.0 replaces a whole same-name native entry when the task also declares
that MCP server. Its task schema cannot carry `enabled_tools`, so duplicating a
server would silently drop this setting. The launcher rejects that duplicate;
declare each server once. Installed Harbor is unchanged. The filtered server
records only public registration fields in service data during startup, because
Harbor removes the entire temporary Codex home before the end hook.

A model-free native catalog probe separately confirmed the reset canary is
excluded while both intended tools remain available. The live case then checks
the real reservation. This is a native catalog filter, not a security boundary
against shell access, service-code edits or direct MCP clients. See the
[official Codex configuration](https://learn.chatgpt.com/docs/extend/mcp) and
[SDK v1 maintenance documentation](https://py.sdk.modelcontextprotocol.io/v1/).
