"""Model-free protocol control; never used by the evaluated agent."""
import asyncio,json,sys
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    params=StdioServerParameters(command='/opt/mcp-venv/bin/python',args=['/opt/mcp/server.py'])
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            tools=await session.list_tools()
            assert {t.name for t in tools.tools}=={'get_inventory','reserve_stock','reset_inventory'}
            result=await session.call_tool('get_inventory',{})
            assert not result.isError
            stock=json.loads(result.content[0].text)
            if '--bad' not in sys.argv:
                result=await session.call_tool('reserve_stock',{'sku':'CABLE-USB','quantity':3,'order_id':'demo-42','expected_revision':stock['revision']})
                assert not result.isError
                receipt=json.loads(result.content[0].text)
            else:
                receipt={'sku':'CABLE-USB','quantity':3,'order_id':'demo-42','available':9,'reserved':3,'revision':1}
            Path('/app/project/RECEIPT.json').write_text(json.dumps(receipt)+'\n')
asyncio.run(main())
