#!/bin/sh
set -eu
/opt/mcp-venv/bin/python /opt/mcp/control.py
