# Network restrictions and native web controls

Source-only fixture for Harbor 0.25.0, Linux Docker, Codex 0.167.0 and the selected
ChatGPT subscription. Two read-only services provide authenticated-by-content
HTTP, verified TLS, raw TCP and UDP exchanges, plus DNS/ICMP positive controls.
No host ports, mounts or live services are used. A separate verifier parses the
explicit project artifact and never executes submitted code.

Prepare outside the repository, using the selected Harbor interpreter. This
builds frozen local image IDs and a disposable self-signed TLS key/certificate.
The key belongs only to synthetic endpoints; no user credential is involved,
and no host certificate store changes. Public source never contains the key.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i09-network/prepare.py \
  --output /path/outside/repository/i09-public-profile
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i09-public-profile/docker-codex-i09-network \
  --output /path/outside/repository/i09-public-control --name i09-public-control \
  --agent oracle
```

The public Oracle control must establish that both endpoints respond on every
protocol before interpreting later denials. DNS and ICMP remain explicit
channels in the installed controller; no fully-offline claim follows.

## Allow-list qualification

After reviewing the public control, pin the exact controller built by the
selected installed Harbor source and copy the frozen task into a policy variant:

```sh
"$HARBOR_PYTHON" examples/docker-codex-i09-network/pin_controller.py \
  --output /path/outside/repository/controller.json
"$HARBOR_PYTHON" examples/docker-codex-i09-network/variant.py \
  --base /path/outside/repository/i09-public-profile \
  --output /path/outside/repository/i09-allowlist-profile --policy allowlist
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i09-allowlist-profile/docker-codex-i09-network \
  --output /path/outside/repository/i09-allowlist-control --name i09-allowlist-control \
  --agent oracle --egress-image sha256:CONTROLLER_IMAGE_PRINTED_ABOVE
```

The variant reuses all image IDs and the fixture certificate. The agent phase
allows the synthetic allowed hostname; setup uses public networking and the
end hook observes restoration to that baseline. The trusted controller alone
has NET_ADMIN/NET_RAW. Its image, entrypoint, privileges, mounts and host ports
are checked; spelling with Docker's CAP_ prefix is normalized. The agent stays
nonroot, shares the controller's network namespace and gains no capabilities.

HTTP Host and TLS SNI identify the allowed hostname. A TCP connect alone can
succeed at the transparent proxy even when the real exchange is denied. The
probe therefore checks response content. It also tests a public HTTPS endpoint;
a trusted verifier-side probe checks that endpoint under its own no-network
policy. These tests read public/synthetic data and send no account credentials.

The installed controller permits DNS and ICMP under restricted policies. Treat
this as measured TCP/UDP filtering, not a complete offline boundary. Other
protocols, IPv6, existing connections and adversarial bypasses are unqualified.
Fixture certificates last ten years to support later reruns; they are synthetic
and trusted only by this probe, never by the host's certificate store.

## No-network and native web cases

Use the same variant command with `--policy no-network` for the TCP/UDP deny
control. It still needs the pinned controller. Its DNS/ICMP results remain true
on this installed backend. The trusted verifier likewise records DNS resolution
while blocking HTTPS to the public positive-control endpoint.

For native web checks, add `--expected-web present` to a public variant and run
Codex with explicit `--web-search cached`. Then create an `absent` public variant
and run `--web-search disabled`. The participant instructions are identical;
expected capability and native configuration vary. Review the actual native web
call, not only WEB.json. All runs use the same Sol / High and existing ChatGPT
subscription route, with no model judges or API-key substitution.

The runner explicitly sets guest `features.apps=false`. This closes an observed
hosted Search Service path that survived `web_search="disabled"`; it changes no
account connection. The full rollout's nested `McpToolCall` events must be checked,
because compact stdout omitted that connector call. Built-in web mode and hosted
app access are separate controls. The default web mode remains disabled.

Finally, use an allow-list variant with `--expected-web absent`, request cached
web, and add only the subscription inference hosts at run level:

```sh
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task /path/outside/repository/i09-restricted-web-profile/docker-codex-i09-network \
  --output /path/outside/repository/i09-restricted-web-live --name i09-restricted-web \
  --agent codex --model openai/gpt-6.1-sol --effort high --codex-version 0.167.0 \
  --web-search cached --egress-image sha256:CONTROLLER_IMAGE_PRINTED_ABOVE \
  --allow-agent-host chatgpt.com --allow-agent-host auth.openai.com
```

Run-specific hosts replace Harbor's automatic inference-host additions. The
local allowed service stays in the task policy. The installed integration
normally disables native web tools under restricted policies; this case checks
that runtime result while real subscription inference and the allowed service
remain reachable. Every run uses a new output directory. This recipe qualifies
the stated profile; it is not a guarantee against DNS/ICMP disclosure, forged
Host/SNI, existing connections, other transports or adversarial reconfiguration.
