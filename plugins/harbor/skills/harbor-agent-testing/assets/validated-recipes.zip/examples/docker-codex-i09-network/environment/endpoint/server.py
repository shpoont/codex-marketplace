"""Read-only synthetic HTTP/TLS, TCP and UDP positive controls."""
import http.server,json,socketserver,ssl,sys,threading
role=sys.argv[1]
class Http(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        data=json.dumps({'service':role,'marker':'HARBOR-I09-'+role.upper()}).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
class Tcp(socketserver.StreamRequestHandler):
    def handle(self):
        if self.rfile.readline()==b'PING\n':self.wfile.write(('ECHO-'+role+'\n').encode())
class Udp(socketserver.BaseRequestHandler):
    def handle(self):
        data,sock=self.request
        if data==b'PING':sock.sendto(('ECHO-'+role).encode(),self.client_address)
http_server=http.server.ThreadingHTTPServer(('0.0.0.0',80),Http)
https_server=http.server.ThreadingHTTPServer(('0.0.0.0',443),Http)
ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain('/opt/fixture/tls/cert.pem','/opt/fixture/tls/key.pem');https_server.socket=ctx.wrap_socket(https_server.socket,server_side=True)
servers=[http_server,https_server,socketserver.ThreadingTCPServer(('0.0.0.0',19090),Tcp),socketserver.ThreadingUDPServer(('0.0.0.0',19091),Udp)]
for server in servers:threading.Thread(target=server.serve_forever,daemon=True).start()
threading.Event().wait()
