"""Protocol exchanges, not TCP connect-only network claims."""
import argparse,http.client,json,socket,ssl,subprocess,tomllib,os
from pathlib import Path

def exchange(role,kind):
    host=role+'.fixture.test';connected=False
    try:
        if kind in ['http','https']:
            conn=(http.client.HTTPSConnection(host,443,timeout=3,context=ssl.create_default_context(cafile='/opt/network/fixture-ca.pem')) if kind=='https' else http.client.HTTPConnection(host,80,timeout=3))
            try:
                conn.connect();connected=True
                conn.request('GET','/',headers={'Host':host})
                response=conn.getresponse();body=json.loads(response.read())
                return {'ok':response.status==200 and body=={'service':role,'marker':'HARBOR-I09-'+role.upper()},'connected':connected,'status':response.status}
            finally:conn.close()
        if kind=='tcp':
            with socket.create_connection((host,19090),timeout=3) as stream:
                connected=True;stream.sendall(b'PING\n');data=stream.recv(128)
                return {'ok':data==('ECHO-'+role+'\n').encode(),'connected':True}
        if kind=='udp':
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as stream:
                stream.settimeout(2);stream.sendto(b'PING',(host,19091));data,_=stream.recvfrom(128)
                return {'ok':data==('ECHO-'+role).encode()}
        if kind=='icmp':
            run=subprocess.run(['ping','-c','1','-W','1',host],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=3)
            return {'ok':run.returncode==0,'returncode':run.returncode}
        if kind=='dns':
            addresses=sorted({v[4][0] for v in socket.getaddrinfo(host,80,type=socket.SOCK_STREAM)})
            return {'ok':bool(addresses),'addresses':addresses}
    except (OSError,ValueError,TimeoutError,subprocess.TimeoutExpired,http.client.HTTPException) as exc:
        return {'ok':False,'connected':connected,'error':type(exc).__name__}

def external():
    result={}
    try:
        result['dns']=bool(socket.getaddrinfo('example.com',443,type=socket.SOCK_STREAM))
    except OSError:result['dns']=False
    connection=http.client.HTTPSConnection('example.com',443,timeout=3)
    try:
        connection.request('GET','/');response=connection.getresponse();response.read(4096)
        result.update(https=response.status==200,status=response.status)
    except (OSError,ValueError,http.client.HTTPException) as exc:
        result.update(https=False,error=type(exc).__name__)
    finally:connection.close()
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    config=Path('/installed-agent/codex-home/config.toml')
    native=tomllib.loads(config.read_text()) if config.exists() else {}
    results={role:{kind:exchange(role,kind) for kind in ['http','https','tcp','udp','icmp','dns']} for role in ['allowed','blocked']}
    report={'routes':results,'external':external(),'uid':os.getuid(),'native_web_search':native.get('web_search')}
    args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
