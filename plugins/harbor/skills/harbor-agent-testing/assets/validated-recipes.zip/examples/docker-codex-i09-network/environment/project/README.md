# Network boundary fixture

Only NETWORK.json is required by the network probe case.
