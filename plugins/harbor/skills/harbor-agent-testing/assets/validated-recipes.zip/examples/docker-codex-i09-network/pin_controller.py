"""Build/pin only the selected installed Harbor controller, without patching it."""
import argparse,asyncio,hashlib,json,subprocess
from pathlib import Path
from importlib.metadata import version
from harbor.environments.docker.docker import DockerEnvironment
from harbor.environments.docker.utils import default_docker_platform,ensure_docker_image_built
async def main(output):
    if version('harbor')!='0.25.0':raise ValueError('Selected installed Harbor 0.25.0 required')
    context=DockerEnvironment._EGRESS_CONTROL_SIDECAR_CONTEXT_PATH
    tag=await ensure_docker_image_built(docker_name=DockerEnvironment._EGRESS_CONTROL_SIDECAR_DOCKER_NAME,
        docker_build_context=context,dockerfile_path=context/'Dockerfile',build_args={},platform=await default_docker_platform())
    image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',tag],text=True).strip()
    record={'image':image,'native_tag':tag,'source_files':{str(p.relative_to(context)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(context.rglob('*')) if p.is_file()}}
    output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'image':image}))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();asyncio.run(main(args.output))
