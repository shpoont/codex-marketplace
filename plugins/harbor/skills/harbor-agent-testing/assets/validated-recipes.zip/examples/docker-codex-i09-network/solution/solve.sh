#!/bin/sh
set -eu
python3 /opt/network/probe.py --output /app/project/NETWORK.json
