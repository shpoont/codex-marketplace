"""Read-only JSON grading; no submitted code runs in the verifier."""
import json,os
from network_probe import external
from pathlib import Path
p=Path('/app/project')
try:report=json.loads((p/'NETWORK.json').read_text())
except (OSError,ValueError):report={}
mode=os.environ['EXPECTED_NETWORK'];web=os.environ['EXPECTED_WEB']
routes=report.get('routes',{})
checks={'report':set(routes)=={'allowed','blocked'},'uid':report.get('uid')==1000,
 'readme':(p/'README.md').read_text()=='# Network boundary fixture\n\nOnly NETWORK.json is required by the network probe case.\n',
 'no_agent_credentials_in_verifier':not any(f.exists() for f in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])}
for role in ['allowed','blocked']:
 for kind in ['http','https','tcp','udp','icmp','dns']:
  expected=(True if mode=='public' else kind in ['dns','icmp'] or (mode=='allowlist' and role=='allowed' and kind in ['http','https']))
  checks[role+'_'+kind]=routes.get(role,{}).get(kind,{}).get('ok')==expected
if web!='none':
 try:w=json.loads((p/'WEB.json').read_text())
 except (OSError,ValueError):w={}
 expected=web=='present'
 checks['web_available']=w.get('web_tool_available')==expected
 checks['web_used']=w.get('used_web_tool')==expected
 checks['native_web_mode']=report.get('native_web_search')==('cached' if expected else 'disabled')
 checks['source']=w.get('source_url')=='https://docs.harborframework.com/tasks/network-policies' if expected else w.get('source_url') is None
verifier_network=external()
checks['external_dns']=report.get('external',{}).get('dns') is True
checks['external_https']=report.get('external',{}).get('https')==(mode=='public')
checks['verifier_https_blocked']=verifier_network['https'] is False
checks['project_files']={f.name for f in p.iterdir()}==({'README.md','NETWORK.json','WEB.json'} if web!='none' else {'README.md','NETWORK.json'})
logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
(logs/'network.json').write_text(json.dumps(verifier_network,indent=2)+'\n')
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n');print(json.dumps(checks))
