# I10: data-only artifact transfer

A payment-summary task writes JSON to `/app/export`. The trusted verifier reads
data without importing submitted code. Shared mode grades the target filesystem;
separate mode grades declared exports rematerialized at their **original source
paths**. `destination="receipt-export"` names the host collection directory only.

Use installed Harbor **0.25.0**, Docker and the existing native Codex ChatGPT
sign-in. The image pins Codex **0.167.0**. Keep the selected Sol / High settings.
Set `HARBOR_PYTHON` to the existing Harbor environment's Python and
`TEST_EVIDENCE` to a new disposable evidence directory outside this repository.
Preparation builds both images once and records their immutable local IDs.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i10-transfer/prepare.py \
  --output "$TEST_EVIDENCE/transfer-profile"
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/transfer-profile/docker-codex-i10-transfer" \
  --output "$TEST_EVIDENCE/shared-native" --name i10-shared-native
```

Create and run each control separately, reviewing its manifest, summary,
`isolation.json`, exported files and cleanup before the next control:

```sh
"$HARBOR_PYTHON" examples/docker-codex-i10-transfer/control.py \
  --prepared "$TEST_EVIDENCE/transfer-profile/docker-codex-i10-transfer" \
  --output "$TEST_EVIDENCE/separate-good-task" --mode separate --control good
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/separate-good-task" \
  --output "$TEST_EVIDENCE/separate-good" --name i10-separate-good --agent oracle
```

Controls: `good` passes; `wrong` and `omitted` are valid task failures;
`unsafe` and `fifo` invalidate transfer; `excluded` passes with `scratch` absent
from host collection. `--no-exclude` exercises ordinary directory collection;
otherwise the fixture uses Harbor's exclusion path. Add the launcher's
`--missing-artifact-control` to a good task to test a missing harness-owned input:
a native positive reward must become an infrastructure error. Expected failure
controls return exit status 1; retain them as evidence.

The runner's companion `tooling/artifact_receipt.py` reads each explicitly
declared export once more at agent end, recording hashes/types through GNU tar's
actual exclusion selection. It compares native host collection without following
links and refuses entries the verifier transfer would remove. Preserve both
runner and companion hashes. A manifest status of `ok` alone is insufficient.
Special files and hardlink archive entries are explicitly unsupported by this
prototype receipt and invalidate evidence; internal relative links have unit
coverage only. Large exports and artifact mutation by surviving processes have
not been qualified. This is a small-snapshot recipe, not a general filesystem
transfer guarantee.

See the [separately reviewed results](../../docs/i10-transfer-and-worker.md).
This source recipe is not installed plugin behavior. No submitted code is
executed by its verifier; use the qualified
[Worker recipe](../docker-codex-i10-worker/README.md) for code grading.
