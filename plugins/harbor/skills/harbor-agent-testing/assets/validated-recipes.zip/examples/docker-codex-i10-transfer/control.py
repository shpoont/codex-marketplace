"""Make one disposable transfer control from a prepared, pinned task."""
import argparse
import json
from pathlib import Path
import shutil


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--prepared',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=['shared','separate'],required=True)
    p.add_argument('--control',choices=['good','wrong','omitted','unsafe','fifo','excluded'],required=True)
    p.add_argument('--no-exclude',action='store_true')
    a=p.parse_args()
    shutil.copytree(a.prepared,a.output)
    config=(a.output/'task.toml').read_text().replace('environment_mode = "shared"',f'environment_mode = "{a.mode}"')
    if a.no_exclude:config=config.replace(', exclude = ["scratch"]','')
    if a.mode=='separate':
        image=json.loads((a.prepared.parent/'images.json').read_text())['images']['verifier']
        config+=f'\n[verifier.environment]\ndocker_image = "{image}"\ncpus = 1\nmemory_mb = 512\nnetwork_mode = "no-network"\n'
    (a.output/'task.toml').write_text(config)
    script=(a.output/'solution/solve.sh').read_text()
    if a.control=='wrong':script=script.replace("'total_cents':4000","'total_cents':4800")
    if a.control=='omitted':script='#!/bin/sh\nset -eu\ntrue\n'
    if a.control=='unsafe':script+='ln -s /etc/hostname /app/export/zz-escape\n'
    if a.control=='fifo':script+='mkfifo /app/export/zz-pipe\n'
    if a.control=='excluded':script+='mkdir /app/export/scratch\nprintf "synthetic excluded note\\n" > /app/export/scratch/note.txt\n'
    (a.output/'solution/solve.sh').write_text(script)


if __name__=='__main__':main()
