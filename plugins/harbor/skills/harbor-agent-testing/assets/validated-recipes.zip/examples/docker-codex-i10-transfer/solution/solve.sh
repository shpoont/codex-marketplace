#!/bin/sh
set -eu
python3 - <<'PYCODE'
import json
from pathlib import Path
Path('/app/export/receipt.json').write_text(json.dumps({'paid_orders':2,'total_cents':4000,'currency':'EUR'})+'\n')
PYCODE
