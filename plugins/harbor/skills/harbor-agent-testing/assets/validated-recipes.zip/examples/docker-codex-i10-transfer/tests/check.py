"""Grade JSON data only; never execute submitted code."""
import json
from pathlib import Path
checks={}
try:
    checks['receipt']=json.loads(Path('/app/export/receipt.json').read_text())=={'paid_orders':2,'total_cents':4000,'currency':'EUR'}
except (OSError,ValueError):checks['receipt']=False
checks['original_source_path']=Path('/app/project/orders.csv').is_file()
checks['no_agent_credentials_in_verifier']=not any(p.exists() for p in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])
logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks))
