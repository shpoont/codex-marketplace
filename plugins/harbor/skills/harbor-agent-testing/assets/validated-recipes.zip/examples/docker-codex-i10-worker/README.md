# I10: protected submitted-code grading

The target implements a standard-library payment-summary program. Only the
separate trusted verifier executes it for grading, using released RewardKit
**0.2.4** `Worker`. The verifier tests an empty list and mixed paid/pending orders
including a negative adjustment. Grading files, reward files and a separate
private reference directory are protected explicitly. No model judge is used.

Use the same installed Harbor **0.25.0**, guest Codex **0.167.0**, Sol / High and
existing ChatGPT sign-in. Set `HARBOR_PYTHON` to the installed Harbor environment's
Python and `TEST_EVIDENCE` to a fresh disposable evidence root outside Git.
RewardKit is installed **only in the verifier image**, from the exact published
wheel URL and SHA-256 in its Dockerfile. Resolved dependencies are frozen by the
resulting local image ID. Do not install it into the host Harbor environment.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i10-worker/prepare.py \
  --output "$TEST_EVIDENCE/worker-profile"
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/worker-profile/docker-codex-i10-worker" \
  --output "$TEST_EVIDENCE/worker-good" --name i10-worker-good --agent oracle
```

Review that result before creating the next control with `control.py`:

```sh
"$HARBOR_PYTHON" examples/docker-codex-i10-worker/control.py \
  --prepared "$TEST_EVIDENCE/worker-profile/docker-codex-i10-worker" \
  --output "$TEST_EVIDENCE/worker-wrong-task" --control wrong
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/worker-wrong-task" \
  --output "$TEST_EVIDENCE/worker-wrong" --name i10-worker-wrong --agent oracle
```

Run each control in a fresh output directory and review before continuing:

- `wrong`: counts pending amounts; valid task rejection, reward 0.
- `probe`: synthetic submission attempts grading/reference/process-state reads,
  grader/reward writes, environment inheritance and a surviving child. Reward 1
  here means the **protection control** succeeded, not that attack code solved
  the payment task.
- `setup-failure`: a symlink in the configured private-path boundary triggers a
  real `WorkerSetupError` before submitted code runs; no numeric reward.
- `cleanup-failure`: a trusted in-memory fault injection makes the official
  cleanup helper report failure. It must raise `WorkerSetupError`, produce no
  reward and discard the container. No installed package file is patched.

After controls pass, run the original prepared task without `--agent oracle` for
native Sol / High code generation. Review submitted files, actual Worker outputs,
`verifier/boundary.json`, `checks.json`, collection and cleanup. Target self-checks
use its public workspace; they do not replace protected grading.

Root belongs only to the disposable verifier. Worker uses a fresh unprivileged
UID, empty supplementary groups, zero effective capabilities and no-new-privs.
The target stays UID 1000 with no extra capabilities, host mounts or Docker
socket. Worker needs no additional container capabilities. Harbor's separate
no-network verifier uses its official network-controller sidecar with
NET_ADMIN/NET_RAW; the [I09 networking limits](../../docs/i09-network-and-web-controls.md)
still apply. Root does not imply a fully offline or general-purpose secure VM.

This qualifies selected deterministic programs and adversarial controls, not
all possible attacks, languages, concurrent graders or hostile host mounts.
Every grading-data location must be added to `private_paths`; defaults alone
cannot protect an arbitrary project. Keep setup/cleanup errors separate from
quality scores. See the [reviewed I10 evidence](../../docs/i10-transfer-and-worker.md).
