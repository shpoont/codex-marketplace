"""Make one immutable Worker control; no live model is needed for calibration."""
import argparse
from pathlib import Path
import shutil
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--prepared',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--control',choices=['wrong','probe','setup-failure','cleanup-failure'],required=True)
a=p.parse_args()
shutil.copytree(a.prepared,a.output)
if a.control=='wrong':
    s=a.output/'solution/solve.sh';s.write_text(s.read_text().replace("sum(o['amount_cents'] for o in paid)","sum(o['amount_cents'] for o in orders)"))
else:
    c=a.output/'task.toml';c.write_text(c.read_text().replace('I10_CONTROL = "grade"',f'I10_CONTROL = "{a.control}"'))
    if a.control=='probe':
        probe=(Path(__file__).parent/'calibration/probe.py').read_text()
        (a.output/'solution/solve.sh').write_text("#!/bin/sh\nset -eu\ncat > /app/project/summarize.py <<'I10_PROBE'\n"+probe+'I10_PROBE\n')
