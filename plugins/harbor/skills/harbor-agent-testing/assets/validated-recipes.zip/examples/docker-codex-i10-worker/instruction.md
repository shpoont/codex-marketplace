Implement /app/project/summarize.py as described in README.md. Do not change README.md. Use python3. Do not install packages or run grading code.
