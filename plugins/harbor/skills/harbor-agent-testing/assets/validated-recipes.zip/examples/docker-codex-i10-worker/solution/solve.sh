#!/bin/sh
set -eu
cat > /app/project/summarize.py <<'PYCODE'
import json,sys
orders=json.load(sys.stdin)
paid=[o for o in orders if o['status']=='paid']
print(json.dumps({'paid_orders':len(paid),'total_cents':sum(o['amount_cents'] for o in paid)}))
PYCODE
