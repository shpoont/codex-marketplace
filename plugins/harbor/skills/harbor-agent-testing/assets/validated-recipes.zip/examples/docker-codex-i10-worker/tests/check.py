"""Trusted deterministic grading. Submitted code runs only through released Worker."""
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import sys
import rewardkit.sandbox as sandbox
from rewardkit import Worker, WorkerError, WorkerSetupError

logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
private=(Path('/tests'),logs,Path('/grading'),Path('/trusted-state'))
cases=[([],{'paid_orders':0,'total_cents':0}),
       ([{'status':'paid','amount_cents':1200},{'status':'pending','amount_cents':500},{'status':'paid','amount_cents':-200}],{'paid_orders':2,'total_cents':1000})]
Path('/grading/reference/cases.json').write_text(json.dumps(cases))
sentinel=logs/'score-sentinel.json';sentinel.write_text('trusted-score-sentinel\n')
protected={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
           [Path('/tests/check.py'),Path('/grading/reference/cases.json'),Path('/trusted-state/canary.txt'),sentinel]}
control=os.environ.get('I10_CONTROL','grade')
os.environ['I10_PARENT_ONLY']='synthetic-parent-only'
checks={'no_agent_credentials_in_verifier':not any(p.exists() for p in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])}
boundary={'rewardkit_version':version('harbor-rewardkit'),'sandbox_sha256':hashlib.sha256(Path(sandbox.__file__).read_bytes()).hexdigest(),
          'verifier_uid':os.getuid(),'private_paths':[str(p) for p in private],
          'cap_eff':next(x.split(':',1)[1].strip() for x in Path('/proc/self/status').read_text().splitlines() if x.startswith('CapEff:')),
          'relevant_mounts':[line.split()[4] for line in Path('/proc/self/mountinfo').read_text().splitlines() if any(line.split()[4]==str(p) for p in private)],
          'docker_socket_absent':not Path('/var/run/docker.sock').exists(),'control':control,'runs':[]}
assert boundary['rewardkit_version']=='0.2.4'
assert boundary['sandbox_sha256']=='b5d5b5e5eb4abb9fbd8c3238d219f3e25864e674cd2ffe7084e5dfd2fc417144'
try:
    if control=='setup-failure':
        Path('/unsafe-private').symlink_to('/tests')
        private=(*private,Path('/unsafe-private'))
    if control=='cleanup-failure':
        # Fault injection in the disposable verifier only; no package-file edits.
        sandbox._kill_all=lambda uid:False
    worker=Worker(private_paths=private,max_output_bytes=65536)
    if control in ('setup-failure','cleanup-failure'):
        worker.run('true',timeout_sec=5)
        raise RuntimeError('Fault control unexpectedly succeeded')
    if control=='probe':
        result=worker.run('python3 summarize.py',files=[Path('/app/project/summarize.py')],
                          stdin=json.dumps({'trusted_pid':os.getpid()}).encode(),outputs=['probe.json'],timeout_sec=10)
        report=json.loads(result.files.get('probe.json',b'{}'))
        boundary['runs'].append({'returncode':result.returncode,'report':report})
        expected={'tests_read','grading_read','other_private_read','reward_write','score_write','grader_write','proc_env','proc_mem','proc_fd'}
        checks['denials']=set(report.get('denied',[]))==expected
        checks['unprivileged']=report.get('uid',0)!=0 and report.get('cap_eff')=='0000000000000000' and report.get('no_new_privs')==1 and report.get('groups')==[]
        checks['environment_not_inherited']=report.get('parent_env_absent') is True
        pid=report.get('child_pid')
        status=Path(f'/proc/{pid}/status') if isinstance(pid,int) else None
        checks['descendants_cleaned']=bool(status) and (not status.exists() or '\nState:\tZ' in status.read_text())
        checks['probe_exit']=result.returncode==0
    else:
        outcomes=[]
        for data,expected in cases:
            result=worker.run('python3 summarize.py',files=[Path('/app/project/summarize.py')],stdin=json.dumps(data).encode(),timeout_sec=10)
            try:actual=json.loads(result.stdout)
            except ValueError:actual=None
            outcomes.append(result.returncode==0 and actual==expected)
            boundary['runs'].append({'returncode':result.returncode,'actual':actual,'expected':expected})
        checks['correctness']=all(outcomes)
    checks['trusted_files_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in protected.items())
    checks['worker_boundary_ok']=True
except WorkerSetupError as exc:
    checks['worker_boundary_ok']=False
    boundary['infrastructure_error']={'type':type(exc).__name__,'message':str(exc)}
    (logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (logs/'boundary.json').write_text(json.dumps(boundary,indent=2)+'\n')
    (logs/'reward.json').unlink(missing_ok=True)
    print(json.dumps(boundary['infrastructure_error']))
    sys.exit(2)
except WorkerError as exc:
    checks['correctness']=False
    checks['worker_boundary_ok']=True
    boundary['submission_error']={'type':type(exc).__name__,'message':str(exc)}
checks['trusted_files_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in protected.items())
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(logs/'boundary.json').write_text(json.dumps(boundary,indent=2)+'\n')
(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks))
