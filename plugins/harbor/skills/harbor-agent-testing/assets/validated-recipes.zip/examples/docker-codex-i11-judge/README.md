# I11: subscription Codex judge and recorded-output regrading

The target writes a customer incident update from approved facts. Deterministic
checks require a message and an unchanged brief. A single batched Codex judge
assesses accuracy, useful customer action and clarity. Accuracy/action are
mandatory; clarity remains a separate normalized partial score. Evaluator-directed
text is flagged descriptively and cannot change the rubric.

Use installed Harbor **0.25.0**, guest Codex **0.167.0**, released RewardKit
**0.2.4**, **GPT-6.1 Sol / High** for target and judge, and the existing ChatGPT
sign-in. RewardKit and judge dependencies live only in Docker. Set
`HARBOR_PYTHON` to the installed Harbor environment's Python and `TEST_EVIDENCE`
to a new evidence root outside Git. Keep asdf runtime/CLI directories on PATH.

## Prepare, calibrate, then run

```sh
"$HARBOR_PYTHON" examples/docker-codex-i11-judge/prepare.py \
  --output "$TEST_EVIDENCE/judge-profile"
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/judge-profile/docker-codex-i11-judge" \
  --output "$TEST_EVIDENCE/judge-good" --name i11-good \
  --agent oracle --subscription-judge
```

`oracle` produces a known calibration submission here. **Its verifier still
calls the real Codex judge.** Review each result before creating the next control
with `control.py --prepared … --output … --control …`, then run that control's
task with `--agent oracle --subscription-judge`:

- `bad`: unsupported recovery/duplicate-charge guarantees; valid quality zero.
- `alternative`: different legitimate wording; accepted.
- `injection`: bad message plus evaluator-directed instructions; rejected and
  guard flagged in the qualified case. Guard mode is descriptive, not immunity.
- `timeout`: real one-second judge startup limit; errored zeros are retained in
  details but no valid reward is emitted.
- `parse-error`: model-free malformed-response injection through RewardKit's
  actual parser/retry loop; no credential stream or model call.
- `omitted`, `changed-brief`: deterministic task rejections, with no judge call
  and no invented judge-dimension scores.

Expected rejections/errors return status 1; keep the records. After calibration,
run the original prepared task without `--agent oracle` for a fresh target
attempt followed by judgment. Each output directory must be new.

```sh
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/judge-profile/docker-codex-i11-judge" \
  --output "$TEST_EVIDENCE/agent-and-judge" --name i11-agent-judge \
  --subscription-judge
```

`probe_subscription.py --image sha256:… --output …` is a separate model-free,
network-disabled Docker check. It supplies synthetic invalid API-key canaries,
forces subscription selection, checks native ChatGPT login status and confirms
child-variable removal and temporary-home cleanup without showing credentials.

## Credential and capability boundary

`tooling/subscription_judge_verifier.py` uses Harbor's supported custom-verifier
hook. It passes the configured native session file handle to `docker exec` stdin;
credential contents never enter host job configuration, argv or a host copy.
RewardKit consumes `CODEX_AUTH_JSON` in guest process memory with
`REWARDKIT_FORCE_SUBSCRIPTION=1`, internally creates a temporary native Codex home
and removes it before evidence collection. Never put raw credentials in
`verifier.env` or `--verifier-env`. Judge credentials are distinct from the
evaluated agent's temporary credentials.

The trusted judge runs in a separate pinned container with no host mounts,
extra capabilities or published ports. The guest CLI wrapper preserves native
Codex inference/authentication while enforcing read-only mode and disabling web,
apps, shell/unified execution and delegation. All judgment evidence is inline;
selected live histories showed no tool calls. This is bounded protection, not
proof against every injection or credential attack. Do not execute submitted
code in this data-only grader; use the I10 Worker route when needed.

RewardKit's installed timeout path returns errored numeric zeros, and its error/
parse path permits up to three backend attempts. The validity adapter rejects
warnings, score errors, missing/duplicate/nonfinite scores and failed cleanup.
Trial retries are disabled. Record every actual judge attempt; `samples=1` does
not remove RewardKit's internal error retries. Target and judge usage are kept
separate. Price estimates do not establish subscription billing.

## Regrade without a new target attempt

The example revision changes only clarity anchors from three to five points;
mandatory facts/actions remain unchanged. Build only the revised verifier while
retaining the original prepared agent configuration and image pin:

```sh
"$HARBOR_PYTHON" examples/docker-codex-i11-judge/prepare_regrade.py \
  --prepared "$TEST_EVIDENCE/judge-profile/docker-codex-i11-judge" \
  --output "$TEST_EVIDENCE/regrade-profile"
"$HARBOR_PYTHON" tooling/regrade_docker_case.py \
  --source-job "$TEST_EVIDENCE/agent-and-judge/jobs/i11-agent-judge" \
  --task "$TEST_EVIDENCE/regrade-profile/docker-codex-i11-judge" \
  --output "$TEST_EVIDENCE/regrade-generated" --name i11-regrade-generated
```

The source-job path must identify the completed native job, not its wrapper
output root. The helper delegates to native Harbor `source_jobs` derivation,
uses one concurrent regrade and disables job retries. Native regrading requires
separate verification and available declared exports. It copies original agent
logs/usage as historical evidence; those copied counters are **not new target
usage**. New judge usage belongs to the regrade.

Review source-file hashes, artifact byte identity, native source-trial lineage,
absence of new agent events/timing, new judge history and the verdict before the
next regrade. Derived output inside source-job/task directories is refused.
Missing exports and shared-mode targets are input errors, not quality zeros;
retain originals and repair inputs rather than silently rerunning the agent.

See [reviewed I11 results and limits](../../docs/i11-subscription-judge-and-regrade.md).
This qualifies the selected single-step text cases, not trajectory judges,
multistep regrading, generic scoring trees or real-project judge accuracy.
