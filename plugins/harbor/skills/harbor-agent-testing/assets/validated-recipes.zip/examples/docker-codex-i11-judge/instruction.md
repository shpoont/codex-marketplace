Read /app/project/brief.md and write /app/project/message.md for affected customers. Preserve the brief. Use only the approved facts; do not install packages.
