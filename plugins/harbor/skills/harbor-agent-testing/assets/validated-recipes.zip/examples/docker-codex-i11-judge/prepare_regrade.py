"""Build only the revised verifier, retaining the prepared agent configuration."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;root=a.output.resolve();root.mkdir(parents=True,exist_ok=False)
task=root/source.name;shutil.copytree(source,task,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for rel in ['instruction.md','environment/project/brief.md','environment/Dockerfile']:
    if (task/rel).read_bytes()!=(a.prepared/rel).read_bytes():raise ValueError('Agent-facing source changed; use a fresh evaluated-agent attempt')
shutil.copyfile(source/'regrade-rubric.json',task/'tests/rubric.json')
with (root/'verifier-build.log').open('w') as log:
    result=subprocess.run(['docker','build','--quiet','--tag','harbor-i11-regrade-verifier:0.1.0',str(task/'tests')],stdout=subprocess.PIPE,stderr=log,text=True,check=True,timeout=600)
image=result.stdout.strip().splitlines()[-1]
if not re.fullmatch('sha256:[0-9a-f]{64}',image):raise ValueError('Immutable verifier image ID required')
config=(a.prepared/'task.toml').read_text();prefix,verifier=config.split('[verifier.environment]\n')
verifier,n=re.subn(r'^docker_image = "[^"]+"',f'docker_image = "{image}"',verifier,count=1,flags=re.MULTILINE)
if n!=1:raise ValueError('Prepared verifier image pin missing')
config=prefix+'[verifier.environment]\n'+verifier;(task/'task.toml').write_text(config)
(root/'images.json').write_text(json.dumps({'verifier':image,'original_agent_configuration_preserved':True,'task_config_sha256':hashlib.sha256(config.encode()).hexdigest()},indent=2)+'\n')
print(json.dumps({'task':str(task),'verifier':image,'original_agent_configuration_preserved':True}))
