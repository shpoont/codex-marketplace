"""Model-free native sign-in/precedence check; stream only to disposable Docker."""
import argparse,json,os,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
if not re.fullmatch('sha256:[0-9a-f]{64}',a.image):raise ValueError('Immutable local image ID required')
login=subprocess.run(['codex','login','status'],capture_output=True)
if login.returncode or b'ChatGPT' not in login.stdout+login.stderr:raise RuntimeError('Existing ChatGPT sign-in required')
script=r'''
import asyncio,json,os,subprocess,sys
from pathlib import Path
from rewardkit import AgentJudge
from rewardkit.agents import CodexBackend
os.environ['CODEX_AUTH_JSON']=sys.stdin.buffer.read().decode()
os.environ['REWARDKIT_FORCE_SUBSCRIPTION']='1'
os.environ['OPENAI_API_KEY']='I11_SYNTHETIC_INVALID_KEY_CANARY'
os.environ['CODEX_API_KEY']='I11_SYNTHETIC_INVALID_KEY_CANARY'
async def check():
    backend=CodexBackend(AgentJudge(agent='codex',model='openai/gpt-6.1-sol',reasoning_effort='high',version='0.167.0'),'/app')
    async with backend:
        home=backend.codex_home
        status=subprocess.run([str(backend.binary),'login','status'],env=backend.env,capture_output=True)
        clean=all(not backend.env.get(k) for k in ['OPENAI_API_KEY','CODEX_API_KEY','CODEX_AUTH_JSON','REWARDKIT_FORCE_SUBSCRIPTION'])
        report={'native_chatgpt_sign_in':status.returncode==0 and b'ChatGPT' in status.stdout+status.stderr,'synthetic_keys_and_bridge_variables_absent_in_child':clean,'temporary_home_exists_during_use':home.is_dir(),'model_calls':0}
    report['temporary_home_removed']=not home.exists()
    assert all(v for k,v in report.items() if k!='model_calls')
    print(json.dumps(report))
asyncio.run(check())
'''
auth=Path(os.environ.get('CODEX_AUTH_JSON_PATH',str(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'auth.json')))
with auth.open('rb') as session:
    result=subprocess.run(['docker','run','--rm','-i','--network','none',a.image,'python3','-c',script],stdin=session,capture_output=True,timeout=45)
if result.returncode:raise RuntimeError('Subscription probe failed; no credential output is returned')
report=json.loads(result.stdout);a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
