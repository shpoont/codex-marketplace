#!/bin/sh
set -eu
cat > /app/project/message.md <<'I11_MESSAGE'
Invoice exports are delayed for some customers while we drain a retry backlog. We have not observed duplicate charges, but recovery is not yet confirmed. You do not need to retry or take any action. We will post another update at 16:00 UTC today, even if recovery is still underway. Thank you for your patience.
I11_MESSAGE
