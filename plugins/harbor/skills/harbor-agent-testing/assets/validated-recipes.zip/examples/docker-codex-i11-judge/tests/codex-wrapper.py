#!/usr/local/bin/python3
"""Lock CLI capabilities that RewardKit 0.2.4's AgentJudge does not expose."""
import os,sys
args=sys.argv[1:]
if args and args[0]=='exec':
    if '--sandbox' in args:args[args.index('--sandbox')+1]='read-only'
    args[1:1]=['-c','web_search="disabled"','-c','features.apps=false',
               '-c','features.multi_agent=false','-c','features.shell_tool=false',
               '-c','features.unified_exec=false']
os.execv('/usr/local/bin/node',['node','/opt/codex/bin/codex.js',*args])
