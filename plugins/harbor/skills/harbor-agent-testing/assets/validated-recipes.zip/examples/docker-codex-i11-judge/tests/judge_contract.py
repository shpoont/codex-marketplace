"""Validity and mandatory acceptance stay separate from normalized quality."""
import math


def submission_checks(project, reference):
    brief=project/'brief.md'
    message=project/'message.md'
    return {'brief_preserved':brief.is_file() and brief.read_bytes()==reference.read_bytes(),
            'message_present':message.is_file()}


def rewards_from_details(details,rubric):
    scores=details['scores']
    if details.get('warnings') or any(s.get('error') for s in scores):
        raise ValueError('Judge warnings or criterion errors invalidate the score')
    expected={c['name'] for c in rubric['criteria']}
    if len(scores)!=len(expected) or {s['name'] for s in scores}!=expected:
        raise ValueError('Incomplete or duplicate criterion scores')
    values={s['name']:s['value'] for s in scores}
    if any(not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or not 0<=v<=1 for v in values.values()):
        raise ValueError('Invalid normalized score')
    accepted=all(values[n]==1 for n in rubric['mandatory'])
    return {'reward':float(accepted),**values},accepted
