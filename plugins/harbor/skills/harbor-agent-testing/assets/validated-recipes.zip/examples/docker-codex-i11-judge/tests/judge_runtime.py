"""Bound the actual rendered input of the qualified, single batched Codex judge.

This process-local adapter leaves RewardKit's renderer and scoring intact. It
opens the original backend only after checking the exact prompt passed to run.
No credentials, evidence bodies or model outputs enter its audit record.
"""
from contextlib import AsyncExitStack, asynccontextmanager
from importlib.metadata import version
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

MAX_CODEX_CHARACTERS = 1048576  # Verified on guest Codex 0.167.0 without inference.
_active = False


class JudgeInputError(ValueError):
    pass


class JudgeAttemptError(RuntimeError):
    pass


def validate_prompt(prompt):
    if not isinstance(prompt, str) or not prompt:
        raise JudgeInputError('Nonempty fully rendered judge input required')
    if len(prompt) > MAX_CODEX_CHARACTERS:
        raise JudgeInputError('Fully rendered judge input exceeds Codex 0.167.0 character limit')


async def arun_guarded(judge, criteria, *, system_prompt, audit_path,
                       weights=None, workspace=None, max_native_attempts=None):
    global _active
    if version('harbor-rewardkit') != '0.2.4':
        raise ValueError('Judge adapter requires qualified RewardKit 0.2.4')
    if (judge.agent != 'codex' or judge.version != '0.167.0'
            or judge.mode != 'batched' or judge.samples != 1):
        raise ValueError('Judge adapter requires the qualified single batched Codex 0.167.0 profile')
    if _active:
        raise RuntimeError('Concurrent process-local judge adapter calls are not qualified')
    if max_native_attempts is not None and (type(max_native_attempts) is not int or max_native_attempts < 1):
        raise ValueError('An explicit native-attempt limit must be a positive integer')
    import rewardkit.judges as sdk
    factory = sdk.get_agent
    audit = {'rewardkit': '0.2.4', 'codex': '0.167.0',
             'character_limit': MAX_CODEX_CHARACTERS, 'max_native_attempts': max_native_attempts,
             'sdk_calls': 0, 'forwarded_calls': [], 'blocked': [],
             'usage_provenance': 'SDK-normalized counters; native field presence is unknown here. Consult retained native sessions.'}

    @asynccontextmanager
    async def lazy_factory(*args, **kwargs):
        async with AsyncExitStack() as stack:
            backend = None

            class Backend:
                async def run(self, prompt, schema, label):
                    nonlocal backend
                    audit['sdk_calls'] += 1
                    try:
                        validate_prompt(prompt)
                    except JudgeInputError:
                        audit['blocked'].append({'reason': 'input_too_large_or_invalid',
                            'characters': len(prompt) if isinstance(prompt, str) else None})
                        raise
                    if max_native_attempts is not None and len(audit['forwarded_calls']) >= max_native_attempts:
                        audit['blocked'].append({'reason': 'native_attempt_limit', 'label': label})
                        raise JudgeAttemptError('Selected judge native-attempt limit reached')
                    if backend is None:
                        backend = await stack.enter_async_context(factory(*args, **kwargs))
                    row = {'label': label, 'characters': len(prompt),
                           'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
                           'outcome': 'unknown', 'sdk_normalized_usage': None}
                    audit['forwarded_calls'].append(row)
                    attempt = await backend.run(prompt, schema, label)
                    row['outcome'] = ('timeout' if attempt.timed_out else 'backend_error'
                                      if attempt.error is not None else 'returned_unvalidated_output')
                    # Preserve the SDK's counters even if parsing later fails.
                    # It may default absent native fields to 0; these values
                    # do not establish native presence or complete usage.
                    known = {key: attempt.usage[key] for key in
                             ('input_tokens', 'cache_read_input_tokens', 'output_tokens',
                              'reasoning_output_tokens', 'total_tokens')
                             if type(attempt.usage.get(key)) is int and attempt.usage[key] >= 0}
                    row['sdk_normalized_usage'] = known or None
                    return attempt

            yield Backend()

    _active = True
    try:
        with patch.object(sdk, 'get_agent', lazy_factory):
            return await sdk.arun_agent(judge, criteria, weights=weights,
                                       workspace=workspace, system_prompt=system_prompt)
    finally:
        _active = False
        Path(audit_path).write_text(json.dumps(audit, indent=2) + '\n')
