#!/bin/sh
# Authentication arrives over stdin through the source verifier bridge.
exec python3 /tests/check.py
