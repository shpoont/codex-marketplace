# I12: native Exec map and reviewed reducer

This source recipe uses installed Harbor **0.25.0**, guest Codex **0.167.0**,
**GPT-6.1 Sol / High** and the existing ChatGPT sign-in. One map task summarizes
paid orders without changing its CSV. The reducer consumes that retained JSON,
reports the totals and identifies the exact source bytes by SHA-256. Separate
data-only verifiers check semantics, preservation and lineage.

Set `HARBOR_PYTHON` to the installed Harbor environment's Python and
`TEST_EVIDENCE` to a new evidence root outside Git. Keep asdf/CLI directories
on PATH. Each preparation/run output directory must be new.

## Map, then review

```sh
"$HARBOR_PYTHON" examples/docker-codex-i12-exec/prepare.py \
  --output "$TEST_EVIDENCE/map-profile"
"$HARBOR_PYTHON" tooling/run_exec_case.py \
  --prepared "$TEST_EVIDENCE/map-profile" \
  --output "$TEST_EVIDENCE/map-good" --agent oracle
```

Review the calibration, including `summary.json`, isolation observations,
collection receipt and verifier checks. Run the original profile without
`--agent oracle` into a new output directory for the real map attempt:

```sh
"$HARBOR_PYTHON" tooling/run_exec_case.py \
  --prepared "$TEST_EVIDENCE/map-profile" \
  --output "$TEST_EVIDENCE/map-native"
```

The launcher calls native `Executor.execute()` with no reduce configuration.
The paid count is 3, pending count 1 and net 5,000 cents; pending money must
not enter the paid total. File existence alone cannot pass.

## Reducer from the reviewed map

Proceed only after reviewing the map result and retained artifacts.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i12-exec/prepare_reducer.py \
  --map-prepared "$TEST_EVIDENCE/map-profile" \
  --output "$TEST_EVIDENCE/reducer-profile"
"$HARBOR_PYTHON" tooling/run_exec_reduce.py \
  --map-run "$TEST_EVIDENCE/map-native" \
  --prepared "$TEST_EVIDENCE/reducer-profile" \
  --output "$TEST_EVIDENCE/reducer-good" --agent oracle
```

Review that control, then run the same command without `--agent oracle` into
a new output directory. The source map is never rerun. The launcher refuses a
failed map, changed receipt or inconsistent native trial URI before startup.
Native staging is compared to the complete retained artifact tree. Both staged
inputs and output are exported, and source map bytes are checked afterward.
Correct totals with a forged source digest are rejected.

This checkpoint uses the installed native `_compile_reduce_task()` and
`_run_job()` APIs. It rehydrates trial results from their actual native records;
the aggregate job JSON omits them. These internal APIs require requalification
on a Harbor upgrade. The automatic combined map/reduce pipeline and map fanout
were not qualified by this increment.

## Measured setup corrections

- Native loose uploads preserved host ownership. The observer repairs ownership
  only under `/app/project` in the already verified unmounted container, refuses
  links/special entries and checks that bytes/modes remain unchanged. Staged
  reducer artifacts retain their original ownership and stay read-only to node.
- Native Exec's config round trip masks a literal auth path. The launcher sets
  the same configured path only in its process environment and saves the native
  `${CODEX_AUTH_JSON_PATH}` placeholder. Credentials remain under Harbor's
  temporary native-session handling; no raw secret is placed in saved config.
- A reducer template Dockerfile suppresses native loose-artifact upload when a
  prebuilt image is selected. The reducer template deliberately contains no
  Dockerfile; it reuses the frozen map agent image.

Both roles run as UID 1000 with no host mounts, Docker socket, added capabilities
or privileged mode. Web/apps/delegation are disabled. Job retries are disabled.
Original setup failures and separate corrections remain in the
[reviewed I12 record](../../docs/i12-exec-and-imported-task.md).
