"""Freeze the task template and Docker images before native Exec compilation."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;root=a.output.resolve()
if root.is_relative_to(source):raise ValueError('Preparation output must be outside source')
root.mkdir(parents=True,exist_ok=False);images={}
for role,context in [('agent','template/environment'),('verifier','template/tests')]:
    with (root/(role+'-build.log')).open('w') as log:
        r=subprocess.run(['docker','build','--quiet','--tag','harbor-i12-'+role+':0.1.0',str(source/context)],stdout=subprocess.PIPE,stderr=log,text=True,check=True,timeout=600)
    image=r.stdout.strip().splitlines()[-1]
    if not re.fullmatch('sha256:[0-9a-f]{64}',image):raise ValueError('Immutable image ID required')
    images[role]=image
shutil.copytree(source/'template',root/'template',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copytree(source/'inputs',root/'inputs');shutil.copyfile(source/'map.md',root/'map.md')
p=root/'template/task.toml';s=p.read_text()
for section,role in [('environment','agent'),('verifier.environment','verifier')]:s=s.replace('['+section+']\n','['+section+']\ndocker_image = "'+images[role]+'"\n')
p.write_text(s)
(root/'images.json').write_text(json.dumps(images,indent=2)+'\n');print(json.dumps({'prepared':str(root),'images':images}))
