"""Freeze the reducer verifier without rebuilding the qualified map agent image."""
import argparse,json,re,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--map-prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;root=a.output.resolve();root.mkdir(parents=True,exist_ok=False)
shutil.copytree(source/'reducer',root/'template',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
with (root/'verifier-build.log').open('w') as log:
 r=subprocess.run(['docker','build','--quiet','--tag','harbor-i12-reducer-verifier:0.1.0',str(source/'reducer/tests')],stdout=subprocess.PIPE,stderr=log,text=True,check=True,timeout=600)
image=r.stdout.strip().splitlines()[-1]
if not re.fullmatch('sha256:[0-9a-f]{64}',image):raise ValueError('Immutable verifier image ID required')
agent=json.loads((a.map_prepared/'images.json').read_text())['agent']
p=root/'template/task.toml';s=p.read_text().replace('[environment]\n','[environment]\ndocker_image = "'+agent+'"\n').replace('[verifier.environment]\n','[verifier.environment]\ndocker_image = "'+image+'"\n');p.write_text(s)
(root/'images.json').write_text(json.dumps({'agent':agent,'verifier':image},indent=2)+'\n');print(json.dumps({'prepared':str(root),'agent':agent,'verifier':image}))
