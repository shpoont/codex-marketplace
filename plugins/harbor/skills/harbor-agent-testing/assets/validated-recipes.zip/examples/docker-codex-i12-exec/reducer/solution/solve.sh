#!/bin/sh
set -eu
python3 - <<'PY'
import hashlib,json
from pathlib import Path
p=next(Path('/app/artifacts').glob('*/project/analysis.json'));data=json.loads(p.read_text())
Path('/app/project/rollup.json').write_text(json.dumps({'currency':data['currency'],'net_cents':data['net_cents'],'paid_count':data['paid_count'],'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})+'\n')
PY
