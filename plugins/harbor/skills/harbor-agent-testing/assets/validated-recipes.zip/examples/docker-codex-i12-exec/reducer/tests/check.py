"""Data-only grading; canonical source hash arrives in trusted verifier config."""
import hashlib,json,os
from pathlib import Path
source=list(Path('/app/artifacts').glob('*/project/analysis.json'))
expected_sha=os.environ['I12_SOURCE_SHA256']
checks={'source_lineage':len(source)==1 and hashlib.sha256(source[0].read_bytes()).hexdigest()==expected_sha,
        'no_agent_credentials_in_verifier':not any(p.exists() for p in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])}
try:checks['semantic_rollup']=json.loads(Path('/app/project/rollup.json').read_text())=={'currency':'EUR','net_cents':5000,'paid_count':3,'source_sha256':expected_sha}
except (ValueError,OSError):checks['semantic_rollup']=False
logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks))
