The native Exec compiler supplies this phase's instruction.
