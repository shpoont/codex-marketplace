#!/bin/sh
set -eu
printf '%s\n' '{"batch_id":"PT-1108","currency":"EUR","paid_count":3,"net_cents":5000,"pending_count":1}' > /app/project/analysis.json
