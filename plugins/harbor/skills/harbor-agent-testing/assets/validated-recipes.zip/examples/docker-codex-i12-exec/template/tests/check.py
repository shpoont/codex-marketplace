"""Grade data only, using a trusted original input rather than submitted claims."""
import json
from pathlib import Path
p=Path('/app/project')
checks={'original_input_preserved':(p/'orders.csv').is_file() and (p/'orders.csv').read_bytes()==Path('/tests/orders.csv').read_bytes(),
        'no_agent_credentials_in_verifier':not any(x.exists() for x in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])}
try:checks['semantic_summary']=json.loads((p/'analysis.json').read_text())=={'batch_id':'PT-1108','currency':'EUR','paid_count':3,'net_cents':5000,'pending_count':1}
except (ValueError,OSError):checks['semantic_summary']=False
logs=Path('/logs/verifier');logs.mkdir(parents=True,exist_ok=True)
(logs/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(logs/'reward.json').write_text(json.dumps({'reward':float(all(checks.values()))})+'\n')
print(json.dumps(checks))
