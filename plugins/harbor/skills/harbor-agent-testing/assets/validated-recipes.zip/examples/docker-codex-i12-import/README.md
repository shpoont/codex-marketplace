# I12: imported Terminal-Bench task and original reference

This recipe imports the real
[log-summary-date-ranges task](https://github.com/harbor-framework/terminal-bench/tree/cfc7b6c66f2c731e4b70d92ee71ee5d6d3b55b64/legacy/log-summary-date-ranges)
at the pinned commit in `upstream.json`. The agent summarizes deterministic log
files into a 15-row CSV. The task's reference date is **2025-08-12**, regardless
of the actual run date. Original instructions, generator, reference solution,
pytest assertions and test driver are preserved. No adapter or registry upload
is needed.

Use installed Harbor **0.25.0**, guest Codex **0.167.0**, **GPT-6.1 Sol / High**
and the existing ChatGPT sign-in. Set `HARBOR_PYTHON` to that Harbor environment's
Python and `TEST_EVIDENCE` to a new evidence root outside Git. Keep asdf/CLI
directories on PATH. Each output directory must be new.

```sh
"$HARBOR_PYTHON" examples/docker-codex-i12-import/fetch.py \
  --output "$TEST_EVIDENCE/original"
"$HARBOR_PYTHON" examples/docker-codex-i12-import/prepare.py \
  --original "$TEST_EVIDENCE/original" \
  --output "$TEST_EVIDENCE/import-profile"
```

The fetch verifies nine SHA-256 digests and Git blobs, including the upstream
Apache 2.0 license. Original material stays outside source Git. Preparation
pins images, adds guest Codex and an unprivileged node user, declares `/app`
export excluding input logs, and selects a separate verifier. The unchanged
upstream test driver is retained as `upstream-test.sh`; a wrapper runs it and
adds credential-boundary metadata without changing the earned reward.

## Original reference, then real Codex

The inspected reference uses `apt-get`. Its trusted calibration therefore runs
as root **inside disposable Docker**, with no model call or model credentials:

```sh
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/import-profile/oracle-task" \
  --output "$TEST_EVIDENCE/import-oracle" --name i12-import-oracle \
  --agent oracle --trusted-root-oracle
```

Review the native result, both original pytest tests, full CSV, transfer receipt,
observed root role and cleanup. After calibration, run the nonroot agent task:

```sh
"$HARBOR_PYTHON" tooling/run_docker_case.py \
  --task "$TEST_EVIDENCE/import-profile/log-summary-date-ranges" \
  --output "$TEST_EVIDENCE/import-native" --name i12-import-native
```

The root exception is accepted only for `oracle`; selecting Codex with it is
rejected before Docker or inference. The real agent is configured and observed
as node/UID 1000. Separate trusted grading needs root for its original package
setup but only reads CSV; it never executes submitted code. No Worker is needed
for this task. A different imported grader that executes submissions requires
the qualified protected-code route and its own review.

The original grader catches a well-formed CSV with one incorrect count. It also
distinguishes actual bracketed ERROR/WARNING/INFO severities from DEBUG and the
word ERROR inside a WARNING message. The live result matched all 15 reference
rows semantically; line-ending equality is not required.

The imported task retains upstream timeouts and public dependency downloads.
Images are frozen by local immutable IDs; the original verifier's external
package setup is not a fully locked dependency build. No host mounts/socket,
added capabilities, privileged container, key/provider fallback or host package
change is introduced. This qualifies one legacy task and one reference, not
all benchmark tasks or multiple-reference selection. See the
[reviewed results](../../docs/i12-exec-and-imported-task.md).
