"""Fetch one pinned public benchmark task outside Git; retain all original bytes."""
import argparse,hashlib,json,urllib.request
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;root=a.output.resolve()
if root.is_relative_to(source):raise ValueError('Imported benchmark material belongs outside source Git')
root.mkdir(parents=True,exist_ok=False);pin=json.loads((source/'upstream.json').read_text())
for name,expected in pin['files_sha256'].items():
    path='LICENSE' if name=='LICENSE' else pin['subdir']+'/'+name
    data=urllib.request.urlopen('https://raw.githubusercontent.com/'+pin['repository']+'/'+pin['commit']+'/'+path,timeout=30).read()
    if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Upstream byte mismatch: '+name)
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if blob!=pin['git_blobs'][name]:raise ValueError('Upstream Git blob mismatch: '+name)
    f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
(root/'provenance.json').write_text(json.dumps(pin,indent=2)+'\n')
print(json.dumps({'commit':pin['commit'],'verified_files':len(pin['files_sha256']),'output':str(root)}))
