"""Adapt only execution/transfer for the pinned upstream log-summary task."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
from harbor.models.task.config import TaskConfig
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--original',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=Path(__file__).resolve().parent;root=a.output.resolve()
if root.is_relative_to(source) or root.is_relative_to(a.original.resolve()):raise ValueError('Preparation must preserve source/originals')
root.mkdir(parents=True,exist_ok=False);pin=json.loads((source/'upstream.json').read_text())
for name,digest in pin['files_sha256'].items():
    if hashlib.sha256((a.original/name).read_bytes()).hexdigest()!=digest:raise ValueError('Original changed: '+name)
task=root/'log-summary-date-ranges';shutil.copytree(a.original,task)
base='python:3.13-slim-bookworm@'+pin['python_image']['digest']
original=(a.original/'environment/Dockerfile').read_text().replace('FROM python:3.13-slim-bookworm','FROM '+base)
prefix='FROM node:22-bookworm-slim@sha256:5ec23b7c622b00547753bc6ffd78085dd868a68aeb41c8e0a1418f033e13d96d AS codex\nRUN npm install --global @openai/codex@0.167.0\n'
suffix='''
RUN apt-get update && apt-get install -y --no-install-recommends git ripgrep ca-certificates && rm -rf /var/lib/apt/lists/*
COPY --from=codex /usr/local/bin/node /usr/local/bin/node
COPY --from=codex /usr/local/lib/node_modules/@openai/codex /usr/local/lib/node_modules/@openai/codex
RUN ln -s /usr/local/lib/node_modules/@openai/codex/bin/codex.js /usr/local/bin/codex \\
    && useradd -m -u 1000 node && chown node:node /app
USER node
'''
(task/'environment/Dockerfile').write_text(prefix+original+'\n'+suffix)
# Original grader, reference, instruction and generator are not rewritten.
shutil.copyfile(a.original/'tests/test.sh',task/'tests/upstream-test.sh')
shutil.copyfile(source/'test-wrapper.sh',task/'tests/test.sh')
(task/'tests/Dockerfile').write_text('FROM '+base+'\nWORKDIR /app\nCOPY upstream-test.sh test_outputs.py test.sh /tests/\n')
images={}
for role,context in [('agent','environment'),('verifier','tests')]:
    with (root/(role+'-build.log')).open('w') as log:
        result=subprocess.run(['docker','build','--quiet','--tag','harbor-i12-import-'+role+':0.1.0',str(task/context)],stdout=subprocess.PIPE,stderr=log,text=True,check=True,timeout=600)
    image=result.stdout.strip().splitlines()[-1]
    if not re.fullmatch('sha256:[0-9a-f]{64}',image):raise ValueError('Immutable image ID required')
    images[role]=image
config=TaskConfig.model_validate_toml((a.original/'task.toml').read_text())
config.environment.docker_image=images['agent'];config.agent.user='node'
from harbor.models.task.config import ArtifactConfig,EnvironmentConfig,VerifierEnvironmentMode
config.artifacts=[ArtifactConfig(source='/app',destination='app',exclude=['logs'])]
config.verifier.environment_mode=VerifierEnvironmentMode.SEPARATE
config.verifier.environment=EnvironmentConfig(docker_image=images['verifier'],cpus=1,memory_mb=1024,network_mode='public')
(task/'task.toml').write_text(config.model_dump_toml())
reference=root/'oracle-task';shutil.copytree(task,reference)
config.agent.user='root';(reference/'task.toml').write_text(config.model_dump_toml())
record={'images':images,'upstream_commit':pin['commit'],'instruction_unchanged':(task/'instruction.md').read_bytes()==(a.original/'instruction.md').read_bytes(),
        'reference_unchanged':(task/'solution/solve.sh').read_bytes()==(a.original/'solution/solve.sh').read_bytes(),
        'pytest_unchanged':(task/'tests/test_outputs.py').read_bytes()==(a.original/'tests/test_outputs.py').read_bytes(),
        'test_entrypoint_preserved_as_upstream_test':(task/'tests/upstream-test.sh').read_bytes()==(a.original/'tests/test.sh').read_bytes(),
        'generator_unchanged':(task/'environment/log_generator_deterministic.py').read_bytes()==(a.original/'environment/log_generator_deterministic.py').read_bytes()}
assert all(v for k,v in record.items() if k.endswith('unchanged') or k=='test_entrypoint_preserved_as_upstream_test')
(root/'images.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
