#!/bin/bash
set -eu
bash /tests/upstream-test.sh
python3 - <<'PY'
import json
from pathlib import Path
checks={'upstream_verifier_ran':True,'no_agent_credentials_in_verifier':not any(p.exists() for p in [Path('/tmp/codex-secrets'),Path('/installed-agent/codex-home/auth.json')])}
Path('/logs/verifier/checks.json').write_text(json.dumps(checks,indent=2)+'\n')
PY
