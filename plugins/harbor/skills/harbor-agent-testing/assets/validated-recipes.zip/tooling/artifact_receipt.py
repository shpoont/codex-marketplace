"""Compare declared export bytes/types with native collection; never follow links.

The guest enumerates GNU tar's actual exclusion selection, matching Harbor's
installed exclusion path. Only hashes and entry metadata leave the container.
This intentionally costs one extra read of explicitly declared artifact data.
"""
import hashlib
import os
import posixpath
from pathlib import Path
import stat

GUEST_RECEIPT = r'''
import hashlib,json,posixpath,subprocess,sys,tarfile
from pathlib import PurePosixPath
source,exclude=json.loads(sys.argv[1])
p=PurePosixPath(source)
is_dir=subprocess.run(['test','-d',source]).returncode==0
base=source if is_dir else str(p.parent)
name='.' if is_dir else p.name
cmd=['tar','czf','-']+['--exclude='+x for x in exclude]+['-C',base,name]
proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
entries={}
with tarfile.open(fileobj=proc.stdout,mode='r|gz') as archive:
    for member in archive:
        key=posixpath.normpath(member.name)
        if is_dir:key='' if key=='.' else key.removeprefix('./')
        else:key='' if key==name else key
        if member.isdir():value={'kind':'directory'}
        elif member.isreg() or member.islnk():
            # Hardlinks need full filesystem semantics, not a streaming guess.
            if member.islnk():value={'kind':'unsupported-hardlink'}
            else:
                h=hashlib.sha256()
                with archive.extractfile(member) as f:
                    for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
                value={'kind':'file','sha256':h.hexdigest()}
        elif member.issym():value={'kind':'symlink','target':member.linkname}
        else:value={'kind':'special'}
        if key in entries:raise RuntimeError('Duplicate archive path')
        entries[key]=value
if proc.wait()!=0:raise RuntimeError('Artifact receipt packing failed')
print(json.dumps(entries,sort_keys=True))
'''


def local_receipt(root):
    """lstat every entry and hash regular files only."""
    root=Path(root)
    entries={}
    def visit(path,key):
        mode=path.lstat().st_mode
        if stat.S_ISDIR(mode):
            entries[key]={'kind':'directory'}
            for child in sorted(path.iterdir()):visit(child,(key+'/' if key else '')+child.name)
        elif stat.S_ISREG(mode):
            h=hashlib.sha256()
            with path.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
            entries[key]={'kind':'file','sha256':h.hexdigest()}
        elif stat.S_ISLNK(mode):entries[key]={'kind':'symlink','target':os.readlink(path)}
        else:entries[key]={'kind':'special'}
    if root.exists() or root.is_symlink():visit(root,'')
    return entries


def compare_receipts(artifacts_dir,manifest,receipts):
    for receipt in receipts:
        rows=[x for x in manifest if x['source']==receipt['source'] and (x.get('service') or 'main')==receipt['service']]
        if len(rows)!=1 or rows[0]['status']!='ok':return False
        destination=Path(rows[0]['destination'])
        if destination.is_absolute() or '..' in destination.parts:return False
        target=(artifacts_dir.parent/destination).absolute()
        if not target.is_relative_to(artifacts_dir.absolute()):return False
        expected=receipt['entries']
        if any(x['kind'] in ('special','unsupported-hardlink') for x in expected.values()):return False
        for key,entry in expected.items():
            if entry['kind']=='symlink':
                link_target=entry['target']
                resolved=posixpath.normpath(posixpath.join(posixpath.dirname(key),link_target))
                if not key or link_target.startswith('/') or resolved=='..' or resolved.startswith('../'):
                    return False
        if local_receipt(target)!=expected:return False
    return True
