#!/usr/bin/env python3
"""Probe installed unsupported-mode boundaries without credentials or execution."""

import argparse
import asyncio
import builtins
from contextlib import ExitStack, redirect_stdout
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import inspect
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import traceback
from types import SimpleNamespace
from unittest.mock import patch

from harbor.agents.installed.codex import Codex, CodexOptions
from harbor.models.bridge import BridgeKind
from harbor.models.trial.config import TrialConfig


AUTH_ERROR = "Codex auth.json authentication is not supported in ACP mode"


def rejects(call, message, error=ValueError):
    try:
        call()
    except error as exc:
        if message not in str(exc):
            raise AssertionError("Unexpected rejection: " + str(exc)) from exc
        return message
    raise AssertionError("Expected installed-runtime rejection: " + message)


def adaptive():
    checks = []
    for settings in (
        {"CODEX_AUTH_JSON_PATH": "/synthetic/not-opened/auth.json"},
        {"CODEX_FORCE_AUTH_JSON": "1"},
    ):
        def resolve(name):
            return ("synthetic", settings[name]) if name in settings else None

        rejects(lambda: Codex.resolve_model_connection_config_for_bridge(
            BridgeKind.ACP, "openai/gpt-6.1-sol", resolve
        ), AUTH_ERROR)
        checks.append("ACP rejects " + next(iter(settings)))

    class NoEnvironment:
        def __getattr__(self, name):
            raise AssertionError("Guard reached an environment operation: " + name)

    target = SimpleNamespace(
        model_name="openai/gpt-6.1-sol",
        _resolve_auth_json_path=lambda: Path("/synthetic/not-opened/auth.json"),
    )
    rejects(lambda: asyncio.run(Codex.acp_install(target, NoEnvironment())), AUTH_ERROR)
    checks.append("ACP install rejects subscription before any environment operation")
    assert list(BridgeKind) == [BridgeKind.ACP]
    checks.append("ACP is the only installed bridge kind")

    # Inspect actual command construction without instantiating/authenticating a role.
    target.options = CodexOptions(reasoning_effort="high", web_search="disabled")
    target._resolved_model_name = lambda: "gpt-6.1-sol"
    target._REMOTE_ACP_CODEX_HOME = Codex._REMOTE_ACP_CODEX_HOME
    target._acp_codex_executable = None
    command = Codex.acp_command(target)
    assert 'DEFAULT_AUTH_REQUEST={"methodId":"api-key"}' in command
    config = json.loads(next(s.removeprefix("CODEX_CONFIG=") for s in command if s.startswith("CODEX_CONFIG=")))
    assert config["model"] == "gpt-6.1-sol" and config["model_reasoning_effort"] == "high"
    checks.append("ACP command requests api-key auth; selected model/effort are expressible")
    config = TrialConfig(
        task={"path": "/synthetic/task"},
        agent={"name": "codex", "model_name": "openai/gpt-6.1-sol", "kwargs": {"reasoning_effort": "high"}},
        user_agent={"name": "codex", "model_name": "openai/gpt-6.1-sol", "kwargs": {"reasoning_effort": "high"}, "bridge": {"kind": "acp"}},
    )
    assert config.agent.model_name == config.user_agent.model_name == "openai/gpt-6.1-sol"
    checks.append("Both role configurations parse; this does not qualify runtime authentication")
    return checks


def load_simulator():
    checks = []
    user = {"name": "codex", "bridge": {"kind": "acp"}}
    for source in ("/synthetic/history.json", "/synthetic/rollout-history.jsonl"):
        rejects(lambda: TrialConfig(
            task={"path": "/synthetic/task"},
            agent={"name": "codex", "load_trajectory": source},
            user_agent=user,
        ), "agent.load_trajectory cannot be combined with user_agent.")
        checks.append("Run-level " + Path(source).suffix + " loading with simulator rejected")
    assert TrialConfig(task={"path": "/synthetic/task"},
                       agent={"name": "codex", "load_trajectory": "/synthetic/history.json"}).user_agent is None
    checks.append("History configuration without simulator parses")
    assert TrialConfig(task={"path": "/synthetic/task"},
                       agent={"name": "codex"}, user_agent=user).agent.load_trajectory is None
    checks.append("Simulator configuration without history parses")
    return checks


def multistep_simulator():
    from harbor.models.task.config import TaskConfig
    from harbor.trial.multi_step import MultiStepTrial
    from harbor.trial.trial import Trial

    config = TrialConfig(task={"path": "/synthetic/task"}, agent={"name": "codex"},
                         user_agent={"name": "codex", "bridge": {"kind": "acp"}})
    with patch.object(Trial, "__init__", side_effect=AssertionError("Parent startup reached")) as parent:
        rejects(lambda: MultiStepTrial(config, _task=SimpleNamespace(has_steps=True),
                                      _task_download_result=None),
                "User-agent bridge trials are not supported for multi-step tasks.")
        parent.assert_not_called()
    assert len(TaskConfig(steps=[{"name": "first"}, {"name": "second"}]).steps) == 2
    return ["Actual multistep constructor rejects simulator",
            "Rejection precedes parent trial initialization",
            "Ordinary ordered-step configuration parses"]


def windows():
    from harbor.models.task.config import TaskOS
    from harbor.trial.trial import Trial

    assert Codex.capabilities.windows is False
    trial = SimpleNamespace(
        agent=SimpleNamespace(capabilities=Codex.capabilities, name=Codex.name, mcp_servers=[]),
        agent_environment=SimpleNamespace(os=TaskOS.WINDOWS),
        config=TrialConfig(task={"path": "/synthetic/task"}, agent={"name": "codex"}),
        user_agent=None, _effective_skills_dir=None,
    )
    rejects(lambda: Trial._validate_agent_capabilities(trial),
            "Agent 'codex' does not support Windows containers.", RuntimeError)
    trial.agent_environment.os = TaskOS.LINUX
    Trial._validate_agent_capabilities(trial)
    return ["Codex declares windows=false", "Actual trial capability guard rejects Windows",
            "Same capability check accepts Linux configuration"]


def handoff():
    from harbor.cli.trials import handoff as native_handoff

    assert Codex.capabilities.handoff is False
    rejects(lambda: Codex.handoff(Path("/synthetic/trial"), Path("/synthetic/work")),
            "Agent 'codex' does not support handoff", NotImplementedError)
    with tempfile.TemporaryDirectory(prefix="i13-handoff-") as temporary:
        trial = Path(temporary)
        config = TrialConfig(task={"path": "/synthetic/task"}, agent={"name": "codex"})
        (trial / "config.json").write_text(config.model_dump_json())
        output = io.StringIO()
        with patch.object(Codex, "handoff", side_effect=AssertionError("Handoff mutation reached")) as mutate:
            with redirect_stdout(output):
                try:
                    native_handoff(str(trial))
                except SystemExit as exc:
                    assert exc.code == 1
                else:
                    raise AssertionError("Expected native CLI rejection")
            mutate.assert_not_called()
        assert "agent 'codex' does not support handoff" in output.getvalue()
    return ["Codex declares handoff=false", "Inherited handoff method rejects Codex",
            "Actual CLI rejects synthetic Codex trial before agent handoff or exec"]


def start_step():
    from harbor.cli.main import app
    from harbor.models.job.config import JobConfig
    from harbor.models.task.config import TaskConfig
    from harbor.telemetry import TELEMETRY_ENV
    from typer.testing import CliRunner

    for model in (TaskConfig, TrialConfig, JobConfig):
        assert "start_step" not in model.model_fields
    with patch.dict(os.environ, {TELEMETRY_ENV: "0"}):
        result = CliRunner().invoke(app, ["run", "--start-step", "second"])
    assert result.exit_code == 2 and "No such option" in result.output and "start-step" in result.output
    return ["Task, trial and job schemas have no start_step field",
            "Actual CLI rejects --start-step during argument parsing"]


def direct_provider():
    from dataclasses import replace
    from harbor.agents.agent_auth_resolution import ModelConnectionSpec, resolve_model_connection
    from harbor.llms.litellm_config import require_litellm_credentials

    settings = {"CODEX_AUTH_JSON_PATH": "/synthetic/not-opened/auth.json",
                "CODEX_FORCE_AUTH_JSON": "1"}

    def resolve(*names):
        return next((("synthetic", settings[name]) for name in names if name in settings), None)

    connection = resolve_model_connection(
        "openai/gpt-6.1-sol", ModelConnectionSpec(default_provider="openai"), resolve,
        agent_name="synthetic-direct-provider",
    )
    assert connection.api_key is None
    rejects(lambda: require_litellm_credentials(connection, "synthetic-direct-provider"),
            "no model API key selected")
    # Presence-only control: never sent to a client and never an authentication test.
    require_litellm_credentials(replace(connection, api_key="public-synthetic-presence-control"),
                               "synthetic-direct-provider")
    assert connection.api_key is None
    return ["Generic resolver does not turn native auth-file settings into an API key",
            "Actual LiteLLM credential preflight rejects the keyless public-provider route",
            "Synthetic API-key presence control parses without authentication or network"]


CASES = {"adaptive": adaptive, "load-simulator": load_simulator,
         "multistep-simulator": multistep_simulator, "windows": windows,
         "handoff": handoff, "start-step": start_step, "direct-provider": direct_provider}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=CASES, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if metadata.version("harbor") != "0.25.0":
        raise RuntimeError("Requalify these probes for the installed Harbor version")
    output = args.output.resolve()
    if output.is_relative_to(Path(__file__).resolve().parents[1]):
        raise ValueError("Probe evidence must stay outside source Git")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError(output)
    touched = {"network": 0, "subprocess": 0, "credential_read": 0}
    attempts = []

    def forbidden(kind):
        def stop(*args, **kwargs):
            touched[kind] += 1
            attempts.append({"kind": kind, "stack": [
                {"file": Path(frame.filename).name, "function": frame.name, "line": frame.lineno}
                for frame in traceback.extract_stack(limit=9)[:-1]
            ]})
            raise AssertionError(kind + " is forbidden in compatibility probes")
        return stop

    original_open = builtins.open
    original_io_open = __import__("io").open

    def guarded_open(original):
        def open_file(file, *args, **kwargs):
            if isinstance(file, (str, bytes, os.PathLike)) and Path(os.fsdecode(file)).name == "auth.json":
                return forbidden("credential_read")()
            return original(file, *args, **kwargs)
        return open_file

    with ExitStack() as stack:
        for target in ("socket.socket.connect", "socket.socket.connect_ex", "socket.socket.sendto"):
            stack.enter_context(patch(target, side_effect=forbidden("network")))
        for target in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp", "os.execvp"):
            if target.startswith("os.") and not hasattr(os, target.split(".")[1]):
                continue
            stack.enter_context(patch(target, side_effect=forbidden("subprocess")))
        stack.enter_context(patch("builtins.open", guarded_open(original_open)))
        stack.enter_context(patch("io.open", guarded_open(original_io_open)))
        # Supported offline settings affect probe metadata/telemetry only.
        stack.enter_context(patch.dict(os.environ, {
            "HARBOR_TELEMETRY": "0", "LITELLM_LOCAL_MODEL_COST_MAP": "True",
        }))
        try:
            checks = CASES[args.case]()
        except Exception as exc:
            with output.open("x") as handle:
                json.dump({"case": args.case, "probe_failed": True,
                           "exception_type": type(exc).__name__,
                           "forbidden_operations_attempted": touched, "attempts": attempts,
                           "model_calls": 0, "containers_started": 0}, handle, indent=2)
                handle.write("\n")
            raise
    if any(touched.values()):
        failure = {"case": args.case, "probe_failed": True,
                   "forbidden_operations_attempted": touched, "attempts": attempts,
                   "model_calls": 0, "containers_started": 0}
        with output.open("x") as handle:
            json.dump(failure, handle, indent=2)
            handle.write("\n")
        raise AssertionError("A forbidden operation was attempted; see retained probe output")
    source = Path(inspect.getfile(Codex))
    record = {
        "case": args.case, "checked_at": datetime.now(timezone.utc).isoformat(),
        "harbor": metadata.version("harbor"), "checks": checks,
        "model_calls": 0, "containers_started": 0, "forbidden_operations_attempted": touched,
        "codex_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "limit": "Installed source/configuration rejection only; no successful live-mode qualification",
    }
    with output.open("x") as handle:
        json.dump(record, handle, indent=2)
        handle.write("\n")
    print(json.dumps({"case": args.case, "checks_passed": len(checks), "model_calls": 0, "containers_started": 0}))


if __name__ == "__main__":
    main()
