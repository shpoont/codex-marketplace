"""Native Exec JobPlugin for the qualified small-snapshot Docker profile."""
import hashlib,json
from pathlib import Path
from harbor.models.task.task import Task
from harbor.trial.hooks import TrialEvent
from artifact_receipt import GUEST_RECEIPT
from run_docker_case import command,project_name

class ExecEvidence:
    def __init__(self,output):self.root=Path(output);self.observations=[]
    async def on_job_start(self,job):
        self.job=job
        self.canary=self.root/'host-only-canary.txt';self.canary.write_text('host-only Exec canary\n')
        self.before=hashlib.sha256(self.canary.read_bytes()).hexdigest()
        job.add_hook(TrialEvent.AGENT_START,self.observe);job.add_hook(TrialEvent.AGENT_END,self.observe)
    async def observe(self,event):
        task=Task(task_dir=event.config.task.path)
        ids=(await command('docker','ps','-q','--filter',f'label=com.docker.compose.project={project_name(event.trial_name)}','--filter','label=com.docker.compose.service=main')).split()
        if len(ids)!=1:raise RuntimeError('Expected one owned Exec agent container')
        identity=ids[0]
        spec=json.loads(await command('docker','inspect','--format','{"image":{{json .Image}},"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},"mounts":{{json .Mounts}},"ports":{{json .HostConfig.PortBindings}}}',identity))
        if spec['image']!=task.config.environment.docker_image or spec['privileged'] or spec['cap_add'] or spec['mounts'] or spec['ports']:raise RuntimeError('Exec target isolation/image mismatch')
        ownership=None
        if event.event==TrialEvent.AGENT_START:
            # Native environment upload retains host ownership. This owned,
            # unmounted synthetic workspace must remain writable as node.
            repair="""
import hashlib,json,os,pwd,stat
from pathlib import Path
root=Path('/app/project')
if root.is_symlink() or not root.is_dir():raise RuntimeError('Unsafe Exec workspace')
records=[]
for p in [root,*sorted(root.rglob('*'))]:
    s=p.lstat()
    if not (stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode)):raise RuntimeError('Unsupported Exec input entry')
    records.append((p,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode),hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None))
user=pwd.getpwnam('node')
for p,*_ in records:os.chown(p,user.pw_uid,user.pw_gid,follow_symlinks=False)
for p,uid,gid,mode,digest in records:
    s=p.lstat()
    if (s.st_uid,s.st_gid)!=(user.pw_uid,user.pw_gid) or stat.S_IMODE(s.st_mode)!=mode:raise RuntimeError('Exec ownership repair changed modes')
    if digest is not None and hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise RuntimeError('Exec ownership repair changed bytes')
print(json.dumps({'entries':len(records),'prior_owners':sorted({(uid,gid) for _,uid,gid,_,_ in records}),'uid':user.pw_uid,'bytes_and_modes_preserved':True}))
"""
            ownership=json.loads(await command('docker','exec','--user','root',identity,'python3','-c',repair))
        probe="import json,os,sys;from pathlib import Path;print(json.dumps({'uid':os.getuid(),'host_canary_absent':not Path(sys.argv[1]).exists(),'grader_absent':not Path('/tests/check.py').exists(),'socket_absent':not Path('/var/run/docker.sock').exists(),'credentials_cleaned':not Path('/tmp/codex-secrets').exists() and not Path('/installed-agent/codex-home/auth.json').exists()}))"
        checks=json.loads(await command('docker','exec','--user','node',identity,'python3','-c',probe,str(self.canary)))
        if checks['uid']!=1000 or not all(v for k,v in checks.items() if k!='uid'):raise RuntimeError('Exec isolation canary failed')
        cli=await command('docker','exec','--user','node',identity,'codex','--version')
        if cli!='codex-cli 0.167.0':raise RuntimeError('Unexpected guest Codex version')
        receipts=[]
        for artifact in task.config.artifacts:
            source=artifact if isinstance(artifact,str) else artifact.source
            exclude=[] if isinstance(artifact,str) else list(artifact.exclude)
            entries=json.loads(await command('docker','exec','--user','root',identity,'python3','-c',GUEST_RECEIPT,json.dumps([source,exclude])))
            receipts.append({'source':source,'service':'main','entries':entries})
        self.observations.append({'event':event.event.value,'trial_name':event.trial_name,'spec':spec,'checks':checks,'artifact_receipts':receipts,'workspace_ownership':ownership})
        (self.root/'isolation.json').write_text(json.dumps(self.observations,indent=2)+'\n')
    async def on_job_end(self,result):
        (self.root/'host-canary.json').write_text(json.dumps({'unchanged':hashlib.sha256(self.canary.read_bytes()).hexdigest()==self.before})+'\n')
