#!/usr/bin/env python3
"""Regrade one local Harbor job through the qualified subscription judge."""
import argparse,asyncio,hashlib,json,re
from importlib.metadata import version
from pathlib import Path
from harbor.job import Job
from harbor.models.job.config import JobConfig
from harbor.trial.hooks import TrialEvent


def snapshot(root):
    paths=sorted(root.rglob('*'))
    if any(p.is_symlink() for p in paths):raise ValueError('Source snapshot must not contain symlinks')
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}


def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')


def validate_destination(root,source,task):
    if root.resolve().is_relative_to(source.resolve()) or root.resolve().is_relative_to(task.resolve()):
        raise ValueError('Derived output must be outside source-job and task directories')


async def main(a):
    if version('harbor')!='0.25.0':raise RuntimeError('Requalify the installed Harbor release first')
    root=a.output.resolve();source=a.source_job.resolve()
    validate_destination(root,source,a.task)
    root.mkdir(parents=True,exist_ok=False);before=snapshot(source)
    events=[]
    config=JobConfig.model_validate({'job_name':a.name,'jobs_dir':str(root/'jobs'),
        'source_jobs':[{'action':'regrade','type':'local','path':str(source)}],
        'tasks':[{'path':str(a.task.resolve())}],'agents':[{'name':'nop'}],
        'environment':{'type':'docker','delete':True},
        'verifier':{'import_path':'subscription_judge_verifier:SubscriptionJudgeVerifier'},
        'n_concurrent_trials':1,'retry':{'max_retries':0},'quiet':True})
    write(root/'inputs.json',{'source_job_files':before,'task_files':snapshot(a.task.resolve()),
        'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'bridge_sha256':hashlib.sha256(Path(__file__).with_name('subscription_judge_verifier.py').read_bytes()).hexdigest(),
        'judged_outputs':'recorded; no new evaluated-agent attempt','judge_model':'openai/gpt-6.1-sol','judge_effort':'high',
        'judge_authentication':'existing ChatGPT sign-in via stdin'})
    async def observe(event):events.append(event.event.value)
    try:
        job=await Job.create(config)
        job.add_hook(TrialEvent.AGENT_START,observe);job.add_hook(TrialEvent.AGENT_END,observe)
        await job.run()
    except Exception as exc:
        # Derivation incompatibility is an input error, not a quality zero.
        from harbor.trial.regrade import RegradeError
        if not isinstance(exc,(RegradeError,ValueError)):raise
        unchanged=snapshot(source)==before
        write(root/'summary.json',{'disposition':'input_error','error_type':type(exc).__name__,'reason':str(exc),
             'source_unchanged':unchanged,'new_agent_events':events,'new_agent_attempts':0})
        print(json.dumps({'disposition':'input_error','error_type':type(exc).__name__,'source_unchanged':unchanged}))
        return 1
    paths=list((root/'jobs'/a.name).glob('*/result.json'))
    if len(paths)!=1:raise RuntimeError('Expected one derived trial')
    p=paths[0];raw=json.loads(p.read_text());checks_path=p.parent/'verifier/checks.json'
    checks=json.loads(checks_path.read_text()) if checks_path.exists() else {}
    details_path=p.parent/'verifier/reward-details.json';details=json.loads(details_path.read_text()) if details_path.exists() else {}
    native_source=raw.get('config',{}).get('source_trial')
    unchanged=snapshot(source)==before
    source_trials=list(source.glob('*/result.json'))
    if len(source_trials)!=1:raise RuntimeError('Expected one source trial')
    old=json.loads(source_trials[0].read_text())
    old_artifacts=source_trials[0].parent/'artifacts/project';new_artifacts=p.parent/'artifacts/project'
    same_artifacts=old_artifacts.is_dir() and new_artifacts.is_dir() and snapshot(old_artifacts)==snapshot(new_artifacts)
    rewards=(raw.get('verifier_result') or {}).get('rewards')
    agent_not_run=raw.get('agent_execution') is None and not events
    valid=(not raw.get('exception_info') and unchanged and same_artifacts and agent_not_run and native_source
           and checks.get('grading_valid',checks.get('judge_valid')) is True
           and checks.get('judge_credentials_cleaned') is True and rewards is not None)
    input_error=(raw.get('exception_info') or {}).get('exception_type')=='RegradeError'
    summary={'disposition':'input_error' if input_error else 'infrastructure_error' if not valid else 'passed' if rewards['reward']==1 else 'failed',
       'rewards':rewards,'original_rewards':(old.get('verifier_result') or {}).get('rewards'),
       'source_unchanged':unchanged,'artifact_bytes_unchanged':same_artifacts,'native_source_trial':native_source,
       'new_agent_attempts':0 if agent_not_run else None,'new_agent_events':events,'agent_execution':raw.get('agent_execution'),
       'judge_usage':details.get('usage'),'checks':checks,'exception_type':(raw.get('exception_info') or {}).get('exception_type')}
    if input_error:summary['reason']=(raw.get('exception_info') or {}).get('exception_message')
    write(root/'summary.json',summary)
    print(json.dumps({k:summary[k] for k in ['disposition','rewards','original_rewards','source_unchanged','artifact_bytes_unchanged','new_agent_attempts']}))
    return 0 if summary['disposition']=='passed' else 1


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-job',type=Path,required=True);p.add_argument('--task',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--name',required=True)
    raise SystemExit(asyncio.run(main(p.parse_args())))
