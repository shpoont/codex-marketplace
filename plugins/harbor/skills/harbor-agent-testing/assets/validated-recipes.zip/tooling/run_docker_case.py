#!/usr/bin/env python3
"""Run one native Harbor case and retain its validity/isolation evidence.

Use the selected Harbor installation's Python. This is a small Job API adapter,
not a replacement case format. Oracle is for non-model calibration controls.
"""

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tomllib
import yaml
sys.path.insert(0, str(Path(__file__).resolve().parent))
from artifact_receipt import GUEST_RECEIPT, compare_receipts
from importlib.metadata import version
from uuid import UUID

from harbor.agents.installed.codex import Codex
from harbor.environments.docker.docker import DockerEnvironment
from harbor.job import Job
from harbor.models.job.config import JobConfig
from harbor.models.task.config import TaskConfig
from harbor.models.task.verifier_mode import resolve_step_verifier_mode
from harbor.models.trajectories import Trajectory
from harbor.skills import compute_skill_digest, resolve_skills
from harbor.trial.hooks import TrialEvent


def load_developer_instructions(path):
    """Freeze an explicit project instruction, preserving its complete text."""
    if path is None:
        return None
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 131072:
        raise ValueError("Developer instructions require a regular UTF-8 file up to 128 KiB")
    # Decode one frozen byte string; text-mode reads translate CRLF/CR to LF.
    data = path.read_bytes()
    if len(data) > 131072:
        raise ValueError("Developer instructions exceed 128 KiB")
    text = data.decode("utf-8")
    if not text.strip() or "\x00" in text:
        raise ValueError("Developer instructions must contain nonempty text without NUL")
    return text


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


async def command(*args):
    process = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await asyncio.wait_for(process.communicate(), 30)
    if process.returncode:
        raise RuntimeError(f"{args[0]} failed ({process.returncode}): {stderr.decode()[:500]}")
    return stdout.decode().strip()


def project_name(trial_name):
    return re.sub(r"[^a-z0-9_-]", "-", trial_name.lower() + "__env")


def validate_egress_controller(entry, expected_image):
    """The installed trusted controller is the only added-capability exception."""
    if (not expected_image or not expected_image.startswith("sha256:")
            or entry["image"] != expected_image or entry["privileged"]
            or {v.removeprefix("CAP_") for v in entry["cap_add"] or []} != {"NET_ADMIN", "NET_RAW"}
            or entry["mounts"] or entry["ports"]
            or entry["entrypoint"] != ["/opt/egress-sidecar/entrypoint.sh"]):
        raise RuntimeError("Egress controller differs from the pinned installed profile")


def describe_local_skills(paths):
    """Freeze explicit local inputs in order; Harbor still owns resolution/upload."""
    sources = []
    for path in paths:
        if not path.is_dir() or path.is_symlink() or any(p.is_symlink() for p in path.rglob("*")):
            raise ValueError("Skill inputs must be existing local directories without symlinks")
        for skill in resolve_skills([path]):
            sources.append({"name": skill.name, "source": str(skill.source),
                            "digest": compute_skill_digest(skill.source),
                            "files": {str(p.relative_to(skill.source)): hashlib.sha256(p.read_bytes()).hexdigest()
                                      for p in sorted(skill.source.rglob("*")) if p.is_file()}})
    winners = {s["name"]: s for s in sources}
    return {"sources_in_order": sources, "effective": [winners[n] for n in sorted(winners)]}


def skills_delivery_ok(snapshots, supplied):
    if not snapshots:
        return False
    for snapshot in snapshots:
        if (not snapshot or not snapshot["source"]["files"]
                or snapshot["source"]["symlinks"] or snapshot["native"]["symlinks"]
                or snapshot["source"]["files"] != snapshot["native"]["files"]):
            return False
        for skill in supplied:
            prefix = skill["name"] + "/"
            actual = {k.removeprefix(prefix): v for k, v in snapshot["source"]["files"].items() if k.startswith(prefix)}
            if actual != skill["files"]:
                return False
    return True


def load_mcp_config(path, task_config):
    """Allow fixture MCP settings without changing inference/authentication policy."""
    if path is None:
        return {}
    config = tomllib.loads(path.read_text())
    if set(config) != {"mcp_servers"} or not isinstance(config["mcp_servers"], dict):
        raise ValueError("The fixture config must contain only an mcp_servers table")
    declared = {s["name"] for s in task_config.get("environment", {}).get("mcp_servers", [])}
    allowed = {"command", "args", "url", "enabled_tools", "disabled_tools", "required",
               "startup_timeout_sec", "tool_timeout_sec"}
    for name, entry in config["mcp_servers"].items():
        if name in declared:
            raise ValueError("Task MCP declarations replace same-name native entries; declare each server once")
        if not isinstance(entry, dict) or set(entry) - allowed:
            raise ValueError("Unsupported fixture MCP setting")
        if ("command" in entry) == ("url" in entry):
            raise ValueError("Declare exactly one MCP command or URL")
    return config


def validate_native_load(path):
    """Require complete native JSONL; never let damaged input become fresh work."""
    if not Codex._ROLLOUT_FILENAME_RE.match(path.name):
        raise ValueError("Native Codex history must retain its rollout-<timestamp>-<session-id>.jsonl filename")
    if not path.is_file():
        raise ValueError("Native Codex history file does not exist")
    rows = []
    try:
        for number, line in enumerate(path.read_text().splitlines(), 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except ValueError as exc:
                raise ValueError(f"Native Codex history is malformed JSONL at line {number}") from exc
            if not isinstance(row, dict) or not isinstance(row.get("payload"), dict) or not isinstance(row.get("type"), str):
                raise ValueError(f"Native Codex history has an invalid record at line {number}")
            rows.append(row)
    except (OSError, UnicodeError) as exc:
        raise ValueError("Native Codex history is unreadable") from exc
    if not rows or rows[0]["type"] != "session_meta":
        raise ValueError("Native Codex history must begin with session_meta")
    identity = rows[0]["payload"].get("id")
    try:
        UUID(identity)
    except (ValueError, TypeError, AttributeError) as exc:
        raise ValueError("Native Codex history has an invalid session ID") from exc
    if not path.stem.endswith("-" + identity):
        raise ValueError("Native Codex history filename and session ID disagree")
    return {"filename": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "session_id": identity, "records": len(rows)}


def select_load_source(task_dir, task_config, run_source, agent):
    """Match Harbor's precedence; unused task sources must not block overrides."""
    if run_source:
        return run_source, "run"
    if agent != "codex":
        return None, None
    first_step = (task_config.get("steps") or [{}])[0].get("name")
    candidate = task_dir / "steps" / first_step / "trajectory.json" if first_step else task_dir / "trajectory.json"
    return (candidate, "task") if candidate.is_file() else (None, None)


def validate_atif_load(path):
    try:
        trajectory = Trajectory.model_validate_json(path.read_text())
    except (OSError, UnicodeError, ValueError) as exc:
        raise ValueError("ATIF history is not a readable, schema-valid trajectory") from exc
    identity = trajectory.session_id
    try:
        UUID(identity)
    except (ValueError, TypeError, AttributeError):
        identity = None  # The native integration generates an ID in this case.
    return {"filename": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "session_id": identity, "steps": len(trajectory.steps), "format": "atif"}


def render_atif(path, identity, logs_dir, default_timestamp=None):
    trajectory = Trajectory.model_validate_json(path.read_text())
    if default_timestamp and not any(step.timestamp for step in trajectory.steps):
        # Compare the converter's runtime-generated timestamp without rewriting input.
        trajectory.steps[0].timestamp = default_timestamp
    converter = Codex(logs_dir=logs_dir)
    return converter.atif_to_native_trajectory(trajectory, identity)


def check_load_prefix(agent_dir, filename, prefix, identity):
    """A successful command/score is insufficient if the runtime started fresh."""
    candidates = list((agent_dir / "sessions").rglob(filename))
    preserved = False
    if len(candidates) == 1:
        content = candidates[0].read_bytes()
        preserved = content.startswith(prefix) and len(content) > len(prefix)
    identities = []
    stream = agent_dir / "codex.txt"
    if stream.exists():
        for line in stream.read_text().splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("type") == "thread.started":
                identities.append(row.get("thread_id"))
    return {"ok": preserved and identities == [identity],
            "native_prefix_extended": preserved, "expected_session": identity,
            "actual_sessions": identities}


def check_native_load(agent_dir, source, descriptor):
    return check_load_prefix(agent_dir, source.name, source.read_bytes(), descriptor["session_id"])


def check_atif_load(agent_dir, source, descriptor, logs_dir):
    identity = descriptor["session_id"]
    if identity is None:
        streams = []
        stream = agent_dir / "codex.txt"
        for line in stream.read_text().splitlines() if stream.exists() else []:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get("type") == "thread.started":
                streams.append(row.get("thread_id"))
        if len(streams) != 1 or not isinstance(streams[0], str):
            return {"ok": False, "reason": "No unique converted native session was observed"}
        identity = streams[0]
    default_timestamp = None
    if not any(step.timestamp for step in Trajectory.model_validate_json(source.read_text()).steps):
        candidates = list((agent_dir / "sessions").rglob("rollout-*-" + identity + ".jsonl"))
        if len(candidates) != 1:
            return {"ok": False, "reason": "No unique converted native snapshot was observed"}
        try:
            default_timestamp = json.loads(candidates[0].read_text().splitlines()[0])["payload"]["timestamp"]
        except (OSError, ValueError, IndexError, KeyError, TypeError):
            return {"ok": False, "reason": "Converted native timestamp is unavailable"}
    filename, content = render_atif(source, identity, logs_dir, default_timestamp)
    receipt = check_load_prefix(agent_dir, filename, content.encode(), identity)
    receipt["format"] = "atif"
    receipt["converted_prefix_sha256"] = hashlib.sha256(content.encode()).hexdigest()
    return receipt


async def restore_resume_log_owner(container):
    """Log re-upload can retain host ownership; restore only owned guest logs."""
    script = """
import hashlib,json,os,pwd,stat
from pathlib import Path
root=Path('/logs/agent')
if root.is_symlink() or root.parent.is_symlink() or not root.is_dir():
    raise RuntimeError('Unsafe native log directory')
entries=[root,*sorted(root.rglob('*'))]
before=[]
for p in entries:
    s=p.lstat()
    if not (stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode)) or p.name=='auth.json':
        raise RuntimeError('Unexpected entry in native logs')
    before.append((p,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode),
                   hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None))
user=pwd.getpwnam('node')
for p,*_ in before:
    os.chown(p,user.pw_uid,user.pw_gid,follow_symlinks=False)
for p,uid,gid,mode,digest in before:
    s=p.lstat()
    if s.st_uid!=user.pw_uid or s.st_gid!=user.pw_gid or stat.S_IMODE(s.st_mode)!=mode:
        raise RuntimeError('Native log ownership restoration failed')
    if digest is not None and hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        raise RuntimeError('Native log content changed during ownership restoration')
print(json.dumps({'entries':len(before),'changed':sum((uid,gid)!=(user.pw_uid,user.pw_gid) for _,uid,gid,_,_ in before),
                  'prior_owner_pairs':sorted({(uid,gid) for _,uid,gid,_,_ in before}),
                  'uid':user.pw_uid,'gid':user.pw_gid,'contents_and_modes_preserved':True}))
"""
    return json.loads(await command("docker", "exec", "--user", "root", container, "python3", "-c", script))


def summarize(trial, result, task_config, observations, cleanup, *, fault_control=False):
    """Keep native rewards; require complete, valid step evidence for a pass."""
    config = TaskConfig.model_validate(task_config)
    planned = [step.name for step in config.steps or []]
    records = result.get("step_results") if planned else [result]
    records = records or []
    names = [row["step_name"] for row in records] if planned else ["task"]
    order_ok = not planned or names == planned[:len(names)]
    rows = []
    for index, record in enumerate(records):
        name = names[index]
        step = config.steps[index] if planned and index < len(config.steps) else None
        directory = trial / "steps" / name if planned else trial
        manifest_path = directory / "artifacts/manifest.json"
        manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else []
        required = set()
        for artifact in [*config.artifacts, *(step.artifacts if step else [])]:
            required.add((artifact, "main") if isinstance(artifact, str)
                         else (artifact.source, artifact.service or "main"))
        if fault_control:
            required.add(("/app/intentionally-missing-harness-input.txt", "main"))
        collected = bool(manifest) and all(entry["status"] == "ok" for entry in manifest) and all(
            len(entries := [entry for entry in manifest if entry["source"] == source
                            and (entry.get("service") or "main") == service]) == 1
            and entries[0]["status"] == "ok" for source, service in required
        )
        receipts = [r for o in observations if o.get("event") == TrialEvent.AGENT_END.value
                    and o.get("step_name") == (name if planned else None)
                    for r in o.get("artifact_receipts", [])]
        receipt_ok = compare_receipts(directory / "artifacts", manifest, receipts) if receipts else None
        if receipts:
            collected = collected and receipt_ok
        checks_path = directory / "verifier/checks.json"
        checks = json.loads(checks_path.read_text()) if checks_path.exists() else {}
        rewards = (record.get("verifier_result") or {}).get("rewards")
        exception = record.get("exception_info")
        timing = record.get("agent_execution") or {}
        attempted = timing.get("started_at") is not None
        completed = attempted and timing.get("finished_at") is not None and not exception and rewards is not None
        valid = (not exception and collected and checks.get("no_agent_credentials_in_verifier") is True
                 and checks.get("worker_boundary_ok", True) is True
                 and isinstance(rewards, dict) and rewards.get("reward") in (0.0, 1.0))
        rows.append({"step_name": name, "attempted": attempted, "completed": completed,
                     "disposition": "infrastructure_error" if not valid else (
                         "passed" if rewards["reward"] == 1 else "failed"),
                     "rewards": rewards, "exception_type": exception.get("exception_type") if exception else None,
                     "collection_ok": collected, "transfer_receipt_ok": receipt_ok,
                     "artifact_manifest": manifest, "checks": checks,
                     "separate_verifier": (resolve_step_verifier_mode(config, step).value == "separate")
                         if step else result.get("verifier_environment_mode") == "separate"})
    attempted = sum(row["attempted"] for row in rows)
    complete = order_ok and len(rows) == len(planned or ["task"]) and all(row["completed"] for row in rows)
    valid = (order_ok and bool(rows) and not result.get("exception_info")
             and all(row["disposition"] != "infrastructure_error" for row in rows)
             and cleanup["host_canary_unchanged"] and not cleanup["owned_containers_remaining"]
             and not cleanup["owned_networks_remaining"] and len(observations) == 2 * attempted)
    if not valid:
        disposition = "infrastructure_error"
    elif any(row["disposition"] == "failed" for row in rows):
        disposition = "failed"
    elif not complete:
        disposition = "stopped"
    else:
        disposition = "passed"
    for name in planned[len(rows):]:
        rows.append({"step_name": name, "attempted": False, "completed": False, "disposition": "skipped"})
    usage = {}
    resumed_codex = (result.get("agent_info", {}).get("name") == "codex"
                     and result.get("config", {}).get("agent", {}).get("resume_trajectory", False))
    native_step_usage_sum = {}
    for key in ("n_input_tokens", "n_cache_tokens", "n_output_tokens", "cost_usd"):
        values = [(row.get("agent_result") or {}).get(key) for row in records]
        known = [value for value in values if value is not None]
        native_step_usage_sum[key] = sum(known) if known else None
        # This Codex integration converts the full retained native session after
        # every resumed turn. Its latest counters already include prior turns.
        usage[key] = known[-1] if resumed_codex and known else native_step_usage_sum[key]
    usage_complete = (not result.get("exception_info") and bool(records) and all(
        not row.get("exception_info") and (row.get("agent_result") or {}).get("n_input_tokens") is not None
        for row in records)) if result.get("agent_info", {}).get("name") == "codex" else None
    return {"disposition": disposition, "rewards": (result.get("verifier_result") or {}).get("rewards"),
            "exception_type": (result.get("exception_info") or {}).get("exception_type"),
            "collection_ok": bool(attempted) and all(row.get("collection_ok", False) for row in rows if row["attempted"]),
            "artifact_manifest": [entry for row in rows for entry in row.get("artifact_manifest", [])],
            "agent_info": result.get("agent_info"), "agent_result": result.get("agent_result"), "usage": usage,
            "native_step_usage_sum": native_step_usage_sum, "usage_complete": usage_complete,
            "usage_basis": "latest_cumulative_codex_session" if resumed_codex else "sum_of_step_contexts",
            "started_at": result.get("started_at"), "finished_at": result.get("finished_at"),
            "separate_verifier": bool(attempted) and all(row.get("separate_verifier", False) for row in rows if row["attempted"]),
            "checks": rows[0].get("checks", {}) if not planned else {row["step_name"]: row.get("checks", {}) for row in rows},
            "steps": rows, "planned_steps": len(planned or ["task"]), "attempted_steps": attempted,
            "completed_steps": sum(row["completed"] for row in rows),
            "skipped_steps": sum(row["disposition"] == "skipped" for row in rows), "workflow_complete": complete,
            "isolation_checkpoints": len(observations),
            "cleanup_passed": cleanup["host_canary_unchanged"] and not cleanup["owned_containers_remaining"] and not cleanup["owned_networks_remaining"]}


async def main(args):
    if version("harbor") != "0.25.0":
        raise RuntimeError("This recipe is qualified against installed Harbor 0.25.0")
    developer_path = getattr(args, "developer_instructions", None)
    developer_text = load_developer_instructions(developer_path)
    if developer_path and args.agent != "codex":
        raise ValueError("Developer instructions are qualified only for Codex")
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    canary = root / "host-only-canary.txt"
    canary.write_text("host-only isolation control\n")
    before = hashlib.sha256(canary.read_bytes()).hexdigest()
    observations = []
    projects = set()
    prefixes = set()
    task_config = tomllib.loads((args.task / "task.toml").read_text())
    trusted_root_oracle = getattr(args, "trusted_root_oracle", False)
    if trusted_root_oracle and (args.agent != "oracle" or task_config.get("agent", {}).get("user") != "root"):
        raise ValueError("Root reference execution requires Oracle and an explicitly root task user")
    if not trusted_root_oracle and task_config.get("agent", {}).get("user") in ("root", "0", 0):
        raise ValueError("Root task execution is outside the unprivileged profile")
    probe_user = "root" if trusted_root_oracle else "node"
    compose_path = args.task / "environment/docker-compose.yaml"
    compose_services = (yaml.safe_load(compose_path.read_text()).get("services", {}) if compose_path.exists() else {})
    restricted_agent = any(c.get("network_mode", "public") != "public" for c in
                           [task_config.get("environment", {}), task_config.get("agent", {}),
                            *[s.get("agent", {}) for s in task_config.get("steps", [])]])
    if restricted_agent and not args.egress_image:
        raise ValueError("Restricted Docker runs require the prepared official egress-controller image pin")
    native_mcp_config = load_mcp_config(args.mcp_config, task_config)
    pinned_agent_image = task_config.get("environment", {}).get("docker_image")
    supplied_skills = describe_local_skills(args.skill)
    if args.skill and args.agent != "codex":
        raise ValueError("This recipe qualifies skill injection only with Codex; Oracle controls omit --skill")
    effective_skills_dir = task_config.get("environment", {}).get("skills_dir") or ("/runtime/skills" if args.skill else None)
    load_preflight = None
    effective_load, load_level = select_load_source(args.task, task_config, args.load_trajectory, args.agent)
    if effective_load and args.agent == "codex":
        try:
            load_preflight = validate_atif_load(effective_load) if effective_load.suffix == ".json" else validate_native_load(effective_load)
            load_preflight["level"] = load_level
        except ValueError as exc:
            canary_unchanged = hashlib.sha256(canary.read_bytes()).hexdigest() == before
            write_json(root / "input-error.json", {"stage": "history_preflight", "filename": effective_load.name,
                       "reason": str(exc)})
            write_json(root / "cleanup.json", {"host_canary_unchanged": canary_unchanged,
                       "owned_containers_remaining": [], "owned_networks_remaining": []})
            summary = {"disposition": "input_error", "stage": "history_preflight", "reason": str(exc),
                       "rewards": None, "attempted_steps": 0, "completed_steps": 0,
                       "workflow_complete": False, "agent_invocations": 0, "docker_started": False,
                       "cleanup_passed": canary_unchanged}
            write_json(root / "summary.json", summary)
            print(json.dumps(summary))
            return 1

    async def started(event):
        prefixes.add(re.sub(r"[^a-z0-9_-]", "-", event.trial_name.lower()))

    async def observe(event):
        project = project_name(event.trial_name)
        projects.add(project)
        ids = (await command("docker", "ps", "-q", "--filter", f"label=com.docker.compose.project={project}",
                             "--filter", "label=com.docker.compose.service=main")).split()
        if len(ids) != 1:
            raise RuntimeError("Expected exactly one owned agent container")
        container = ids[0]
        services = {}
        compose_networks = {}
        if compose_services:
            controller_name = DockerEnvironment._EGRESS_CONTROL_SERVICE_NAME
            expected_services = {"main", *compose_services} | ({controller_name} if restricted_agent else set())
            all_ids = (await command("docker", "ps", "-q", "--filter", f"label=com.docker.compose.project={project}")).split()
            for identity in all_ids:
                entry = json.loads(await command("docker", "inspect", "--format",
                    '{"service":{{json (index .Config.Labels "com.docker.compose.service")}},"image":{{json .Image}},'
                    '"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},'
                    '"mounts":{{json .Mounts}},"ports":{{json .HostConfig.PortBindings}},'
                    '"entrypoint":{{json .Config.Entrypoint}},"network_mode":{{json .HostConfig.NetworkMode}},'
                    '"networks":{{json .NetworkSettings.Networks}},"state":{{json .State}}}', identity))
                name = entry["service"]
                if name in services or name not in expected_services:
                    raise RuntimeError("Unexpected or duplicate Compose service")
                if name == controller_name:
                    validate_egress_controller(entry, args.egress_image)
                    if entry["state"].get("Health", {}).get("Status") != "healthy":
                        raise RuntimeError("Egress controller is not healthy")
                    services[name] = {"container": identity, "image": entry["image"], "uid": int(await command("docker", "exec", identity, "id", "-u")),
                        "health": "healthy", "trusted_network_controller": True, "cap_add": entry["cap_add"],
                        "mounts": entry["mounts"], "ports": entry["ports"], "networks": sorted(entry["networks"]),
                        "policy": await command("docker", "exec", identity, "network-policy", "show")}
                    continue
                if entry["privileged"] or entry["cap_add"] or entry["mounts"] or entry["ports"]:
                    raise RuntimeError("Compose fixture has unexpected privileges, mounts or published ports")
                expected_image = pinned_agent_image if name == "main" else compose_services[name].get("image")
                if not expected_image or not expected_image.startswith("sha256:") or entry["image"] != expected_image:
                    raise RuntimeError("Compose service differs from its frozen image ID")
                health = entry["state"].get("Health", {}).get("Status")
                if name != "main" and health != "healthy":
                    raise RuntimeError("Compose sidecar is not healthy")
                service_probe = ("import json,os,sys;from pathlib import Path;"
                    "print(json.dumps({'uid':os.getuid(),'host_canary_absent':not Path(sys.argv[1]).exists(),"
                    "'docker_socket_absent':not Path('/var/run/docker.sock').exists(),"
                    "'grader_absent':not Path('/tests/check.py').exists(),"
                    "'credentials_absent':not Path('/tmp/codex-secrets').exists() and not Path('/installed-agent/codex-home/auth.json').exists()}))")
                service_state = json.loads(await command("docker", "exec", identity, "python3", "-c", service_probe, str(canary)))
                uid = service_state["uid"]
                if uid == 0:
                    raise RuntimeError("Compose service unexpectedly runs as root")
                if not all(v for k, v in service_state.items() if k != "uid"):
                    raise RuntimeError("Compose service isolation canary failed")
                services[name] = {"container": identity, "image": entry["image"], "uid": uid, "health": health,
                                  "mounts": entry["mounts"], "ports": entry["ports"],
                                  "networks": sorted(entry["networks"]), "canaries": service_state,
                                  "network_mode": entry["network_mode"]}
                for network in entry["networks"]:
                    compose_networks[network] = json.loads(await command("docker", "network", "inspect", "--format",
                        '{"internal":{{json .Internal}},"driver":{{json .Driver}}}', network))
            if set(services) != expected_services:
                raise RuntimeError("A declared Compose service is missing")
            if restricted_agent:
                controller_id = services[controller_name]["container"]
                if not services["main"]["network_mode"].startswith("container:" + controller_id):
                    raise RuntimeError("Agent does not share the official controller's network namespace")
        spec = json.loads(await command(
            "docker", "inspect", "--format",
            '{"image":{{json .Image}},"user":{{json .Config.User}},"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},"mounts":{{json .Mounts}}}',
            container,
        ))
        if spec["privileged"] or spec["cap_add"]:
            raise RuntimeError("The agent container unexpectedly has extra privileges")
        effective_user = task_config.get("agent", {}).get("user") or spec["user"]
        if not trusted_root_oracle and effective_user not in ("node", "node:node", "1000", "1000:1000", 1000):
            raise RuntimeError("Configured execution user differs from the unprivileged profile")
        if pinned_agent_image and pinned_agent_image.startswith("sha256:") and spec["image"] != pinned_agent_image:
            raise RuntimeError("Agent container differs from the frozen image ID")
        for mount in spec["mounts"]:
            source = mount["Source"].removeprefix("/host_mnt").removeprefix("/run/desktop/mnt/host")
            if not Path(source).is_relative_to(root):
                raise RuntimeError("An agent mount exposes a path outside this run's output")
        log_owner = None
        if (args.resume_trajectory and event.event == TrialEvent.AGENT_START
                and event.result.step_results and len(event.result.step_results) > 1):
            if any(Path("/logs/agent").is_relative_to(m["Destination"])
                   or Path(m["Destination"]).is_relative_to("/logs/agent") for m in spec["mounts"]):
                raise RuntimeError("Cannot restore ownership through mounted native logs")
            log_owner = await restore_resume_log_owner(container)
        probe = (
            "import json,os,sys;from pathlib import Path;"
            "print(json.dumps({'uid':os.getuid(),"
            "'host_canary_absent':not Path(sys.argv[1]).exists(),"
            "'grader_absent':not any(Path(p).exists() for p in ('/tests/check.py','/tests/test_outputs.py')),"
            "'docker_socket_absent':not Path('/var/run/docker.sock').exists(),"
            "'credentials_cleaned':not Path('/tmp/codex-secrets').exists() and not Path('/installed-agent/codex-home/auth.json').exists()}))"
        )
        state = json.loads(await command("docker", "exec", "--user", probe_user, container, "python3", "-c", probe, str(canary)))
        state["execution_role"] = "trusted_root_oracle" if trusted_root_oracle else "unprivileged_agent"
        if task_config.get("environment", {}).get("mcp_servers") or native_mcp_config:
            # Only synthetic, non-secret registration fields; never read auth.
            mcp_probe = """
import json,tomllib
from pathlib import Path
p=Path('/installed-agent/codex-home/config.toml')
config=tomllib.loads(p.read_text()) if p.exists() else {}
keys=('command','args','url','enabled_tools','disabled_tools','required','startup_timeout_sec')
print(json.dumps({'exists':p.exists(),'web_search':config.get('web_search'),
                 'multi_agent':config.get('features',{}).get('multi_agent'),
                 'servers':{name:{k:v for k,v in entry.items() if k in keys}
                            for name,entry in config.get('mcp_servers',{}).items()}}))
"""
            state["native_mcp"] = json.loads(await command(
                "docker", "exec", "--user", "node", container, "python3", "-c", mcp_probe))
        if effective_skills_dir:
            # Snapshot only declared synthetic context, never the surrounding home.
            skills_probe = """
import hashlib,json,sys
from pathlib import Path
def snapshot(root):
    return {'path':str(root),'exists':root.is_dir(),
            'symlinks':[str(p.relative_to(root)) for p in root.rglob('*') if p.is_symlink()],
            'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}}
print(json.dumps({'source':snapshot(Path(sys.argv[1])),
                  'native':snapshot(Path.home()/'.agents/skills')}))
"""
            state["skills"] = json.loads(await command(
                "docker", "exec", "--user", "node", container, "python3", "-c", skills_probe,
                effective_skills_dir))
        if task_config.get("steps") or effective_load:
            # Focused fixture data only: record state before agent work, including
            # step setup, without copying the host checkout or reading credentials.
            digest_probe = (
                "import hashlib,json;from pathlib import Path;"
                "p=Path('/app/project');"
                "print(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() "
                "for f in sorted(p.rglob('*')) if f.is_file() and not f.is_symlink()}))"
            )
            state["project_files"] = json.loads(await command(
                "docker", "exec", "--user", "node", container, "python3", "-c", digest_probe))
        if (state["uid"] != (0 if trusted_root_oracle else 1000)
                or not all(state[k] for k in ("host_canary_absent", "grader_absent", "docker_socket_absent"))):
            raise RuntimeError("An isolation canary failed")
        if not state["credentials_cleaned"]:
            raise RuntimeError("Agent credentials exist outside their intended execution phase")
        codex_version = await command("docker", "exec", "--user", "node", container, "codex", "--version")
        if codex_version != f"codex-cli {args.codex_version}":
            raise RuntimeError("Guest Codex differs from the selected version")
        step_name = event.result.step_results[-1].step_name if event.result.step_results else None
        receipts = []
        if event.event == TrialEvent.AGENT_END:
            native = TaskConfig.model_validate(task_config)
            step = next((s for s in native.steps or [] if s.name == step_name), None)
            declared = [*native.artifacts, *(step.artifacts if step else [])]
            seen = set()
            for artifact in declared:
                source = artifact if isinstance(artifact, str) else artifact.source
                service = "main" if isinstance(artifact, str) else artifact.service or "main"
                exclude = [] if isinstance(artifact, str) else list(artifact.exclude)
                if (source, service) in seen:
                    continue
                seen.add((source, service))
                identity = container if service == "main" else services[service]["container"]
                entries = json.loads(await command("docker", "exec", "--user", "root", identity,
                    "python3", "-c", GUEST_RECEIPT, json.dumps([source, exclude])))
                receipts.append({"source": source, "service": service, "entries": entries})
        observations.append({"event": event.event.value, "step_name": step_name, "container": container, "spec": spec,
                             "codex_version": codex_version, "canaries": state, "resume_log_owner": log_owner,
                             "compose_services": services, "compose_networks": compose_networks,
                             "artifact_receipts": receipts})
        write_json(root / "isolation.json", observations)

    agent = {"name": args.agent, "resume_trajectory": args.resume_trajectory}
    if args.allow_agent_host:
        agent["extra_allowed_hosts"] = args.allow_agent_host
    if args.skill:
        agent["skills"] = [str(p.resolve()) for p in args.skill]
    if args.load_trajectory:
        agent["load_trajectory"] = str(args.load_trajectory.resolve())
    if args.agent == "codex":
        login = await asyncio.create_subprocess_exec(
            "codex", "login", "status", stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(login.communicate(), 30)
        status = (stdout + stderr).decode()
        if login.returncode or "ChatGPT" not in status:
            raise RuntimeError("The configured native Codex session is not a ChatGPT sign-in")
        auth = Path(os.environ.get("CODEX_AUTH_JSON_PATH", str(Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "auth.json")))
        if not auth.is_file():
            raise RuntimeError("The configured native Codex auth file is unavailable")
        # Harbor consumes the existing file internally. Never read its contents here.
        agent.update(
            model_name=args.model,
            env={"CODEX_AUTH_JSON_PATH": str(auth)},
            kwargs={"version": args.codex_version, "reasoning_effort": args.effort, "web_search": args.web_search,
                    "config": {**native_mcp_config,
                               **({"developer_instructions": developer_text} if developer_text is not None else {}),
                               "web_search": args.web_search,
                               "features": {"multi_agent": False, "apps": False}}},
        )
    config = JobConfig.model_validate({
        "job_name": args.name,
        "jobs_dir": str(root / "jobs"),
        "tasks": [{"path": str(args.task.resolve())}],
        "agents": [agent],
        "environment": {"type": "docker", "delete": True},
        "n_concurrent_trials": 1, "n_attempts": 1, "retry": {"max_retries": 0}, "quiet": True,
    })
    if args.subscription_judge:
        config.verifier.import_path = "subscription_judge_verifier:SubscriptionJudgeVerifier"
    if args.missing_artifact_control:
        # Deliberately broken harness declaration, not a participant deliverable.
        from harbor.models.task.config import ArtifactConfig
        config.artifacts.append(ArtifactConfig(source="/app/intentionally-missing-harness-input.txt", destination="missing-harness-input.txt"))
    source = {str(p.relative_to(args.task)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(args.task.rglob("*")) if p.is_file()}
    write_json(root / "inputs.json", {"task_files": source, "harbor": version("harbor"),
               "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "artifact_receipt_sha256": hashlib.sha256(Path(__file__).with_name("artifact_receipt.py").read_bytes()).hexdigest(),
               "subscription_judge_verifier_sha256": hashlib.sha256(Path(__file__).with_name("subscription_judge_verifier.py").read_bytes()).hexdigest() if args.subscription_judge else None,
               "agent": args.agent, "model": args.model if args.agent == "codex" else None,
               "trusted_root_oracle": trusted_root_oracle,
               "effort": args.effort if args.agent == "codex" else None,
               "requested_web_search": args.web_search,
               "explicit_agent_hosts": args.allow_agent_host,
               "egress_controller_image": args.egress_image,
               "auth_route": "existing native Codex ChatGPT file" if args.agent == "codex" else "none",
               "judge_auth_route": "existing ChatGPT sign-in streamed to separate Docker verifier" if args.subscription_judge else None,
               "resume_trajectory": args.resume_trajectory,
               "developer_instructions": {"filename": developer_path.name,
                   "sha256": hashlib.sha256(developer_text.encode()).hexdigest()} if developer_path else None,
               "supplied_skills": supplied_skills,
               "effective_skills_dir": effective_skills_dir,
               "native_mcp_config": {"filename": args.mcp_config.name,
                   "sha256": hashlib.sha256(args.mcp_config.read_bytes()).hexdigest(),
                   "content": native_mcp_config} if args.mcp_config else None,
               "load_source": {"filename": args.load_trajectory.name,
                   "sha256": hashlib.sha256(args.load_trajectory.read_bytes()).hexdigest()
                   if args.load_trajectory.is_file() else None} if args.load_trajectory else None,
               "load_preflight": load_preflight,
               "fault_control": args.missing_artifact_control})
    try:
        job = await Job.create(config)
        job.add_hook(TrialEvent.START, started)
        job.add_hook(TrialEvent.AGENT_START, observe)
        job.add_hook(TrialEvent.AGENT_END, observe)
        await job.run()
    finally:
        unchanged = hashlib.sha256(canary.read_bytes()).hexdigest() == before
        remaining = []
        rows = await command("docker", "ps", "-a", "--filter", "label=com.docker.compose.project",
                             "--format", '{{.ID}} {{.Label "com.docker.compose.project"}}')
        for row in rows.splitlines():
            ident, project = row.split(maxsplit=1)
            if any(project.startswith(prefix + "__") for prefix in prefixes):
                remaining.append(ident)
        networks = []
        for row in (await command("docker", "network", "ls", "--format", "{{.ID}} {{.Name}}")).splitlines():
            ident, name = row.split(maxsplit=1)
            if any(name.startswith(prefix + "__") for prefix in prefixes):
                networks.append(ident)
        write_json(root / "cleanup.json", {"host_canary_unchanged": unchanged,
                   "owned_containers_remaining": remaining, "owned_networks_remaining": networks})
    results = list((root / "jobs" / args.name).glob("*/result.json"))
    if len(results) != 1:
        raise RuntimeError("Expected one retained trial result")
    result = json.loads(results[0].read_text())
    trial = results[0].parent
    summary = summarize(trial, result, task_config, observations,
                        json.loads((root / "cleanup.json").read_text()),
                        fault_control=args.missing_artifact_control)
    if args.subscription_judge:
        protocol_path = trial / "verifier/protocol.json"
        details_path = trial / "verifier/reward-details.json"
        protocol = json.loads(protocol_path.read_text()) if protocol_path.exists() else {}
        details = json.loads(details_path.read_text()) if details_path.exists() else {}
        summary["judge"] = {"protocol": protocol, "usage": details.get("usage"),
                            "valid": summary["checks"].get("judge_valid", False),
                            "recorded_native_sessions": len(list((trial / "verifier/judge").glob("trajectory.codex.*.jsonl")))}
    if args.agent == "codex" and effective_skills_dir:
        snapshots = [o["canaries"].get("skills") for o in observations if o["event"] == TrialEvent.AGENT_END.value]
        delivery_ok = skills_delivery_ok(snapshots, supplied_skills["effective"])
        summary["skills_delivery"] = {"ok": delivery_ok, "checked_after_steps": len(snapshots)}
        if not delivery_ok:
            summary["disposition"] = "infrastructure_error"
    if load_preflight:
        first_step = (task_config.get("steps") or [{}])[0].get("name")
        agent_dir = trial / "steps" / first_step / "agent" if first_step else trial / "agent"
        summary["history_loading"] = (check_atif_load(agent_dir, effective_load, load_preflight, root / "conversion-check")
                                      if load_preflight.get("format") == "atif"
                                      else check_native_load(agent_dir, effective_load, load_preflight))
        summary["history_loading"]["level"] = load_level
        if not summary["history_loading"]["ok"]:
            summary["disposition"] = "infrastructure_error"
            summary["workflow_complete"] = False
    write_json(root / "summary.json", summary)
    print(json.dumps({k: summary[k] for k in ("disposition", "rewards", "collection_ok", "separate_verifier", "cleanup_passed")}))
    return 0 if summary["disposition"] == "passed" else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--name", default="i01")
    parser.add_argument("--agent", choices=("codex", "oracle"), default="codex")
    parser.add_argument("--trusted-root-oracle", action="store_true",
                        help="Run an inspected imported root reference solution; never permits root Codex")
    parser.add_argument("--model", default="openai/gpt-6.1-sol")
    parser.add_argument("--effort", default="high")
    parser.add_argument("--codex-version", default="0.167.0")
    parser.add_argument("--missing-artifact-control", action="store_true")
    parser.add_argument("--subscription-judge", action="store_true",
                        help="Use the separate Docker Codex judge with transient stdin authentication")
    parser.add_argument("--resume-trajectory", action="store_true",
                        help="Continue the native conversation between workflow steps; default is fresh sessions")
    parser.add_argument("--load-trajectory", type=Path,
                        help="Seed the first conversation through Harbor's native trajectory-loading setting")
    parser.add_argument("--skill", type=Path, action="append", default=[],
                        help="Inject a local skill directory or root through Harbor; repeat in precedence order")
    parser.add_argument("--mcp-config", type=Path,
                        help="Native MCP-only fixture TOML; do not redeclare task MCP server names")
    parser.add_argument("--developer-instructions", type=Path,
                        help="Explicit project instruction file injected through native Codex developer_instructions")
    parser.add_argument("--egress-image", help="Pinned official Harbor network-controller image; agent privileges stay unchanged")
    parser.add_argument("--allow-agent-host", action="append", default=[], help="Explicit native run-level inference host additions")
    parser.add_argument("--web-search", choices=("disabled", "cached", "live"), default="disabled",
                        help="Explicit native web mode; restricted Harbor policies still apply their web default")
    sys.exit(asyncio.run(main(parser.parse_args())))
