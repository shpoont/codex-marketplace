#!/usr/bin/env python3
"""Run the native installed Exec map phase and verify retained evidence."""
import argparse,asyncio,hashlib,json,os
from importlib.metadata import version
from pathlib import Path
from harbor.cli.job_plugins import PluginConfig
from harbor.exec.executor import Executor
from harbor.models.exec import ExecConfig
from artifact_receipt import compare_receipts
from run_docker_case import command

def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')

async def main(a):
    if version('harbor')!='0.25.0':raise RuntimeError('Requalify the installed Harbor release')
    root=a.output.resolve()
    if root.is_relative_to(a.prepared.resolve()):raise ValueError('Run output must be outside the prepared source')
    root.mkdir(parents=True,exist_ok=False)
    agent={'name':a.agent}
    if a.agent=='codex':
        proc=await asyncio.create_subprocess_exec('codex','login','status',stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE);out,err=await proc.communicate()
        if proc.returncode or b'ChatGPT' not in out+err:raise RuntimeError('Existing ChatGPT sign-in required')
        auth=Path(os.environ.get('CODEX_AUTH_JSON_PATH',str(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'auth.json')))
        if not auth.is_file():raise RuntimeError('Configured native session file is unavailable')
        os.environ['CODEX_AUTH_JSON_PATH']=str(auth)
        agent.update(model_name='openai/gpt-6.1-sol',env={'CODEX_AUTH_JSON_PATH':'${CODEX_AUTH_JSON_PATH}'},kwargs={'version':'0.167.0','reasoning_effort':'high','web_search':'disabled','config':{'web_search':'disabled','features':{'multi_agent':False,'apps':False}}})
    config=ExecConfig.model_validate({'map':{'compile':{'task_name_prefix':'i12-map','output_dir':str(root/'tasks'),
        'task_template':str(a.prepared.resolve()/'template'),'instructions':[{'path':str(a.prepared.resolve()/'map.md')}],
        'environments':[{'path':str(a.prepared.resolve()/'inputs')}],
        'artifacts':[{'source':'/app/project','destination':'project'}]},
        'job':{'job_name':'i12-map','jobs_dir':str(root/'jobs'),'agents':[agent],
               'environment':{'type':'docker','delete':True},'n_attempts':1,'n_concurrent_trials':1,'retry':{'max_retries':0},'quiet':True}}})
    write(root/'exec-config.json',config.model_dump(mode='json'))
    write(root/'tooling-pins.json',{name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ['run_exec_case.py','exec_evidence.py','artifact_receipt.py','run_docker_case.py']})
    write(root/'source-pins.json',{str(p.relative_to(a.prepared)):hashlib.sha256(p.read_bytes()).hexdigest() for p in a.prepared.rglob('*') if p.is_file()})
    result=await Executor(config,plugin_configs=[PluginConfig(import_path='exec_evidence:ExecEvidence',kwargs={'output':str(root)})]).execute()
    paths=list(result.map.job_dir.glob('*/result.json'))
    if len(paths)!=1:raise RuntimeError('This reviewed profile requires one map task')
    p=paths[0];raw=json.loads(p.read_text());manifest=json.loads((p.parent/'artifacts/manifest.json').read_text())
    observations=json.loads((root/'isolation.json').read_text());receipts=observations[-1]['artifact_receipts']
    collected=all(e['status']=='ok' for e in manifest) and compare_receipts(p.parent/'artifacts',manifest,receipts)
    checks_path=p.parent/'verifier/checks.json';checks=json.loads(checks_path.read_text()) if checks_path.exists() else {}
    reward=(raw.get('verifier_result') or {}).get('rewards')
    prefix=p.parent.name.lower()+'__'
    containers=[line for line in (await command('docker','ps','-a','--filter','label=com.docker.compose.project','--format','{{.ID}} {{.Label "com.docker.compose.project"}}')).splitlines() if line.split(maxsplit=1)[1].startswith(prefix)]
    networks=[line for line in (await command('docker','network','ls','--format','{{.ID}} {{.Name}}')).splitlines() if line.split(maxsplit=1)[1].startswith(prefix)]
    valid=not raw.get('exception_info') and collected and len(observations)==2 and checks.get('no_agent_credentials_in_verifier') is True and reward is not None and json.loads((root/'host-canary.json').read_text())['unchanged']
    valid=valid and not containers and not networks
    summary={'disposition':'infrastructure_error' if not valid else 'passed' if reward['reward']==1 else 'failed',
      'rewards':reward,'collection_ok':collected,'checks':checks,'agent_info':raw.get('agent_info'),'agent_result':raw.get('agent_result'),
      'native_exec':True,'map_tasks':len(result.map.task_dirs),'reduce_started':result.reduce is not None,
      'cleanup_passed':not containers and not networks,'owned_containers_remaining':containers,'owned_networks_remaining':networks}
    write(root/'summary.json',summary);print(json.dumps(summary))
    return 0 if summary['disposition']=='passed' else 1
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--agent',choices=['codex','oracle'],default='codex');a=p.parse_args();raise SystemExit(asyncio.run(main(a)))
