#!/usr/bin/env python3
"""Run native Exec reducer staging/job from one reviewed retained map job."""
import argparse,asyncio,hashlib,json,os
from importlib.metadata import version
from pathlib import Path
from harbor.cli.job_plugins import PluginConfig
from harbor.exec.executor import Executor
from harbor.models.exec import ExecConfig
from harbor.models.job.result import JobResult
from harbor.models.trial.result import TrialResult
from harbor.models.task.task import Task
from artifact_receipt import compare_receipts,local_receipt
from run_docker_case import command

def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')

async def main(a):
    if version('harbor')!='0.25.0':raise RuntimeError('Requalify installed Harbor first')
    root=a.output.resolve();source=a.map_run.resolve()
    if root.is_relative_to(source) or root.is_relative_to(a.prepared.resolve()):raise ValueError('Reducer output must be separate from input records')
    root.mkdir(parents=True,exist_ok=False)
    summary=json.loads((source/'summary.json').read_text())
    if summary.get('disposition')!='passed' or not summary.get('collection_ok') or not summary.get('cleanup_passed'):
        write(root/'summary.json',{'disposition':'input_error','reason':'Map evidence is not a complete valid pass; reducer not started','model_calls':0});print('Map evidence rejected before reducer startup');return 1
    config=ExecConfig.model_validate_json((source/'exec-config.json').read_text())
    job_dir=Path(config.map.job.jobs_dir)/config.map.job.job_name
    if job_dir.resolve()!=(source/'jobs'/config.map.job.job_name).resolve():
        raise ValueError('Map job path is outside the selected retained run')
    result=JobResult.model_validate_json((job_dir/'result.json').read_text())
    paths=list(job_dir.glob('*/result.json'))
    result.trial_results=[TrialResult.model_validate_json(p.read_text()) for p in paths]
    if len(paths)!=1 or result.n_total_trials!=1:raise ValueError('This qualification requires one map result')
    map_artifacts=paths[0].parent/'artifacts';before=local_receipt(map_artifacts)
    manifest=json.loads((map_artifacts/'manifest.json').read_text())
    observations=json.loads((source/'isolation.json').read_text())
    receipts=observations[-1]['artifact_receipts']
    uri_matches=Executor._trial_dir_from_uri(result.trial_results[0].trial_uri).resolve()==paths[0].parent.resolve()
    if not uri_matches or not compare_receipts(map_artifacts,manifest,receipts):
        write(root/'summary.json',{'disposition':'input_error','reason':'Retained map lineage or artifact receipt no longer matches','model_calls':0});print('Map integrity rejected before reducer startup');return 1
    map_sha=hashlib.sha256((map_artifacts/'project/analysis.json').read_bytes()).hexdigest()
    agent={'name':a.agent}
    if a.agent=='codex':
        login=await asyncio.create_subprocess_exec('codex','login','status',stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE);out,err=await login.communicate()
        if login.returncode or b'ChatGPT' not in out+err:raise RuntimeError('Existing ChatGPT sign-in required')
        auth=Path(os.environ.get('CODEX_AUTH_JSON_PATH',str(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'auth.json')))
        if not auth.is_file():raise RuntimeError('Configured session unavailable')
        os.environ['CODEX_AUTH_JSON_PATH']=str(auth)
        agent.update(model_name='openai/gpt-6.1-sol',env={'CODEX_AUTH_JSON_PATH':'${CODEX_AUTH_JSON_PATH}'},kwargs={'version':'0.167.0','reasoning_effort':'high','web_search':'disabled','config':{'web_search':'disabled','features':{'multi_agent':False,'apps':False}}})
    images=json.loads((a.prepared/'images.json').read_text())
    reduce={'task':{'task_name':'i12-reduce','output_dir':str(root/'tasks'),'task_template':str(a.prepared.resolve()/'template'),
        'instruction':{'path':str(a.prepared.resolve()/'template/instruction.md')},
        'environment':{'docker_image':images['agent'],'workdir':'/app'},
        'artifacts':[{'source':'/app/project','destination':'project'},{'source':'/app/artifacts','destination':'reducer-inputs'}]},
        'job':{'job_name':'i12-reduce','jobs_dir':str(root/'jobs'),'agents':[agent],'environment':{'type':'docker','delete':True},'n_attempts':1,'n_concurrent_trials':1,'retry':{'max_retries':0},'quiet':True}}
    config=ExecConfig.model_validate({'map':config.map,'reduce':reduce})
    executor=Executor(config,plugin_configs=[PluginConfig(import_path='exec_evidence:ExecEvidence',kwargs={'output':str(root)})])
    # Deliberate review checkpoint: do not call execute(), which would rerun maps.
    task_dir=executor._compile_reduce_task(config.reduce.task,result)
    staged=next((task_dir/'environment/artifacts').iterdir())
    if local_receipt(staged)!=before:raise RuntimeError('Native reducer staging changed source bytes/types')
    task=Task(task_dir=task_dir);task.config.verifier.env['I12_SOURCE_SHA256']=map_sha
    task.paths.config_path.write_text(task.config.model_dump_toml())
    write(root/'exec-config.json',config.model_dump(mode='json'))
    write(root/'lineage.json',{'map_trial_id':str(result.trial_results[0].id),'map_trial_uri':result.trial_results[0].trial_uri,'analysis_sha256':map_sha,'staged_directory':staged.name,'native_staging_matches':True,'map_rerun':False})
    write(root/'tooling-pins.json',{n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ['run_exec_reduce.py','exec_evidence.py','artifact_receipt.py']})
    phase=await executor._run_job(config.reduce.job,[task_dir])
    p=next(phase.job_dir.glob('*/result.json'));raw=json.loads(p.read_text())
    manifest_path=p.parent/'artifacts/manifest.json';manifest=json.loads(manifest_path.read_text()) if manifest_path.exists() else []
    observations=json.loads((root/'isolation.json').read_text()) if (root/'isolation.json').exists() else []
    collected=bool(manifest) and len(observations)==2 and all(e['status']=='ok' for e in manifest) and compare_receipts(p.parent/'artifacts',manifest,observations[-1]['artifact_receipts'])
    checks_path=p.parent/'verifier/checks.json';checks=json.loads(checks_path.read_text()) if checks_path.exists() else {};rewards=(raw.get('verifier_result') or {}).get('rewards')
    unchanged=before==local_receipt(map_artifacts)
    prefix=p.parent.name.lower()+'__'
    containers=[x for x in (await command('docker','ps','-a','--filter','label=com.docker.compose.project','--format','{{.ID}} {{.Label "com.docker.compose.project"}}')).splitlines() if x.split(maxsplit=1)[1].startswith(prefix)]
    networks=[x for x in (await command('docker','network','ls','--format','{{.ID}} {{.Name}}')).splitlines() if x.split(maxsplit=1)[1].startswith(prefix)]
    valid=not raw.get('exception_info') and collected and unchanged and len(observations)==2 and checks.get('no_agent_credentials_in_verifier') is True and rewards is not None and not containers and not networks and json.loads((root/'host-canary.json').read_text())['unchanged']
    report={'disposition':'infrastructure_error' if not valid else 'passed' if rewards['reward']==1 else 'failed','rewards':rewards,'checks':checks,'collection_ok':collected,'map_artifacts_unchanged':unchanged,'map_rerun':False,'native_exec_staging':True,'agent_info':raw.get('agent_info'),'agent_result':raw.get('agent_result'),'cleanup_passed':not containers and not networks,'exception_type':(raw.get('exception_info') or {}).get('exception_type')}
    write(root/'summary.json',report);print(json.dumps(report));return 0 if report['disposition']=='passed' else 1
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--map-run',type=Path,required=True);p.add_argument('--prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--agent',choices=['codex','oracle'],default='codex');raise SystemExit(asyncio.run(main(p.parse_args())))
