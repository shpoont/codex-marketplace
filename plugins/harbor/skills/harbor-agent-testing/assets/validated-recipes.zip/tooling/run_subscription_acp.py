#!/usr/bin/env python3
"""Run opt-in native Harbor ACP setup checks, then qualified adaptive tasks."""
import argparse
import asyncio
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
from unittest.mock import patch

from harbor.job import Job
from harbor.models.job.config import JobConfig
from harbor.models.task.task import Task
from harbor.trial.hooks import TrialEvent
from run_docker_case import command, project_name, write_json, summarize
from artifact_receipt import GUEST_RECEIPT
from subscription_codex_acp import SubscriptionCodexACP, subscription_bridge, check_runtime


NATIVE_QUESTION_TOOLS = {"request_user_input_async", "request_user_input",
                         "mcp__data__form_elicitation_v2_request"}


def owns_resource(name, trial_name):
    base = re.sub(r"[^a-z0-9_-]", "-", trial_name.lower())
    return name.startswith(base + "__")


def called_capabilities(calls):
    """Classify invocations, not strings used to search tool metadata."""
    invoked = []
    for call in calls:
        name = call.get("name", "")
        if name != "exec":
            invoked.append(name)
        if name == "exec":
            code = call.get("input", call.get("arguments", ""))
            invoked.extend(re.findall(r"tools\.([A-Za-z0-9_]+)\s*\(", str(code)))
    native_questions = [n for n in invoked if n in NATIVE_QUESTION_TOOLS]
    disallowed = [n for n in invoked if (n.startswith("mcp__") and n not in NATIVE_QUESTION_TOOLS)
                  or n in ("web__run", "spawn_agent", "image_gen__imagegen")]
    return native_questions, disallowed


def separate_valid_rewards(summary):
    native = summary.get("native_rewards", summary.get("rewards"))
    return {**summary, "native_rewards": native,
            "rewards": native if summary.get("disposition") in ("passed", "failed") else None}


def native_role_evidence(trial):
    """Read each role's own cumulative history; native agent_result is the user."""
    roles = {}
    for role, directory in (("target", "agent"), ("simulated_user", "user-agent")):
        files = list((trial / directory / "sessions").rglob("*.jsonl"))
        if len(files) != 1:
            roles[role] = {"valid": False, "history_files": len(files)}
            continue
        events = [json.loads(line) for line in files[0].read_text().splitlines()]
        profiles = {(x["payload"].get("model"), x["payload"].get("effort"))
                    for x in events if x["type"] == "turn_context"}
        ids = {x["payload"].get("id") for x in events if x["type"] == "session_meta"}
        totals = [x["payload"]["info"]["total_token_usage"] for x in events
                  if x["type"] == "event_msg" and x["payload"].get("type") == "token_count"
                  and (x["payload"].get("info") or {}).get("total_token_usage")]
        calls = [x["payload"] for x in events if x["type"] == "response_item"
                 and x["payload"].get("type") in ("function_call", "custom_tool_call")]
        native_questions, disallowed = called_capabilities(calls)
        roles[role] = {"valid": profiles == {("gpt-6.1-sol", "high")} and len(ids) == 1 and bool(totals) and not disallowed,
            "session_id": next(iter(ids)) if len(ids) == 1 else None,
            "model_effort": [list(p) for p in sorted(profiles)],
            "turns_started": sum(x["type"] == "event_msg" and x["payload"].get("type") == "task_started" for x in events),
            "turns_completed": sum(x["type"] == "event_msg" and x["payload"].get("type") == "task_complete" for x in events),
            "usage": totals[-1] if totals else None, "usage_basis": "latest native cumulative session totals",
            "native_question_calls": native_questions, "disallowed_calls": disallowed,
            "history_sha256": hashlib.sha256(files[0].read_bytes()).hexdigest()}
    valid = all(x["valid"] for x in roles.values()) and roles["target"].get("session_id") != roles["simulated_user"].get("session_id")
    return {"valid": valid, "roles": roles, "native_agent_result_role": "simulated_user",
            "limit": "Behavior/adaptation and work attribution require a separate transcript review"}


async def main(args):
    check_runtime()
    root = args.output.resolve()
    if root.is_relative_to(Path(__file__).resolve().parents[1]):
        raise ValueError("Run evidence must remain outside source Git")
    root.mkdir(parents=True, exist_ok=False)
    prefixes = []
    live = args.task is not None
    if live:
        if args.control != "good" or root.is_relative_to(args.task.resolve()):
            raise ValueError("Adaptive tasks require separate output and no setup-fault control")
        task = args.task.resolve()
        if Task(task_dir=task).config.environment.docker_image != args.image:
            raise ValueError("Adaptive task image does not match the selected immutable ID")
    else:
        task = root / "setup-task"
        (task / "environment").mkdir(parents=True)
        (task / "instruction.md").write_text("Setup-only probe. Do not run inference.\n")
        (task / "task.toml").write_text(
            'schema_version = "1.4"\n[agent]\nuser = "node"\ntimeout_sec = 600\n'
            '[environment]\ndocker_image = ' + json.dumps(args.image) + '\ncpus = 1\nmemory_mb = 2048\nnetwork_mode = "public"\n')
    canary = root / "host-only-canary.txt"; canary.write_text("ACP host-only isolation canary\n")
    canary_before = hashlib.sha256(canary.read_bytes()).hexdigest()
    observations = []; process_samples = []; sampling_stop = asyncio.Event(); sampler = None
    auth = Path(os.environ.get("CODEX_AUTH_JSON_PATH", str(Path(os.environ.get(
        "CODEX_HOME", str(Path.home() / ".codex"))) / "auth.json")))
    if args.control in ("malformed", "api-auth", "missing"):
        auth = root / "synthetic-session-source.json"
        if args.control != "missing":
            auth.write_text("{malformed" if args.control == "malformed" else
                            json.dumps({"OPENAI_API_KEY": "public-synthetic-invalid"}))
    else:
        login = await asyncio.create_subprocess_exec("codex", "login", "status",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await asyncio.wait_for(login.communicate(), 30)
        if login.returncode or b"ChatGPT" not in stdout + stderr or not auth.is_file():
            raise RuntimeError("The existing configured ChatGPT sign-in is required")
    os.environ["CODEX_AUTH_JSON_PATH"] = str(auth)
    kwargs = {"version": "0.167.0", "reasoning_effort": "high", "web_search": "disabled",
              "config": {"web_search": "disabled", "features": {"apps": False, "multi_agent": False}}}
    env = {"CODEX_AUTH_JSON_PATH": "${CODEX_AUTH_JSON_PATH}"}
    if not live:
        env.update(OPENAI_API_KEY="public-synthetic-invalid", CODEX_API_KEY="public-synthetic-invalid")
    config = JobConfig.model_validate({"job_name": "acp-" + (task.name if live else "setup"), "jobs_dir": str(root / "jobs"),
        "tasks": [{"path": str(task)}], "agents": [{"import_path": "subscription_codex_acp:SubscriptionCodexACP",
            "model_name": "openai/gpt-6.1-sol", "env": env, "kwargs": kwargs}],
        "user_agent": {"name": "codex", "model_name": "openai/gpt-6.1-sol", "env": env,
                       "kwargs": kwargs, "bridge": {"kind": "acp"}},
        "install_only": not live, "environment": {"type": "docker", "delete": True},
        "n_attempts": 1, "n_concurrent_trials": 1, "retry": {"max_retries": 0}, "quiet": True})
    write_json(root / "inputs.json", {"mode": "adaptive" if live else "install_only", "control": args.control,
        "model": "openai/gpt-6.1-sol", "effort": "high", "image": args.image,
        "model_calls": None if live else 0, "adapter_sha256": hashlib.sha256(Path(__file__).with_name("subscription_codex_acp.py").read_bytes()).hexdigest(),
        "task_files": {str(p.relative_to(task)): hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file()}})

    async def started(event):
        prefixes.append(event.trial_name)

    async def observe(event):
        nonlocal sampler
        ids = (await command("docker", "ps", "-q", "--filter",
            "label=com.docker.compose.project=" + project_name(event.trial_name),
            "--filter", "label=com.docker.compose.service=main")).split()
        if len(ids) != 1: raise RuntimeError("Expected one owned ACP container")
        container = ids[0]
        spec = json.loads(await command("docker", "inspect", "--format",
            '{"image":{{json .Image}},"mounts":{{json .Mounts}},"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},"ports":{{json .HostConfig.PortBindings}}}', container))
        if spec["image"] != args.image or any(spec[k] for k in ("mounts", "privileged", "cap_add", "ports")):
            raise RuntimeError("ACP isolation/image mismatch")
        probe = """import json,os,stat,sys;from pathlib import Path
p=Path('/installed-agent/codex-subscription-acp-home/auth.json')
print(json.dumps({'uid':os.getuid(),'host_canary_absent':not Path(sys.argv[1]).exists(),'grader_absent':not Path('/tests/check.py').exists(),'socket_absent':not Path('/var/run/docker.sock').exists(),'target_auth_present':p.is_file(),'target_auth_secure':p.is_file() and p.stat().st_uid==1000 and stat.S_IMODE(p.stat().st_mode)==0o600,'user_auth_cleaned':not Path('/tmp/codex-secrets').exists() and not Path('/installed-agent/codex-home/auth.json').exists()}))"""
        state = json.loads(await command("docker", "exec", "--user", "node", container,
                                        "python3", "-c", probe, str(canary)))
        if state["uid"] != 1000 or not all(state[k] for k in ("host_canary_absent", "grader_absent", "socket_absent", "user_auth_cleaned")):
            raise RuntimeError("ACP isolation/credential canary failed")
        beginning = event.event == TrialEvent.AGENT_START
        if state["target_auth_present"] != beginning or (beginning and not state["target_auth_secure"]):
            raise RuntimeError("ACP credential phase boundary failed")
        receipts = []
        if not beginning:
            sampling_stop.set()
            if sampler: await sampler
            entries = json.loads(await command("docker", "exec", "--user", "node", container,
                "python3", "-c", GUEST_RECEIPT, json.dumps(["/app/project", []])))
            receipts.append({"source": "/app/project", "service": "main", "entries": entries})
        else:
            async def sample_processes():
                code = """import json,subprocess
r={'target_uids':[],'user_uids':[]}
for line in subprocess.check_output(['ps','-eo','uid=,comm=,args='],text=True).splitlines():
 parts=line.strip().split(None,2)
 if len(parts)!=3 or parts[1]!='codex':continue
 if ' app-server' in parts[2]:r['target_uids'].append(int(parts[0]))
 elif ' exec ' in parts[2]:r['user_uids'].append(int(parts[0]))
print(json.dumps(r))"""
                while not sampling_stop.is_set():
                    process_samples.append(json.loads(await command("docker", "exec", "--user", "node", container,
                        "python3", "-c", code)))
                    try: await asyncio.wait_for(sampling_stop.wait(), 0.5)
                    except asyncio.TimeoutError: pass
            sampler = asyncio.create_task(sample_processes())
        observations.append({"event": event.event.value, "step_name": None, "spec": spec,
                             "canaries": state, "artifact_receipts": receipts})
        write_json(root / "isolation.json", observations)
        write_json(root / "process-samples.json", process_samples)

    async def mark_uploaded(self, environment):
        state = await self.exec_as_agent(environment, command=(
            "stat -c '%u %a' " + str(self._REMOTE_ACP_CODEX_HOME / "auth.json")))
        if state.stdout.strip() != "1000 600":
            raise RuntimeError("Fault control did not reach secured transient auth")
        self.subscription_lifecycle["fault_after_secured_auth"] = True

    async def fail_after_upload(self, environment, *args, **kwargs):
        await mark_uploaded(self, environment)
        raise RuntimeError("Controlled failure after transient auth upload")

    async def timeout_after_upload(self, environment, *args, **kwargs):
        await mark_uploaded(self, environment)
        await asyncio.wait_for(asyncio.Event().wait(), timeout=0.05)

    error = None
    try:
        with ExitStack() as stack:
            stack.enter_context(subscription_bridge())
            if args.control in ("failure", "timeout"):
                stack.enter_context(patch.object(SubscriptionCodexACP, "_upload_effective_config",
                    fail_after_upload if args.control == "failure" else timeout_after_upload))
            job = await Job.create(config)
            job.add_hook(TrialEvent.START, started)
            if live:
                job.add_hook(TrialEvent.AGENT_START, observe)
                job.add_hook(TrialEvent.AGENT_END, observe)
            await job.run()
    except Exception as exc:
        error = type(exc).__name__
        write_json(root / "preflight-error.json", {"type": error})
    finally:
        sampling_stop.set()
        if sampler and not sampler.done():
            await sampler
        containers = [line for line in (await command("docker", "ps", "-a", "--filter",
            "label=com.docker.compose.project", "--format", '{{.ID}} {{.Label "com.docker.compose.project"}}')).splitlines()
            if any(owns_resource(line.split(maxsplit=1)[1], p) for p in prefixes)]
        networks = [line for line in (await command("docker", "network", "ls", "--format", "{{.ID}} {{.Name}}")).splitlines()
            if any(owns_resource(line.split(maxsplit=1)[1], p) for p in prefixes)]
        write_json(root / "cleanup.json", {"containers": containers, "networks": networks})
    paths = list((root / "jobs").glob("*/*/result.json"))
    raw = json.loads(paths[0].read_text()) if len(paths) == 1 else {}
    lifecycle_path = paths[0].parent / "agent/subscription-lifecycle.json" if paths else root / "absent"
    lifecycle = json.loads(lifecycle_path.read_text()) if lifecycle_path.exists() else {}
    if live:
        cleanup = {"host_canary_unchanged": hashlib.sha256(canary.read_bytes()).hexdigest() == canary_before,
                   "owned_containers_remaining": containers, "owned_networks_remaining": networks}
        if not paths: raise RuntimeError("Adaptive run has no retained native trial")
        result = summarize(paths[0].parent, raw, Task(task_dir=task).config.model_dump(mode="json"), observations, cleanup)
        user_uids = {u for s in process_samples for u in s["user_uids"]}
        target_uids = {u for s in process_samples for u in s["target_uids"]}
        result.update(mode="adaptive", lifecycle=lifecycle,
            observed_role_uids={"target": sorted(target_uids), "user": sorted(user_uids)},
            native_agent_result_role="simulated_user",
            behavior_review="pending separate native-history review")
        evidence = native_role_evidence(paths[0].parent)
        write_json(root / "role-evidence.json", evidence)
        result["role_evidence"] = evidence
        if not lifecycle.get("cleanup_ok") or not lifecycle.get("auth_verified") or user_uids != {1000} or target_uids != {1000}:
            result["disposition"] = "infrastructure_error"
        if not evidence["valid"]:
            result["disposition"] = "infrastructure_error"
        result = separate_valid_rewards(result)
        write_json(root / "summary.json", result)
        print(json.dumps({k: result[k] for k in ("disposition", "rewards", "collection_ok", "cleanup_passed", "observed_role_uids")}))
        return 0 if result["disposition"] == "passed" else 1
    if raw.get("agent_execution") is not None:
        raise RuntimeError("Install-only control unexpectedly executed an agent")
    result = {"mode": "install_only", "control": args.control, "model_calls": 0,
        "native_trials": len(paths), "agent_executed": False, "preflight_error": error,
        "exception_type": (raw.get("exception_info") or {}).get("exception_type"),
        "lifecycle": lifecycle, "cleanup_passed": not containers and not networks,
        "setup_passed": bool(raw) and not raw.get("exception_info") and lifecycle.get("auth_verified") is True
                        and lifecycle.get("cleanup_ok") is True and not containers and not networks}
    write_json(root / "summary.json", result)
    print(json.dumps(result))
    return 0 if result["setup_passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--task", type=Path)
    parser.add_argument("--control", choices=("good", "missing", "malformed", "api-auth", "failure", "timeout"), default="good")
    raise SystemExit(asyncio.run(main(parser.parse_args())))
