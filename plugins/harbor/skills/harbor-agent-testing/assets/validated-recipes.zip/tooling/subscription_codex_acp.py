"""Opt-in subscription ACP target for the qualified Harbor 0.25 Docker profile.

Reuses Harbor's ACP bridge and Codex helpers. No installed module is patched.
Derived helper behavior: harbor-framework/harbor v0.25.0 (Apache-2.0).
"""
import asyncio
from contextlib import contextmanager
import hashlib
import inspect
import json
from importlib.metadata import version
from pathlib import Path, PurePosixPath
import shlex

from harbor.agents.installed.codex import Codex
from harbor.bridges.acp import ACPBridge, build_acpx_config, write_acpx_config
from harbor.bridges.base import bridge_class_for_kind, register_bridge
from harbor.environments.docker.docker import DockerEnvironment
from harbor.models.bridge import BridgeKind
from harbor.utils.env import parse_bool_env_value


MODEL = "gpt-6.1-sol"
EFFORT = "high"
CODEX_VERSION = "0.167.0"
CODEX_SOURCE_SHA256 = "3697e51e7b44447e965c83c56dec9197ae1021ea7087f804ca9451d568fbafa5"
REMOVED_ENV = ("OPENAI_API_KEY", "CODEX_API_KEY", "OPENAI_BASE_URL", "OPENAI_API_BASE",
               "DEFAULT_AUTH_REQUEST", "CODEX_AUTH_JSON_PATH", "CODEX_FORCE_AUTH_JSON")


def check_runtime():
    if version("harbor") != "0.25.0" or hashlib.sha256(
        Path(inspect.getfile(Codex)).read_bytes()
    ).hexdigest() != CODEX_SOURCE_SHA256:
        raise RuntimeError("Requalify the opt-in subscription ACP adapter for this Harbor installation")


class SubscriptionCodexACP(Codex):
    """A separately named target, selected only via its explicit import path."""

    _REMOTE_ACP_CODEX_HOME = PurePosixPath("/installed-agent/codex-subscription-acp-home")

    @staticmethod
    def name():
        return "codex-subscription-acp"

    def __init__(self, *args, **kwargs):
        check_runtime()
        super().__init__(*args, **kwargs)
        if self._resolved_model_name() != MODEL or self.options.reasoning_effort != EFFORT:
            raise ValueError("This opt-in profile requires GPT-6.1 Sol / High")
        if self.options.version != CODEX_VERSION:
            raise ValueError("This opt-in profile requires Codex 0.167.0")
        self.subscription_lifecycle = {"auth_verified": False, "cleanup_ok": False}
        self._acp_codex_executable = "/usr/local/bin/codex"

    @classmethod
    def resolve_model_connection_config_for_bridge(cls, bridge, model_name, resolve_env, **kwargs):
        check_runtime()
        if bridge != BridgeKind.ACP:
            raise ValueError("This adapter supports only the existing ACP bridge")
        path = resolve_env("CODEX_AUTH_JSON_PATH")
        force = resolve_env("CODEX_FORCE_AUTH_JSON")
        if not ((path and path[1]) or parse_bool_env_value(
            force[1] if force else None, name="CODEX_FORCE_AUTH_JSON", default=False
        )):
            raise ValueError("Explicit existing ChatGPT sign-in selection is required; no API fallback")
        # Native resolution already enforces provider/key conflicts and strips API keys.
        access = cls.resolve_model_connection_config(model_name, resolve_env, **kwargs)
        if access.user_supplied_base_url or access.api_key is not None:
            raise ValueError("The subscription ACP profile does not accept API keys or endpoint overrides")
        return access

    def _bridge_config(self):
        config = self._build_effective_config(None)
        if config.get("model_provider", "openai") != "openai" or config.get("openai_base_url"):
            raise ValueError("External native provider configuration is outside this subscription profile")
        config.update(model=MODEL, model_reasoning_effort=EFFORT, web_search="disabled",
                      cli_auth_credentials_store="file")
        config["features"] = {**config.get("features", {}), "apps": False, "multi_agent": False}
        return config

    def acp_command(self):
        command = ["env"]
        for name in REMOVED_ENV:
            command.extend(["-u", name])
        return command + ["NO_BROWSER=1", "INITIAL_AGENT_MODE=agent-full-access",
            f"CODEX_HOME={self._REMOTE_ACP_CODEX_HOME}",
            "CODEX_CONFIG=" + json.dumps(self._bridge_config()),
            "CODEX_PATH=/usr/local/bin/codex", "/usr/local/bin/codex-acp"]

    def acp_env(self):
        self._resolve_model_connection(self.model_name, bridge=BridgeKind.ACP)
        return {**self.mcp_header_env.env, "OPENAI_API_KEY": "", "CODEX_API_KEY": "",
                "OPENAI_BASE_URL": "", "OPENAI_API_BASE": "", "DEFAULT_AUTH_REQUEST": ""}

    async def _validate_environment(self, environment):
        if not isinstance(environment, DockerEnvironment) or environment.default_user != "node":
            raise ValueError("Subscription ACP requires disposable Docker with task agent user=node")
        image = environment.task_env_config.docker_image
        if not image or not image.startswith("sha256:"):
            raise ValueError("An immutable prebuilt Docker image ID is required")
        result = await environment._run_docker_compose_command(["ps", "-q", "main"])
        ids = result.stdout.split()
        if len(ids) != 1:
            raise RuntimeError("Expected one owned Docker target container")
        proc = await asyncio.create_subprocess_exec(
            "docker", "inspect", "--format",
            '{"image":{{json .Image}},"mounts":{{json .Mounts}},"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},"ports":{{json .HostConfig.PortBindings}}}',
            ids[0], stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), 20)
        if proc.returncode:
            raise RuntimeError("Could not inspect the owned ACP container")
        spec = json.loads(stdout)
        if spec["image"] != image or any(spec[k] for k in ("mounts", "privileged", "cap_add", "ports")):
            raise RuntimeError("ACP container image/isolation mismatch before credential delivery")
        self.subscription_lifecycle["docker_spec"] = spec

    async def _remove_private_home(self, environment):
        home = shlex.quote(str(self._REMOTE_ACP_CODEX_HOME))
        result = await self.exec_as_root(environment, command=f"rm -rf -- {home} && test ! -e {home}")
        if result.return_code:
            raise RuntimeError("ACP private-home cleanup failed")
        self.subscription_lifecycle["cleanup_ok"] = True

    def _save_lifecycle(self):
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        (self.logs_dir / "subscription-lifecycle.json").write_text(
            json.dumps(self.subscription_lifecycle, indent=2) + "\n")

    async def acp_install(self, environment):
        auth = self._resolve_auth_json_path()
        if auth is None:
            raise ValueError("Existing ChatGPT sign-in is required; no login or API fallback")
        await self._validate_environment(environment)
        self.subscription_lifecycle["cleanup_ok"] = False
        try:
            # Tools are pinned in the disposable image; do not install a second Codex.
            probe = """import json,os,subprocess;from pathlib import Path
print(json.dumps({'uid':os.getuid(),'codex':subprocess.check_output(['/usr/local/bin/codex','--version'],text=True).strip(),'acp':json.loads(Path('/usr/local/lib/node_modules/@agentclientprotocol/codex-acp/package.json').read_text())['version'],'acpx':json.loads(Path('/usr/local/lib/node_modules/acpx/package.json').read_text())['version']}))"""
            result = await self.exec_as_agent(environment, command="python3 -c " + shlex.quote(probe))
            pins = json.loads(result.stdout)
            if pins != {"uid": 1000, "codex": "codex-cli 0.167.0", "acp": "1.12.0", "acpx": "0.11.2"}:
                raise RuntimeError("ACP binary/user pins differ from the qualified profile")
            self.subscription_lifecycle["binaries"] = pins
            uid, gid = await self._ensure_agent_owned_dir(environment, self._REMOTE_ACP_CODEX_HOME)
            remote_auth = str(self._REMOTE_ACP_CODEX_HOME / "auth.json")
            # Native scoped transfer consumes the configured session internally.
            # Never parse/read its contents here or create a host credential copy.
            await environment.upload_file(auth, remote_auth)
            permission = await self.exec_as_root(environment, command=(
                f"chown {uid}:{gid} {shlex.quote(remote_auth)} && chmod 600 {shlex.quote(remote_auth)}"
            ))
            if permission.return_code:
                raise RuntimeError("Could not secure temporary ACP sign-in")
            config = self._bridge_config()
            await self._upload_effective_config(environment, config,
                str(self._REMOTE_ACP_CODEX_HOME / "config.toml"))
            command = ["env"]
            for name in REMOVED_ENV:
                command.extend(["-u", name])
            command += [f"CODEX_HOME={self._REMOTE_ACP_CODEX_HOME}", "/usr/local/bin/codex", "login", "status"]
            status = await self.exec_as_agent(environment, command=shlex.join(command))
            if status.return_code or "ChatGPT" not in ((status.stdout or "") + (status.stderr or "")):
                raise RuntimeError("Temporary ACP home is not a valid ChatGPT sign-in; refusing fallback")
            self.subscription_lifecycle["auth_verified"] = True
            self._save_lifecycle()
        except BaseException:
            await asyncio.shield(self._remove_private_home(environment))
            self._save_lifecycle()
            raise

    async def acp_teardown(self, environment):
        self.subscription_lifecycle["cleanup_ok"] = False
        try:
            await super().acp_teardown(environment)
        finally:
            await self._remove_private_home(environment)
            self._save_lifecycle()


class SubscriptionACPBridge(ACPBridge):
    """Existing ACP bridge with verified prebuilt tools rather than runtime npm."""

    async def setup(self, environment):
        if not isinstance(self._acp_agent, SubscriptionCodexACP):
            raise ValueError("Opt-in bridge requires the named subscription target")
        # acp_install checks all three baked binary pins and Docker boundaries.
        await self._acp_agent.acp_install(environment)
        config = build_acpx_config(self._acp_agent.acp_command(), self._acpx_overrides)
        await write_acpx_config(environment, config)
        result = await environment.exec("acpx sessions ensure")
        if result.return_code:
            raise RuntimeError("Subscription ACP session initialization failed; refusing fallback")


@contextmanager
def subscription_bridge():
    """Supported registration only for this explicit launcher scope; restore it."""
    previous = bridge_class_for_kind(BridgeKind.ACP)
    register_bridge(BridgeKind.ACP, SubscriptionACPBridge)
    try:
        yield
    finally:
        register_bridge(BridgeKind.ACP, previous)
