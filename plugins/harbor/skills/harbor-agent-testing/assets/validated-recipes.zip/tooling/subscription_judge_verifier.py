"""Native Harbor Docker verifier with transient subscription delivery over stdin.

Only the configured native session file handle is passed to docker exec. No
credential bytes enter job configuration, command arguments or a host copy.
RewardKit itself owns its temporary guest Codex home and cleanup.
"""
import asyncio
import hashlib
import json
import os
from pathlib import Path

from harbor.environments.docker.docker import DockerEnvironment, _sanitize_docker_compose_project_name
from harbor.models.verifier.result import VerifierResult
from harbor.verifier.verifier import Verifier


class SubscriptionJudgeVerifier(Verifier):
    async def verify(self):
        if not isinstance(self.environment,DockerEnvironment) or self.task.config.verifier.environment_mode.value!='separate':
            raise RuntimeError('Subscription judge requires the qualified separate Docker profile')
        if self.override_env or self.verifier_env:
            raise ValueError('Judge credentials/settings must not enter serialized verifier env')
        control=self.task.config.verifier.env.get('I11_CONTROL','live')
        if set(self.task.config.verifier.env)-{'I11_CONTROL'} or control not in ('live','timeout','parse-error'):
            raise ValueError('Unsupported judge runtime controls')
        login=await asyncio.create_subprocess_exec('codex','login','status',stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
        out,err=await login.communicate()
        if login.returncode or b'ChatGPT' not in out+err:raise RuntimeError('Existing ChatGPT sign-in required')
        auth=Path(os.environ.get('CODEX_AUTH_JSON_PATH',str(Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))/'auth.json')))
        project=_sanitize_docker_compose_project_name(self.environment.session_id)
        ps=await asyncio.create_subprocess_exec('docker','ps','-q','--filter',f'label=com.docker.compose.project={project}','--filter','label=com.docker.compose.service=main',stdout=asyncio.subprocess.PIPE)
        ids=(await ps.communicate())[0].decode().split()
        if len(ids)!=1:raise RuntimeError('Expected one owned verifier container')
        identity=ids[0]
        inspect=await asyncio.create_subprocess_exec('docker','inspect','--format',
            '{"image":{{json .Image}},"privileged":{{json .HostConfig.Privileged}},"cap_add":{{json .HostConfig.CapAdd}},"mounts":{{json .Mounts}},"ports":{{json .HostConfig.PortBindings}}}',identity,stdout=asyncio.subprocess.PIPE)
        spec=json.loads((await inspect.communicate())[0])
        if spec['privileged'] or spec['cap_add'] or spec['mounts'] or spec['ports']:
            raise RuntimeError('Unexpected verifier privileges or host exposure')
        if spec['image']!=self.environment.task_env_config.docker_image:raise RuntimeError('Verifier image pin mismatch')
        await self._remove_reward_files()
        # Tests are baked in the pinned verifier image. No source code runs on host.
        self.trial_paths.verifier_dir.mkdir(parents=True,exist_ok=True)
        (self.trial_paths.verifier_dir/'docker-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
        with (open(os.devnull,'rb') if control=='parse-error' else auth.open('rb')) as session:
            process=await asyncio.create_subprocess_exec('docker','exec','-i','--user','root',
                '--env',f'I11_CONTROL={control}',identity,'python3','/tests/check.py',
                stdin=session,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
            try:stdout,stderr=await process.communicate()
            except BaseException:
                if process.returncode is None:process.kill();await process.wait()
                raise
        try:
            await self.environment.download_dir('/logs/verifier',self.trial_paths.verifier_dir)
        except Exception as exc:raise RuntimeError('Judge evidence collection failed') from exc
        (self.trial_paths.verifier_dir/'test-stdout.txt').write_bytes(stdout)
        (self.trial_paths.verifier_dir/'test-stderr.txt').write_bytes(stderr)
        # download_dir can replace the directory; retain fresh actual Docker readback.
        (self.trial_paths.verifier_dir/'docker-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
        checks=json.loads((self.trial_paths.verifier_dir/'checks.json').read_text())
        if process.returncode or checks.get('grading_valid',checks.get('judge_valid')) is not True or checks.get('judge_credentials_cleaned') is not True:
            raise RuntimeError('Judge failed; inspect retained non-secret validity evidence')
        return VerifierResult(rewards=self._parse_reward_json())
